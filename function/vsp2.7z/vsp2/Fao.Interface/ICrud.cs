﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Interface
{
    /// <summary>
    /// created by：yzq 2012-12-30
    /// 实现增，删，查，改以及批量操作数据源的接口
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface ICrud<T> where T : class
    {
        /// <summary>
        /// 添加一个实体，并返回实体标识ID
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        string AddToEntity(T entity);
         
        /// <summary>
        /// 更新一个实体，并返回更新成功与否，成功返回添加的条数
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        string ResetToEntity(T entity);
          
        /// <summary>
        /// 删除一个实体，并返回成功与否，成功返回1
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        string RemoveToEntitys(T entity);
        
        /// <summary>
        /// 返回一个实体
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        T One(IQueryable<T> query, T entity);

        /// <summary>
        /// 返回多个实体
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        IQueryable<T> Many(IQueryable<T> query, T entity);
    }
}

﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Data.B2B.Enum;
using Fao.Common;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// PPC服务实现-Power by CodeGG 
    /// </summary>
    public class PPCService : Entity<PPC>, IPPCService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();
        IPPCTacticService pPPCTacticService = new PPCTacticService();
        IPPCRecordService ppcRecordService = new PPCRecordService();
        IUserTransactionService userTransactionService = new UserTransactionService();
      
        IB2BInfoService b2bInfoService = new B2BInfoService();
        ILogisticCargoService logisticCargoService = new LogisticCargoService();
        ILogisticStoreService logisticStoreService = new LogisticStoreService();
        ILogisticVehicleSourceService logisticVehicleSourceService = new LogisticVehicleSourceService();
        ILogisticRouteService logisticRouteService = new LogisticRouteService();

        #endregion

        #region 实现业务接口


        /// <summary>
        /// 删除推广记录
        /// </summary>
        /// <param name="ppcType">推广类型</param>
        /// <param name="keyID">推广逐渐</param>
        /// <returns></returns>
        public int DeletePPC(int ppcType, int keyID)
        {
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                int count = context.PPCs.Where(p => p.IntWordType == ppcType && p.IntTablePrimkeyID == keyID && p.IntFlag == 1).Count();
                if (count > 0)
                {
                    flag = context.Database.SqlQuery<int>("Prc_Del_PPC  @p0,@p1", ppcType, keyID).FirstOrDefault();
                }
            }
            return flag;
        }

        /// <summary>
        /// 根据SmHotWord查询模型，返回VmHotWord视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图热词分页</returns>
        public VmPPCPaging GetOneHotWordHistory(string id, string keyword)
        {
            VmPPCPaging page = new VmPPCPaging();
            using (var context = new FaoB2BEntities())
            {
                var entities = context.Database.SqlQuery<VmPPC>("ProcGetOneHotWordPriceHistory @p0,@p1", id, keyword).ToList();
                var rows = entities.Select(e => new VmPPC
                    {
                        IntWordType = e.IntWordType,
                        VarKeyword = e.VarKeyword,
                        DecValue = e.DecValue,
                        VarNickName = e.VarNickName,
                        ValueRank = e.ValueRank
                    }).ToList();
                page.rows = rows;
                page.total = 0;
            }
            return page;
        }


        /// <summary>
        /// 根据SmPPC查询模型，返回VmPPC视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmPPC> GetPPCs(SmPPC searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmPPC视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmPPC GetPPCByID(string EncriptID)
        {
            string strID = Security.Decrypt(EncriptID);
            PPC entity = null;
            VmPPC model=null;
            using (var context = new FaoB2BEntities())
            {
                entity = context.PPCs.Find(Utils.ToInt(strID));
                if (entity != null)
                {
                    string title = "";
                    if (entity.IntWordType <= 5)
                    {
                        title = b2bInfoService.GetB2BInfoByID(context,entity.IntTablePrimkeyID).Title;
                    }
                    else if (entity.IntWordType == 6)
                    {
                        title=logisticCargoService.GetLogisticCargoInfoBy(context,Security.Encrypt(entity.IntTablePrimkeyID)).CargoTitle;
                    }
                    else if (entity.IntWordType == 7)
                    {
                        title=logisticStoreService.GetLogisticStoreInfoBy(context,Security.Encrypt(entity.IntTablePrimkeyID)).StoreTitle;
                    }
                    else if (entity.IntWordType ==8)
                    {
                        title=logisticVehicleSourceService.GetVehicleSourceInfoBy(context,Security.Encrypt(entity.IntTablePrimkeyID)).LicenseNum;
                    }
                    else if (entity.IntWordType == 9)
                    {
                        title=logisticRouteService.GetLogisticRouteInfoBy(context, Security.Encrypt(entity.IntTablePrimkeyID)).LicenseNum;
                    }
                    model = new VmPPC()
                    {
                        VarKeyword = entity.VarKeyword,
                        DecValue =decimal.Round(entity.DecValue,2),
                        DteValid = entity.DteValid,
                        StrCreateDate = Utils.GetDateTimeFormate(entity.DteCreate),
                        EncryptID = Security.Encrypt(entity.IntPPCID),
                        IntTablePrimkeyID =entity.IntTablePrimkeyID,
                        EncriptTableID = Security.Encrypt(entity.IntTablePrimkeyID),
                        IntWordType = entity.IntWordType,
                        StrValidDate = Utils.GetDateTimeFormate(entity.DteValid),
                        CreateDate = entity.DteCreate,
                        Title=title,
                        ValidTimeSpan = entity.PPCTactics.Select(p => new VmPPCTactic { DteStartTime = DateTime.Today + p.DteStartTime, DteEndTime = DateTime.Today + p.DteEndTime }).ToList()
                    };
                }
            }

            return model;
        }

        /// <summary>
        /// 添加一条信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddPPC(VmPPC model, List<Tuple<string, string>> timeSpan, string payPassword)
        {
            string str = null;
            using (var context = new FaoB2BEntities())
            {
                var transaction = userTransactionService.GetCurrentUserTransaction(context);
                string encriptPassword = Security.MD5(payPassword);
                if (transaction.PaymentPwd != encriptPassword)
                {
                    str = "支付密码错误";
                }
                else
                {
                    if (transaction.PPCBalance < model.DecValue)
                    {
                        str = "余额不足";
                    }
                    else
                    {
                        #region 查询该热词对于该信息是否已存在

                        var entities = context.PPCs.Where(p => p.VarKeyword == model.VarKeyword && p.IntTablePrimkeyID == model.IntTablePrimkeyID && p.IntWordType == model.IntWordType && p.DteValid >= DateTime.Now).ToList();
                        int count = entities.Count();
                        if (count > 0)
                        {
                            for (int i = 0; i < count; i++)
                            {
                                entities[i].IntFlag = 0;
                            }
                        }

                        #endregion
                        var user = baseUserService.CurrentUser(context.BaseUsers);
                        var entity = new PPC();
                        entity.DteCreate = DateTime.Now;
                        entity.DteValid = model.DteValid;
                        entity.DecValue = model.DecValue;
                        entity.IntCreateUserID = user.IntUserID;
                        entity.IntTablePrimkeyID = model.IntTablePrimkeyID;
                        entity.IntWordType = model.IntWordType;
                        entity.IntFlag = 1;
                        entity.VarKeyword = model.VarKeyword;
                        context.PPCs.Add(entity);
                        int flag = context.SaveChanges();
                        if (flag > 0)
                        {
                            for (int i = 0; i < timeSpan.Count; i++)
                            {
                                VmPPCTactic tractic = new VmPPCTactic();
                                tractic.IntPPCID = entity.IntPPCID;
                                tractic.DteStartTime = DateTime.Today.AddHours(int.Parse(timeSpan[i].Item1));
                                tractic.DteEndTime = DateTime.Today.AddHours(int.Parse(timeSpan[i].Item2));
                                tractic.IntFlag = 1;
                                pPPCTacticService.AddPPCTactic(tractic);
                            }
                            str = "1";
                        }
                        else
                        {
                            str = "保存失败";
                        }
                    }
                }
            }
            return str;
        }

        /// <summary>
        /// 显示用户推广列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VmPPCPaging GetPPCPager(SmPPC sm, int page, int rows)
        {
            VmPPCPaging pager = new VmPPCPaging();
            using (var context = new FaoB2BEntities())
            {

                var user = baseUserService.GetCurrentUserInfo(context);
                PPC entity = new PPC();
                if (user != null)
                {
                    entity.IntCreateUserID = user.UserID;
                }

                var list = context.Database.SqlQuery<VmPPC>("ProcGetPPCList  @p0,@p1,@p2,@p3,@p4,@p5", sm.WordKey == null ? "" : sm.WordKey, sm.Type, sm.state, user.UserID, page, rows);

                pager.total = context.Database.SqlQuery<int>("ProcGetPPCListCount @p0,@p1,@p2,@p3", sm.WordKey == null ? "" : sm.WordKey, sm.Type,sm.state, user.UserID).FirstOrDefault();

                pager.rows = list.Select(u => new VmPPC
                    {
                        EncryptID = Security.Encrypt(u.EncryptID),
                        DecValue = u.DecValue,
                        DteValid = u.DteValid,
                        IntTablePrimkeyID = u.IntTablePrimkeyID,
                        IntWordType = u.IntWordType,
                        VarKeyword = u.VarKeyword,
                        StrCreateDate =u.StrCreateDate,
                        StrValidDate = Utils.GetDateTimeFormate(u.DteValid),
                        WordTypeName = Enum.GetName(typeof(EnumInfoType), u.IntWordType),
                        Flag = u.Flag,
                        Title=u.Title

                    }).ToList();
            }
            return pager;
        }


        /// <summary>
        /// 改变状态
        /// </summary>
        /// <param name="state"></param>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        public string ChangeFlag(int state, string EncryptID)
        {
            string strID = Security.Decrypt(EncryptID);
            int id = 0;
            if (!int.TryParse(strID, out id))
            {
                return "未提到该信息";
            }
            string str = null;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.PPCs.Find(id);
                entity.IntFlag = state;
                int flag = context.SaveChanges();
                if (flag >= 0)
                {
                    str = "1";
                }
                else
                {
                    str = "设置失败";
                }
            }
            return str;
        }

        /// <summary>
        /// 扣除竞价费用
        /// </summary>
        /// <param name="ppc">竞价ID</param>
        /// <returns></returns>
        public int DeductionForExpenses(string ppc)
        {
            int rv = 0;
            using (var context = new FaoB2BEntities())
            {  
                int ppcID = Utils.ToInt(ppc);
                string ip = Utils.CurrentRequestIP();

                //如果该条推广信息是当前登录用户推广的，不收费 
                var currentUser = baseUserService.CurrentUser();
                if (currentUser != null)
                {
                    if (Many(context.PPCs, new PPC { IntPPCID = ppcID, IntCreateUserID = currentUser.IntUserID }).Count() > 0)
                    {
                        return rv;
                    }
                }
                     

                //当天，一个ip只能对同一个竞价id做一次扣费。
                if (ppcRecordService.Many(context.PPCRecords, new PPCRecord
                {
                    IntPPCID = ppcID,
                    DateCreate = DateTime.Now.Date,
                    VarVisitIP = ip
                }).Count() >= 1)
                {
                    rv = 0;
                }
                else
                {
                    //需要扣费的金额
                    var val = One(context.PPCs, new PPC
                    {
                        IntPPCID = ppcID
                    }).DecValue;

                    //扣费
                    if (context.Database.SqlQuery<int>("ProcDeductionForExpenses @p0,@p1,@p2,@p3", ppcID, val, ip, Utils.IpToInt(ip).ToString()).First() == 1)
                    {
                        rv = 1;
                        ////添加扣费记录
                        //context.PPCRecords.Add(new PPCRecord
                        //{
                        //    DateCreate = DateTime.Now,
                        //    IntFlag = 1,
                        //    IntPPCID = ppcID,
                        //    VarVisitIP = ip,
                        //    VarVisitIPValue = Utils.IpToInt(ip).ToString(),
                        //    DecDeduction = val

                        //});

                        //rv = context.SaveChanges();
                    }
                }

            }
            return rv;
        }



        /// <summary>
        /// 竞价记录分页数据
        /// </summary>
        /// <param name="searchModel"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageCount"></param>
        /// <returns></returns>
        public VMPPCRecordPaging GetPPCRecordsWithPage(SmPPCRecord searchModel, int pageIndex, int pageCount)
        {
            VMPPCRecordPaging page = new VMPPCRecordPaging();
            using (var context = new FaoB2BEntities())
            {
                var record = ppcRecordService.Many(context.PPCRecords, null);
                var user = baseUserService.CurrentUser(context.BaseUsers);
                var ppc = Many(context.PPCs, null);

                var entities = from r in record
                               join p in ppc on r.IntPPCID equals p.IntPPCID
                               where p.IntCreateUserID == user.IntUserID
                               select new
                               {
                                   DateCreate = r.DateCreate,
                                   DecDeduction = r.DecDeduction,
                                   PPCID = p.IntPPCID,
                                   PPCRecordID = r.IntPPCRecordID,
                                   KeyWord = p.VarKeyword
                               };
                page.total = entities.Count();

                var rows = entities.OrderByDescending(r => r.PPCRecordID).Skip((pageIndex - 1) * pageCount).Take(pageCount).ToList();

                page.rows = rows.Select((r,i) => new VmPPCRecord
                {
                    DateCreate = r.DateCreate.ToString("yyyy-MM-dd HH:mm:ss"),
                    DecDeduction = r.DecDeduction,
                    PPCID = r.PPCID,
                    PPCRecordID = i +1,
                    Content = string.Format("{0} 竞价推广", r.KeyWord)
                }).ToList();
            }
            return page;
        }


        /// <summary>
        /// 得到用户出价列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VmPPCPaging GetPPCPaging(SmPPC sm, int page, int rows)
        {
            string hotword = sm.WordKey == null ? string.Empty : sm.WordKey;
            int wordtype = sm.Type;
            DateTime startTime, endTime;
            if (!DateTime.TryParse(sm.StartTime, out startTime))
            {
                startTime = DateTime.Parse("1/1/1753 12:00:00");
            }
            if (!DateTime.TryParse(sm.EndTime, out endTime))
            {
                endTime = DateTime.MaxValue;
            }
            if (endTime != DateTime.MaxValue)
            {
                endTime = endTime.AddDays(1);
            }
            VmPPCPaging list = new VmPPCPaging();
            using (var context = new FaoB2BEntities())
            {
                list.rows = context.Database.SqlQuery<VmPPC>("ProcPPCList @p0,@p1,@p2,@p3,@p4,@p5", hotword, wordtype, startTime, endTime, page, rows).ToList();
                list.total = context.Database.SqlQuery<int>("ProcPPCListCount @p0,@p1,@p2,@p3", hotword, wordtype, startTime, endTime).FirstOrDefault();
            }
            list.rows.ForEach(l => l.DecValue = decimal.Round(l.DecValue, 2));
            return list;
        }
        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(PPC entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(PPC entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(PPC entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public PPC One(IQueryable<PPC> query, PPC entity)
        {
            if (entity != null)
            {
                return query.FirstOrDefault(e => e.IntPPCID == entity.IntPPCID);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<PPC> Many(IQueryable<PPC> query, PPC entity)
        {
            var entities = query.Select(e => e);
            entities = entities.Where(e => e.IntFlag != 0);
            if (entity != null)
            {
                if (entity.IntCreateUserID != 0)
                {
                    entities = entities.Where(p => p.IntCreateUserID == entity.IntCreateUserID);
                }
                if (entity.IntFlag != 0)
                {
                    entities = entities.Where(p => p.IntFlag == entity.IntFlag);
                }
                if (!string.IsNullOrWhiteSpace(entity.VarKeyword))
                {
                    entities = entities.Where(p => p.VarKeyword.Contains(entity.VarKeyword));
                }
                if (entity.IntWordType != 0)
                {
                    entities = entities.Where(p => p.IntWordType == entity.IntWordType);
                }
            }

            return entities;
        }

        #endregion

    }
}
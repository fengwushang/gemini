﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Category服务实现-Power by CodeGG
    /// </summary>
    public class CategoryService : Entity<Category>, ICategoryService
    {

        #region 业务接口引用

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmCategory查询模型，返回VmCategory视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmCategory> GetCategorys(SmCategory searchModel)
        {
            var catList = new List<VmCategory>();
            using (var context = new FaoB2BEntities())
            {
                var list = Many(context.Categories, null).Where(p => p.IntCategoryParentId == searchModel.ParentID).OrderBy(p => p.IntOrderID);
                var vmList = new List<VmCategory>();
                foreach (var item in list)
                {
                    vmList.Add(GetVMFrom(item));
                }
                catList= vmList;
            }
            return catList;
        }

        /// <summary>
        /// 根据id，返回VmCategory视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmCategory GetCategoryByID(int id)
        {
            var vmCate = new VmCategory();
            using (var context = new FaoB2BEntities())
            {
                var entity = context.Categories.Find(id);
                vmCate = GetVMFrom(entity);
            }
            return vmCate;
        }

        /// <summary>
        /// 添加分类项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddCategory(VmCategory model)
        {
            string str;
            using (var context = new FaoB2BEntities())
            {
                var adminID = HtmlHelper.GetCookieValue("AdminID");
                string name = model.CatogoryName;
                int parentID = model.ParentID;
                var e = Many(context.Categories, null).Where(p => p.VarCategoryName == name && p.IntCategoryParentId == parentID).Count();
                if (e > 0)
                {
                    str = "该分类名称已存在"; 
                }
                else
                {
                    int orderID = Many(context.Categories, null).Where(p => p.IntCategoryParentId == model.ParentID).Count();
                    Category entity = GetEntityFrom(model);
                    entity.IntOrderID = orderID + 1;
                    entity.IntCreateUserID = Utils.ToInt(adminID);
                    context.Categories.Add(entity);
                    //AddToEntity(entity);
                    int flag = context.SaveChanges();// Save();

                    if (flag >= 0)
                    {
                        //添加成功，修改varSearch字段。父级分类直接添加为自身id，否则添加其父级varSearch + ',' + 自身id
                        if (parentID == 0)
                        {
                            entity.VarSearch = "," + entity.IntCategoryId.ToString() + ",";
                        }
                        else
                        {
                            entity.VarSearch = One(context.Categories, new Category
                            {
                                IntCategoryId = parentID
                            }).VarSearch + entity.IntCategoryId + ',';
                        }
                        context.SaveChanges();
                        //Save();
                        str = "1";
                    }
                    else 
                        str = "保存失败";
                }
            }
            return str;
        }

        /// <summary>
        /// 修改分类项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string Updatecategory(VmCategory model)
        {
            string str;
            using (var context = new FaoB2BEntities())
            {
                if (model == null)
                {
                    str = "保存失败";
                }
                else
                {
                    string name = model.CatogoryName;
                    int parentID = model.ParentID;
                    int id = model.CategoryID;
                    var e = Many(context.Categories, null).Where(p => p.VarCategoryName == name && p.IntCategoryParentId == parentID && p.IntCategoryId != id).Count();
                    if (e > 0)
                    {
                        str = "该行业名称已存在";
                    }
                    else
                    {
                        var entity = context.Categories.Find(model.CategoryID);
                        if (entity != null)
                        {
                            entity.VarCategoryName = model.CatogoryName;
                            entity.VarCategoryAbbName = model.Abbreviation;
                            int flag = context.SaveChanges();// Save();
                            if (flag >= 0)
                            {
                                str = "1";
                            }
                            else 
                                str = "保存失败";
                        }
                        else 
                            str = "保存失败";
                    }
                }
            }
            return str;
        }

        /// <summary>
        /// 删除分类项
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int DeleteCategory(int id)
        {
            int flag;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.Categories.Find(id);
                if (entity == null)
                {
                    flag = 1;
                }
                else
                {
                    entity.IntFlag = 0;
                    flag = context.SaveChanges();// Save();
                }
            }
            return flag;
        }

        /// <summary>
        /// 分类项上移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        public string ItemUP(int ItemID)
        {
            string str;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.Categories.Find(ItemID);
                if (entity != null)
                {
                    if (entity.IntOrderID > 1)
                    {
                        entity.IntOrderID--;
                        var pre = Many(context.Categories, null).Where(p => p.IntCategoryParentId == entity.IntCategoryParentId && p.IntOrderID == entity.IntOrderID).FirstOrDefault();
                        if (pre != null)
                        {
                            pre.IntOrderID++;
                        }
                    }
                    else
                    {
                        str = "该项已经是第一位，不能再移了";
                    }
                    int flag = context.SaveChanges();// Save();
                    if (flag >= 0)
                    {
                        str = "1";
                    }
                    else
                    {
                        str = "-1";
                    }
                }
                else
                    str = "";
            }
            return str;
        }

        /// <summary>
        /// 分类项下移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        public string ItemDown(int ItemID)
        {
            string str;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.Categories.Find(ItemID);
                if (entity != null)
                {
                    var max = Many(context.Categories, null).Where(p => p.IntCategoryParentId == entity.IntCategoryParentId).Max(p => p.IntOrderID);
                    if (entity.IntOrderID < max)
                    {
                        entity.IntOrderID++;
                        var pre = Many(context.Categories, null).Where(p => p.IntCategoryParentId == entity.IntCategoryParentId && p.IntOrderID == entity.IntOrderID).FirstOrDefault();
                        if (pre != null)
                        {
                            pre.IntOrderID--;
                        }
                    }
                    else
                    {
                        str = "该项已经是最后一位，不能再移了";
                    }
                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        str = "1";
                    }
                    else
                    {
                        str = "-1";
                    }
                }
                else 
                    str = "";
            }
            return str;
        }
        #endregion

        #region 辅助方法

        /// <summary>
        /// 把数据库实例转换成VM实例
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private VmCategory GetVMFrom(Category entity)
        {

            if (entity == null)
            {
                return null;
            }
            var vm = new VmCategory()
            {
                CategoryID = entity.IntCategoryId,
                ParentID = entity.IntCategoryParentId,
                CatogoryName = entity.VarCategoryName,
                state = "closed",
                _parentId = entity.IntCategoryParentId,
                Abbreviation = entity.VarCategoryAbbName
            };

            return vm;

        }

        /// <summary>
        /// 把VM实例转化成数据库实例
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private Category GetEntityFrom(VmCategory model)
        {
            if (model == null)
            {
                return null;
            }
            var entity = new Category()
            {
                IntCategoryId = model.CategoryID,
                IntCategoryParentId = model.ParentID,
                VarCategoryName = model.CatogoryName,
                VarCategoryAbbName = model.Abbreviation,
                IntLayerID = 0,
                VarSearch = "",
                IntFlag = 1,
                IntOrderID = 0,
                DteCreate = DateTime.Now,
                IntCreateUserID = 0
            };
            return entity;
        }
        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(Category entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(Category entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(Category entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public Category One(IQueryable<Category> query, Category entity)
        {
            var category = new Category();
            if (entity != null)
            {
                if (entity.IntCategoryId != 0)
                {
                    category = query.FirstOrDefault(e => e.IntCategoryId == entity.IntCategoryId);
                }
            }
            return category;
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<Category> Many(IQueryable<Category> query, Category entity)
        {
            return query.Where(p => p.IntFlag == 1);
        }

        #endregion

    }
}
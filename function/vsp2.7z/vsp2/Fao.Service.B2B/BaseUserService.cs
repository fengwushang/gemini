﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.MV;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// BaseUser服务实现-Power by CodeGG 
    /// </summary>
    public class BaseUserService : Entity<BaseUser>, IBaseUserService
    {


        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IUserExtensionService userExtensionService = new UserExtensionService();
        IBaseLogService baseLogService = new BaseLogService();
        IBasePlatformService basePlatformService = new BasePlatformService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmBaseUser查询模型，返回VmBaseUser视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmBaseUser> GetBaseUsers(SmBaseUser searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmBaseUser视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmBaseUser GetBaseUserByID(string id)
        {
            var vmBaseuser = new VmBaseUser();
            //string str = HtmlHelper.GetCookieValue("UserID");
            //int userid = Utils.ToInt(Security.Decrypt(str));
            using (var context = new FaoB2BEntities())
            {
                vmBaseuser = context.Database.SqlQuery<VmBaseUser>("ProcGetUserDetail @p0", (Utils.ToInt(Security.Decrypt(HtmlHelper.GetCookieValue("B2B_UserID"))))).FirstOrDefault();
                //var user = context.BaseUsers.Where(p => p.IntUserID == userid).FirstOrDefault();
                //vmBaseuser.UserName = user.VarRealName;
                //vmBaseuser.UserNickName = user.VarNickName;
            }
            return vmBaseuser;
        }


        /// <summary>
        /// 验证用户名称密码是否正确
        /// </summary>
        /// <param name="userName">用户名aram>
        /// <param name="passWord">密码</param>
        /// <param name="error">错误</param>
        /// <returns></returns>
        public bool ValidateUser(string userName, string passWord, ref NameValueCollection error)
        {
            bool flag = false;
            using (var context = new FaoB2BEntities())
            {
                //被禁用和已删除的用户不能登录,冻结用户给予提示
                string encryptpassword = Security.MD5(passWord);
                BaseUser entity = context.BaseUsers.Where(p => (p.VarEmail == userName || p.VarPhone == userName || p.VarNickName == userName) && p.VarPWD == encryptpassword && p.IntFlag > 0).FirstOrDefault();
 
                if (entity == null)
                {
                    entity = new BaseUser { IntFlag = 0 };
                }
                switch (entity.IntFlag)
                {
                    case 0: 
                        {
                            flag = false;
                            error.Add("UserName", "用户名或密码填写错误！");
                            break;
                        }
                    case 1:
                        {
                            flag = false;
                            error.Add("UserName", "该用户尚未激活！");
                            break;
                        }
                    case 2:
                        {
                            flag = true;
                            break;
                        }
                    case 3:
                        {
                            flag = false;
                            error.Add("UserName", "账户已经被冻结！");
                            break;
                        }
                }
            }
            return flag;
        }

        /// <summary>
        /// 用户登陆
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="autoLogin"></param>
        public void Login(string userName, string password, bool autoLogin)
        {
            using (var context = new FaoB2BEntities())
            {
                string encryptpassword = Security.MD5(password);
                BaseUser user = context.BaseUsers.Where(p => (p.VarEmail == userName || p.VarPhone == userName || p.VarNickName == userName) && p.VarPWD == encryptpassword).SingleOrDefault();

                //如果登录成功，利用cookie保存用户信息
                if (user != null)
                {
                    SetLoginCookies(user, autoLogin);
                    var vmBaseLog = new VmBaseLog
                    {
                        DateCreate = DateTime.Now,
                        IntLogType = 1,
                        IntPlatform = 4,
                        VarModel = "登陆页面",
                        VarIP = Utils.CurrentRequestIP(),
                        VarInfo = user.VarEmail,
                        IntUserID = user.IntUserID
                    };
                    baseLogService.WriteLog(context, vmBaseLog);
                }
            }
        }

        /// <summary>
        /// 登录后设置Cookies
        /// </summary>
        /// <param name="user"></param>
        /// <param name="autoLogin"></param>
        public void SetLoginCookies(BaseUser user, bool autoLogin)
        {
            string userName = string.IsNullOrEmpty(user.VarRealName) ? (string.IsNullOrEmpty(user.VarPhone) ? user.VarEmail : user.VarPhone) : user.VarRealName;
            //如果手机号、登录名称不存在，显示昵称
            if (string.IsNullOrEmpty(userName) || userName == "0                   ")
                userName = user.VarNickName;
            if (autoLogin)
            {
                Fao.Common.HtmlHelper.SetCookie("B2B_UserID", Security.Encrypt(user.IntUserID));
                Fao.Common.HtmlHelper.SetCookie("B2B_UserName", HttpUtility.UrlEncode(userName));
                Fao.Common.HtmlHelper.SetCookie("B2B_UserEmail", user.VarEmail);
            }
            else
            {
                Fao.Common.HtmlHelper.SetCookie("B2B_UserID", Security.Encrypt(user.IntUserID), DateTime.Now.AddDays(1));
                Fao.Common.HtmlHelper.SetCookie("B2B_UserName", HttpUtility.UrlEncode(userName), DateTime.Now.AddDays(1));
                Fao.Common.HtmlHelper.SetCookie("B2B_UserEmail", user.VarEmail, DateTime.Now.AddDays(1));
            }
        }

        /// <summary>
        /// 注册用户
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int RegisterUser(VmRegister model)
        {
            int rv = -1;
            using (var context = new FaoB2BEntities())
            {
                BaseUser user = GetBaseUserFrom(model);
                int count = context.BaseUsers.Where(p => p.VarEmail == model.Email).Count();
                if (count > 0)
                    rv = -1;
                else
                {

                    user.VarEmailVerifyCode = ValidateCode.CreateRandNum(5);
                    int hours = Utils.ToInt(ConfigurationManager.AppSettings["DteEmailValid"]);
                    user.DteEmailVerifyValid = System.DateTime.Now.AddHours(hours);
                    user.IntEmailVerify = 2;
                    user.IntFlag = 1;

                    context.BaseUsers.Add(user);
                    int flag = context.SaveChanges();
                    
                    if (flag > 0)
                    {
                        Thread tsEmail = new Thread(new ParameterizedThreadStart(SendVerMail));
                        tsEmail.Start(user);
                    }

                    rv = user.IntUserID;
                }
            }
            //注册成功 返回用户id
            return rv;
        }

        /// <summary>
        /// 发送验证邮件。注册时做邮箱号码唯一性判断
        /// 验证后，激活该用户
        /// </summary>
        /// <param name="user"></param>
        private void SendVerMail(object user)
        {
            BaseUser RUser = user as BaseUser;
            string domain = ConfigurationManager.AppSettings["Domain"];
            SendMail.MailContent mc = new SendMail.MailContent();
            mc.emailAdd = RUser.VarEmail;
            mc.emailSub = "金谷高科注册--邮箱验证邮件";
            mc.EmailBody = string.Format(@"<font face=Arial size=2>亲爱的用户：<br/>&nbsp;&nbsp;&nbsp;&nbsp;您好！<br/>&nbsp;&nbsp;&nbsp;&nbsp;
            欢迎您成为金谷高科中的一员！&nbsp;&nbsp;&nbsp;&nbsp;点击：<a href='http://{0}/Login/RegisterVer?code={1}&uid={2}'  target='_blank'>激活</a>您的账户。
或者把如下链接粘贴到您的浏览器地址栏中,并点回车键：&nbsp;http://{0}/Login/RegisterVer?code={1}&uid={2}<br/>
&nbsp;&nbsp;&nbsp;&nbsp;注意：该邮件无需回复！<br/><br/>北京金谷高科科技有限公司<br/>发送时间：{3}</font>", 
             domain, Security.Encrypt(RUser.VarEmailVerifyCode), Security.Encrypt(RUser.IntUserID), DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));

            

           // FileInfo file = new FileInfo(HttpRuntime.AppDomainAppPath.ToString()+"/11.text");
           // if (!file.Exists)
           // {
           //     file.Create();
           // }
           // File.WriteAllText(HttpRuntime.AppDomainAppPath.ToString() + "/11.text", string.Empty);
           //File.WriteAllText(HttpRuntime.AppDomainAppPath.ToString() + "/11.text", string.Format("href={0}/Login/RegisterVer?code={1}&uid={2}",domain, Security.Encrypt(RUser.VarEmailVerifyCode), Security.Encrypt(RUser.IntUserID)));
            SendMail.SEmail(mc);
        }

        /// <summary>
        /// 邮箱激活验证
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int VerifyUserMail(VmRegister model)
        {
            int flag;
            using (var context = new FaoB2BEntities())
            {
                int uid = Utils.ToInt(Security.Decrypt(model.UserID));
                string verMail = Security.Decrypt(model.EmailVerifyCode);
                int count = context.BaseUsers.Where(p => p.IntUserID == uid && p.VarEmailVerifyCode == verMail && p.DteEmailVerifyValid >= System.DateTime.Now).Count();
                if (count > 0)
                {
                    var user = context.BaseUsers.Find(uid);
                    user.VarEmailVerifyCode = "";
                    user.IntEmailVerify = 1;
                    user.IntFlag = 2;
                    user.DteEmailVerifyValid = System.DateTime.Now;
                    flag = context.SaveChanges();
                    if (flag > 0)
                    {
                        flag = 1;

                        try
                        {
                            AuthenCheck.AuthenPassportClient AU = new AuthenCheck.AuthenPassportClient();
                            //HRWcf.HrRegisterUserWcfClient hrWcf = new HRWcf.HrRegisterUserWcfClient();
                            //查询出刚注册的用户id
                            BaseUser entity = context.BaseUsers.Where(p => p.IntUserID == uid && p.IntFlag > 0).FirstOrDefault();

                            //用户信息字符串
                            string psUser = entity.VarPhone + "," + entity.VarEmail + "," + entity.VarPWD + "," + entity.IntEmailVerify + "," + entity.DteEmailVerifyValid + "," + entity.VarEmailVerifyCode + "," + entity.IntUserGroup + "," + entity.IntUserID;
                            //向ps中注册用户信息 
                            int UIDp = AU.B2BToPsUser(psUser);

                            //将PS注册成功的信息写回本平台
                            IBasePlatformService PlatAdd = new BasePlatformService();
                            BasePlatform PlatB2B = new BasePlatform();
                            PlatB2B.IntCreateUserID = entity.IntUserID;
                            PlatB2B.IntTypeID = 3;  //平台标识：1 B2B，2 HR，3PS
                            PlatB2B.IntUserID = UIDp;
                            PlatB2B.IntFlag = 1;
                            PlatB2B.DteCreate = System.DateTime.Now;
                            PlatB2B.DteUpdate = System.DateTime.Now;
                            PlatAdd.AddBasePlatform(PlatB2B);

                            //向HR中注册用户
                            //string hrUser = entity.VarEmail + "," + entity.VarPhone + "," + entity.VarPWD + "," + entity.IntUserGroup.ToString();
                            int UIDhr = 0;// hrWcf.AddUser(hrUser);

                            ////将Hr注册成功的信息写回本平台   2013年8月28日17:11:56  屏蔽HR
                            //PlatB2B.IntCreateUserID = entity.IntUserID;
                            //PlatB2B.IntTypeID = 2;  //平台标识：1 B2B，2 HR，3PS
                            //PlatB2B.IntUserID = UIDhr;
                            //PlatB2B.IntFlag = 1;
                            //PlatB2B.DteCreate = System.DateTime.Now;
                            //PlatB2B.DteUpdate = System.DateTime.Now;
                            //PlatAdd.AddBasePlatform(PlatB2B);

                            //将B2B，HR用户信息写回PS库  str + "," + "2.3," + strh + "." + Security.Decrypt(uid)
                            AU.InsertOtherPlatform(UIDp + "," + "1.2," + entity.IntUserID + "." + UIDhr);

                            //将B2B，PS用户信息写回HR库
                           // hrWcf.InsertOtherPlatform(UIDhr + "," + "1.3," + entity.IntUserID + "." + UIDp);
                        }
                        catch
                        { }
                    }
                    else
                    {
                        flag = 2;
                    } 
                }
                else
                    flag = 0;
            }
            return flag;
        }


        /// <summary>
        /// 检查Email是否补注册
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public int CheckEmail(string email)
        {
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                var user = CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    flag = context.BaseUsers.Where(p => p.VarEmail == email && p.IntUserID != user.IntUserID).Count();
                }
                else
                {
                    flag = context.BaseUsers.Where(p => p.VarEmail == email).Count();
                }
                if (flag > 0)
                    flag = 1;
                else
                    flag = 0;
            }
            return flag;
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="email"></param>
        /// <param name="NewPassword"></param>
        /// <param name=""></param>
        /// <returns></returns>
        public int ChangPassword(string Email, string NewPassword, string OldPassword)
        {
            int flag = -2;
            using (var context = new FaoB2BEntities())
            {
                BaseUser user = null;
                string encryptpassword = Security.MD5(NewPassword);
                if (!string.IsNullOrWhiteSpace(Email))
                {
                    user = context.BaseUsers.Where(p => p.VarEmail == Email).FirstOrDefault();
                    if (user == null)
                    {
                        flag = -1;
                    }
                }
                else
                {
                    user = CurrentUser(context.BaseUsers);
                    if (user != null)
                    {
                        if (user.VarPWD == Security.MD5(OldPassword))
                        {
                            user.VarPWD = encryptpassword;
                            flag = context.SaveChanges();
                        }
                        else
                            flag = -1;
                    }
                }
            }
            return flag;
        }

        /// <summary>
        ///登出
        /// </summary>
        public void Logout()
        { 
            Fao.Common.HtmlHelper.ClearCookie("B2B_UserID");
            Fao.Common.HtmlHelper.ClearCookie("B2B_UserName");
            Fao.Common.HtmlHelper.ClearCookie("B2B_UserEmail"); 
        }

        /// <summary>
        /// 得到当前用户
        /// </summary>
        /// <returns></returns>
        public BaseUser CurrentUser()
        {
            var buser = new BaseUser();
            using (var context = new FaoB2BEntities())
            {
                buser = CurrentUser(context.BaseUsers);
            }
            return buser;
        }

        /// <summary>
        /// 得到当前用户
        /// </summary>
        /// <returns></returns>
        public BaseUser CurrentUser(IQueryable<BaseUser> query)
        {

            var encryptUserID = Fao.Common.HtmlHelper.GetCookieValue("B2B_UserID");
            if (!string.IsNullOrWhiteSpace(encryptUserID))
            {
                var userid = Security.Decrypt(encryptUserID);
                var userID = Utils.ToInt(userid); 
                var user = query.Where(u => u.IntUserID == userID).FirstOrDefault(); 
                return user;
            }
            else
            {
                return null;
            } 
        }

        /// <summary>
        /// 获取当前用户id
        /// </summary>
        /// <returns></returns>
        public string CurrentUserID()
        {
            var encryptUserID = Fao.Common.HtmlHelper.GetCookieValue("B2B_UserID");
            if (!string.IsNullOrWhiteSpace(encryptUserID))
            {
                return Security.Decrypt(encryptUserID);
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        /// 获得当前用户信息及扩展信息
        /// </summary>
        /// <returns></returns>
        public VMUserInfo GetCurrentUserInfo()
        {
            var uInfo = new VMUserInfo();
            using (var context = new FaoB2BEntities())
            {
                uInfo = GetCurrentUserInfo(context);
            }
            return uInfo;
        }

        /// <summary>
        /// 获得当前用户信息及扩展信息
        /// </summary>
        /// <returns></returns>
        public VMUserInfo GetCurrentUserInfo(FaoB2BEntities context)
        {
            VMUserInfo vm = new VMUserInfo();
            BaseUser currentUser = CurrentUser(context.BaseUsers);
            UserExtension userExt = new UserExtension();

            if (currentUser != null)
            {
                vm.NickName = string.IsNullOrEmpty(currentUser.VarNickName) ? "" : currentUser.VarNickName.Trim();
                vm.RealName = string.IsNullOrEmpty(currentUser.VarRealName) ? "" : currentUser.VarRealName.Trim();
                vm.Phone = string.IsNullOrEmpty(currentUser.VarPhone) ? "" : currentUser.VarPhone.Trim();
                vm.IntPhoneVerify = currentUser.IntPhoneVerify.GetValueOrDefault(0);
                vm.Email = string.IsNullOrEmpty(currentUser.VarEmail) ? "" : currentUser.VarEmail.Trim();
                vm.UserID = currentUser.IntUserID;

                userExt.IntUserID = currentUser.IntUserID;
                var listExt = userExtensionService.Many(context.UserExtensions, userExt).ToList();

                if (listExt.Count > 0)
                {
                    userExt = listExt[0];
                    vm.Age = userExt.IntAge;
                    vm.ExtensionID = userExt.IntExtensionID;
                    vm.QQ = userExt.VarQQ;
                    vm.Sex = userExt.IntSex;
                }
            }
            return vm;
        }

        /// <summary>
        /// 修改当前用户的手机，手机验证码
        /// </summary>
        /// <param name="vm"></param>
        /// <returns></returns>
        public string UpdateUserPhone(VMUserInfo vm)
        {
            string str;
            using (var context = new FaoB2BEntities())
            {
                var user = CurrentUser(context.BaseUsers);
                if (user == null)
                {
                    str = "用户未登陆";
                }
                else
                {
                    user.VarPhone = vm.Phone;
                    user.IntPhoneVerify = vm.IntPhoneVerify;

                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        str = "1";
                    }
                    else 
                        str = "保存失败";
                }
            }
            return str;
        }


        /// <summary>
        /// 修改用户的邮箱 或手机
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="MailOrPhone"></param>
        /// <returns></returns>
        public string UpdateUserMail(int uid, string MailOrPhone)
        {
            string re = "0";
            using (var context = new FaoB2BEntities())
            {
                string mail = MailOrPhone.Split(',')[0].ToString();
                string phone = MailOrPhone.Split(',')[1].ToString();

                //修改邮箱
                if (mail.Length > 0)
                {
                    var user = context.BaseUsers.Where(p => p.IntUserID != uid && (p.VarEmail == mail && p.VarEmail.Length > 0)).FirstOrDefault();
                    if (user == null)
                    {
                        user = context.BaseUsers.Where(p => p.IntUserID == uid).FirstOrDefault();
                        if (user != null)
                        {
                            user.VarEmail = mail;
                            re = context.SaveChanges().ToString();
                        }
                    }
                }

                //修改手机
                if (phone.Length > 0)
                {
                    var user = context.BaseUsers.Where(p => p.IntUserID != uid && (p.VarPhone == phone && p.VarPhone.Length > 0)).FirstOrDefault();
                    if (user == null)
                    {
                        user = context.BaseUsers.Where(p => p.IntUserID == uid).FirstOrDefault();
                        if (user != null)
                        {
                            user.VarPhone = phone;
                            re = context.SaveChanges().ToString();
                        } 
                    }
                } 
            }
            return re;
        }


        /// <summary>
        /// 修改当前用户信息及扩展信息
        /// </summary>
        /// <param name="vm"></param>
        /// <returns></returns>
        public string UpadateUserInfo(VMUserInfo vm)
        {
            int re = 0;
            string str;
            using (var context = new FaoB2BEntities())
            {
                var user = CurrentUser(context.BaseUsers);

                if (user == null)
                {
                    str = "用户未登陆";
                }

                else
                {
                    int count = context.BaseUsers.Where(p => p.VarEmail == vm.Email && p.IntUserID != user.IntUserID).Count();
                    if (count > 0)
                    {
                        str = "该邮箱已被注册";
                    }

                    else
                    { 
                        user.VarRealName = vm.RealName;
                        user.VarNickName = vm.NickName;

                        if (user.VarEmail != vm.Email || user.VarPhone != vm.Phone)
                            re = 1;

                        user.VarEmail = vm.Email;
                         
                        if (vm.ExtensionID == 0)
                        {
                            UserExtension userExt = new UserExtension()
                            {
                                IntUserID = vm.UserID,
                                IntAge = vm.Age??0,
                                IntExtensionID = vm.ExtensionID,
                                IntFlag = 2,
                                IntIndustryID = 1,
                                IntAreaID = 1,
                                IntSex = vm.Sex??0,
                                VarQQ = vm.QQ==null?string.Empty:vm.QQ,
                                BaseUser = user,
                                VarUserAddress = "",
                            };
                            context.UserExtensions.Add(userExt); 
                        }
                        else
                        {
                            UserExtension userExt = userExtensionService.One(context.UserExtensions, new UserExtension() { IntExtensionID = vm.ExtensionID });

                            userExt.IntAge = vm.Age??0;
                            userExt.IntIndustryID = 1;
                            userExt.IntAreaID = 1;
                            userExt.IntSex = vm.Sex??0;
                            userExt.VarQQ = vm.QQ==null?string.Empty:vm.QQ;
                            userExt.BaseUser = user;
                            userExt.VarUserAddress = "";

                        }

                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            str = "1";
                            if (re == 1)
                            {
                                try
                                {
                                    //平台标识：1 B2B，2 HR，3 PS
                                    //修改PS用户
                                    int uid = 0;
                                    AuthenCheck.AuthenPassportClient PS = new AuthenCheck.AuthenPassportClient();
                                    uid = basePlatformService.GetPlatformID(vm.UserID, 3);
                                    if (uid > 0)
                                    {
                                        PS.ChangeMailOrPhone(uid.ToString(), vm.Email + ',' + vm.Phone);
                                    }
                                    ////修改HR
                                    //HRWcf.HrRegisterUserWcfClient HR = new HRWcf.HrRegisterUserWcfClient();
                                    //uid = basePlatformService.GetPlatformID(vm.UserID, 2);
                                    //if (uid > 0)
                                    //{
                                    //    HR.ChangeMailOrPhone(uid.ToString(), vm.Email + ',' + vm.Phone);
                                    //}
                                }
                                catch
                                { }
                            }
                        }
                        else
                            str = "保存失败";
                    }
                }
            }
            return str;
        }
         
        #endregion


        #region 辅助方法

        /// <summary>
        /// 从VM中获得数据库实体
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private BaseUser GetBaseUserFrom(VmRegister model)
        {
            string encryptpassword = Security.MD5(model.Password);

            BaseUser user = new BaseUser()
            {
                VarNickName = model.Email,
                VarEmail = model.Email,
                VarPWD = encryptpassword,
                IntFlag = 1,
                VarPhone = ""
            };
            return user;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(BaseUser entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(BaseUser entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(BaseUser entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public BaseUser One(IQueryable<BaseUser> query, BaseUser entity)
        {
            var bUser = new BaseUser();
            using (var context = new FaoB2BEntities())
            {
                if (entity != null)
                {
                    if (entity.IntUserID > 0)
                    {
                        //return Current.Find(entity.IntUserID);
                        bUser = query.FirstOrDefault(t => t.IntUserID == entity.IntUserID);
                    }
                }
            }
            return bUser;
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<BaseUser> Many(IQueryable<BaseUser> query, BaseUser entity)
        {
            var users = query.Select(u => u);

            if (entity != null)
            {

            }

            return users;
        }

        #endregion

    }
}
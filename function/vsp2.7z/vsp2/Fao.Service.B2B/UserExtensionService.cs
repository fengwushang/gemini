﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// UserExtension服务实现-Power by CodeGG
    /// </summary>
    public class UserExtensionService : Entity<UserExtension>, IUserExtensionService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmUserExtension查询模型，返回VmUserExtension视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmUserExtension> GetUserExtensions(SmUserExtension searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmUserExtension视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmUserExtension GetUserExtensionByID(string id)
        {
            throw new Exception("没有实现");
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(UserExtension entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(UserExtension entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(UserExtension entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public UserExtension One(IQueryable<UserExtension> query, UserExtension entity)
        {
            UserExtension ext = new UserExtension();
            if (entity.IntExtensionID > 0)
            {
                ext = query.FirstOrDefault(t => t.IntExtensionID == entity.IntExtensionID);
            }
            return ext;
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<UserExtension> Many(IQueryable<UserExtension> query, UserExtension entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntUserID > 0)
                {
                    entities = entities.Where(e => e.IntUserID == entity.IntUserID);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// Attachment服务实现-Power by CodeGG
    /// </summary>
    public class AttachmentService : Entity<Attachment>, IAttachmentService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmAttachment查询模型，返回VmAttachment视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmAttachment> GetAttachments(FaoB2BEntities context, SmAttachment searchModel)
        {
            Attachment model = new Attachment();
            if (searchModel != null)
            {
                if (searchModel.IntBelongTable > 0)
                    model.IntBelongTable = searchModel.IntBelongTable;
                if (searchModel.IntBelongTablePrikeyID > 0)
                    model.IntBelongTablePrikeyID = searchModel.IntBelongTablePrikeyID;
            }

            var list = Many(context.Attachments, model).Select(a => new VmAttachment
            {
                ID = a.IntAttachmentID,
                BelongTable = a.IntBelongTable,
                PK = a.IntBelongTablePrikeyID,
                Descrip = a.VarDescrip,
                FileName = a.VarFileName,
                Path = a.VarFilePath
            }).ToList();
            return list;

        }

        /// <summary>
        /// 根据id，返回VmAttachment视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmAttachment GetAttachmentByID(FaoB2BEntities context, string id)
        {
            var entity = context.Attachments.Find(int.Parse(id));
            return new VmAttachment
            {
                ID = entity.IntAttachmentID,
                BelongTable = entity.IntBelongTable,
                Descrip = entity.VarDescrip,
                FileName = entity.VarFileName,
                Path = entity.VarFilePath,
                Flag = entity.IntFlag,
                Order = entity.IntOrder,
                PK = entity.IntBelongTablePrikeyID
            };
        }


        /// <summary>
        /// 通过主表ID得到该ID下的所有图片信息
        /// </summary>
        /// <param name="PK"></param>
        /// <returns></returns>
        public List<VmAttachment> GetAttachmentsByTablePK(FaoB2BEntities context, int PK, int type = 6)
        {
            var entity = new Attachment();
            entity.IntBelongTablePrikeyID = PK;
            entity.IntBelongTable = type;
            var list = Many(context.Attachments, entity).Select(p => new VmAttachment
            {
                ID = p.IntAttachmentID,
                PK = p.IntBelongTablePrikeyID,
                FileName = p.VarFileName,
                Path = p.VarFilePath,
                Order = p.IntOrder
            }).ToList();
            return list;
        }

        /// <summary>
        /// 通过主表和主键ID得到该ID下的所有图片信息
        /// </summary>
        /// <param name="PK"></param>
        /// <returns></returns>
        public List<VmAttachment> GetAttachmentsByTableAndPK(int PK, int tableID)
        {
            var attList = new List<VmAttachment>();
            using (var context = new FaoB2BEntities())
            {
                attList = GetAttachmentsByTablePK(context, PK, tableID);
            }

            return attList;
        }


        /// <summary>
        /// 通过BelongTablePrikeyID得到所有图片信息
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public IQueryable<Attachment> GetAttachmentsByTableType(int type)
        {
            IQueryable<Attachment> list = null;
            using (var context = new FaoB2BEntities())
            {
                var entity = new Attachment();
                entity.IntBelongTable = type;
                list = Many(context.Attachments, entity);

            }
            return list;
        }

        /// <summary>
        /// 返回指定信息id集合的对应主要附件url
        /// </summary>
        /// <param name="infoIDs">指定信息id集合</param>
        /// <returns></returns>
        public List<Attachment> GetMainAttachments(IQueryable<Attachment> query, IEnumerable<int> infoIDs)
        {
            var discInfoIDs = infoIDs.Distinct();
            var entities = Many(query, null)
                    .Where(e => discInfoIDs.Contains(e.IntBelongTablePrikeyID))
                    .OrderBy(e => e.IntOrder)
                    .GroupBy(g => g.IntBelongTablePrikeyID)
                    .Select(g => g.FirstOrDefault());
            var list = entities.ToList();
            var dbAttIDs = list.Select( a => a.IntBelongTablePrikeyID).ToList();
            foreach (var infoid in discInfoIDs)
            {
                if (!dbAttIDs.Contains(infoid))
                {
                    list.Add(new Attachment { 
                     IntBelongTablePrikeyID = infoid,
                     VarFilePath = "/content/Images/empty_info.gif"
                    });
                }
            }


            return list;

        }
        /// <summary>
        /// 添加附件
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddAttachment(FaoB2BEntities context, VmAttachment model)
        {
            var entity = new Attachment()
            {
                IntBelongTable = model.BelongTable,
                IntBelongTablePrikeyID = model.PK,
                VarFileName = model.FileName,
                VarFilePath = model.Path,
                VarDescrip = model.Descrip,
                DteCreate = DateTime.Now,
                IntOrder = model.Order,
                IntFlag = 1
            };
            context.Attachments.Add(entity);
            int flag = context.SaveChanges();
            if (flag >= 0)
            {
                return "1";
            }
            else
            {
                return "0";
            }
        }

        /// <summary>
        /// 更新附件
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateAttachment(FaoB2BEntities context, VmAttachment model)
        {
            var entity = context.Attachments.Find(model.ID);
            if (entity != null)
            {
                entity.VarFileName = model.FileName;
                entity.VarFilePath = model.Path;
                entity.VarDescrip = model.Descrip;
                entity.IntOrder = model.Order;
            }
            int flag = context.SaveChanges();
            if (flag >= 0)
            {
                return "1";
            }
            else
            {
                return "0";
            }
        }

        public string DeleteAttachment(FaoB2BEntities context, int id)
        {
            var entity = context.Attachments.Find(id);
            if (entity != null)
            {
                entity.IntFlag = 0;
                return context.SaveChanges().ToString();
            }
            return "1";

        }
        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(Attachment entity)
        {
            throw new Exception("没有实现");

        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(Attachment entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(Attachment entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public Attachment One(IQueryable<Attachment> query, Attachment entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<Attachment> Many(IQueryable<Attachment> query, Attachment entity)
        {
            var entities = query.OrderByDescending(e => e.IntOrder).Select(e => e);

            if (entity != null)
            {
                if (entity.IntBelongTable != 0)
                {
                    entities = entities.Where(p => p.IntBelongTable == entity.IntBelongTable);
                }
                if (entity.IntBelongTablePrikeyID != 0)
                {
                    entities = entities.Where(p => p.IntBelongTablePrikeyID == entity.IntBelongTablePrikeyID);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
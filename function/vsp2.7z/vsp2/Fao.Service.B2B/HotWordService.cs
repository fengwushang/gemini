﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;
using System.Threading;
using System.Xml.Linq;
using System.Xml.XPath;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// HotWord服务实现-Power by CodeGG
    /// </summary>
    public class HotWordService : Entity<HotWord>, IHotWordService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里 

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmHotWord查询模型，返回VmHotWord视图模型列表
        /// </summary> 
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图热词分页</returns>
        public VmHotWordList GetHotWords(int id)
        {
            VmHotWordList page = new VmHotWordList();
            using (var context = new FaoB2BEntities())
            {
                //var entities = Context.Database.SqlQuery<ProcGetAllHotWordRank_Result>("dbo.ProcGetAllHotWordRank @p0,@p1", 1, 2);
                List<VmHotWord> vmlist = new List<VmHotWord>();
                var entities = context.Database.SqlQuery<ProcGetAllHotWordRank_Result>("dbo.ProcGetAllHotWordRank @p0", id);
                var rows = entities.Select(e => new VmHotWord
                {
                    CountRank = e.CountRank,
                    IntWordType = e.IntWordType,
                    VarWord = e.VarWord,
                    WordCount = e.WordCount
                }).ToList();
                page.rows = rows;
                page.total = 0;
            }
            return page;
        }

        /// <summary>
        /// 根据id，返回VmHotWord视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmHotWord GetHotWordByID(string id)
        {
            throw new Exception("没有实现");
        }


        /// <summary>
        /// 得到HotWord列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VmHotWordList GetHotWordPaging(SmHotWord sm, int page, int rows)
        {
            string hotword = sm.HotWord == null ? string.Empty : sm.HotWord;
            int wordtype = sm.WordType;
            DateTime startTime, endTime;
            if (!DateTime.TryParse(sm.StartTime, out startTime))
            {
                startTime = DateTime.Parse("1/1/1753 12:00:00");
            }
            if (!DateTime.TryParse(sm.EndTime, out endTime))
            {
                endTime = DateTime.MaxValue;
            }
            if (endTime != DateTime.MaxValue)
            {
                endTime = endTime.AddDays(1);
            }
            VmHotWordList list = new VmHotWordList();
            using (var context = new FaoB2BEntities())
            {
                list.rows = context.Database.SqlQuery<VmHotWord>("ProcGetHotWordList @p0,@p1,@p2,@p3,@p4,@p5", hotword, wordtype, startTime, endTime, page, rows).ToList();
                list.total = context.Database.SqlQuery<int>("ProcGetHotWordListCount @p0,@p1,@p2,@p3", hotword, wordtype, startTime, endTime).FirstOrDefault();
            }
            return list;
        }

        /// <summary>
        /// 检索关键词时，插入数据库
        /// </summary>
        /// <param name="hw"></param>
        /// <returns></returns>
        public void AddHotWord(string id, string type)
        {
            HotWord hw = new HotWord();
            hw.DteCreate = System.DateTime.Now;
            hw.IntFlag = 1;
            hw.IntWordType = int.Parse(id);
            hw.VarWord = type;
            hw.VarVisitIP = Utils.CurrentRequestIP();

            Thread tsPhone = new Thread(new ParameterizedThreadStart(InsertHotWord));
            tsPhone.Start(hw);
        }

        private void InsertHotWord(object hword)
        {

            HotWord hw = hword as HotWord;



            using (var context = new FaoB2BEntities())
            {
                context.HotWords.Add(hw);
                context.SaveChanges();
            }
        }
        /// <summary>
        /// 获取替换的热词
        /// </summary>
        /// <returns></returns>
        public HotWordString GetHotWordString()
        {
            XDocument siteXml = XDocument.Load(IOHelper.GetWebPath("/") + @"Config\Site.config");
            //获取有当前效配置节点
            var validSite = siteXml.XPathSelectElement("//site[@name='" + siteXml.Root.Attribute("valid").Value + "']");
            string indexPath = validSite.Element("uri").Value;
            HotWordString model = new HotWordString();
            model.B2BSite = indexPath;
            model.PSSite = validSite.Element("ps").Value;
            string wordString = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var words = context.HotWords.Where(e => e.IntWordType < 6)
                       .GroupBy(e => new { e.IntWordType, e.VarWord })
                       .Select(e => new
                       {
                           IntWordType = e.Key.IntWordType,
                           VarWord = e.Key.VarWord,
                           Count = e.Count()
                       })
                       .GroupBy(e => e.IntWordType)
                       .Select(e => new
                       {
                           IntWordType = e.Key,
                           Words = e.OrderByDescending(n => n.Count).Take(5)
                       }).ToList();

                //替换供应
                var gys = words.Where(e => e.IntWordType == 1).Select(e => e.Words).FirstOrDefault();
                if (gys != null)
                {
                    foreach (var gy in gys)
                    {
                        wordString += string.Format("<li><a class='.word'  href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a></li> ", indexPath, gy.IntWordType, gy.VarWord);
                    }
                }
                model.HotGY = wordString;
                wordString = string.Empty;
                //求购
                var qgs = words.Where(e => e.IntWordType == 2).Select(e => e.Words).FirstOrDefault();
                if (qgs != null)
                {
                    foreach (var qg in qgs)
                    {
                        wordString += string.Format("<li><a class='.word'  href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a></li> ", indexPath, qg.IntWordType, qg.VarWord);
                    }
                }
                model.HotQG = wordString;
                wordString = string.Empty;
                //招商
                var zss = words.Where(e => e.IntWordType == 3).Select(e => e.Words).FirstOrDefault();
                if (zss != null)
                {
                    foreach (var zs in zss)
                    {
                        wordString += string.Format("<li><a class='.word'   href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a></li> ", indexPath, zs.IntWordType, zs.VarWord);
                    }
                }
                model.HotZS = wordString;
                wordString = string.Empty;
                //合作
                var hzs = words.Where(e => e.IntWordType == 4).Select(e => e.Words).FirstOrDefault();
                if (hzs != null)
                {
                    foreach (var hz in hzs)
                    {
                        wordString += string.Format("<li><a class='.word'  href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a></li> ", indexPath, hz.IntWordType, hz.VarWord);
                    }
                }
                model.HotHZ = wordString;
                wordString = string.Empty;
                //代理
                var dls = words.Where(e => e.IntWordType == 5).Select(e => e.Words).FirstOrDefault();
                if (dls != null)
                {
                    foreach (var dl in dls)
                    {
                        wordString += string.Format("<li><a class='.word'  href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a></li> ", indexPath, dl.IntWordType, dl.VarWord);
                    }
                }
                model.HotHZ = wordString;
                wordString = string.Empty;
            }
            if (model == null)
            {
                model = new HotWordString();
            }
            return model;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(HotWord entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(HotWord entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(HotWord entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public HotWord One(IQueryable<HotWord> query, HotWord entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<HotWord> Many(IQueryable<HotWord> query, HotWord entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {

            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
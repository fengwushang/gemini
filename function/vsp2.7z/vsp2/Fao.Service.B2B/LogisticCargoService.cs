﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;

namespace Fao.Service.B2B
{

    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticCargo服务实现-Power by CodeGG
    /// </summary>
    public class LogisticCargoService : Entity<LogisticCargo>, ILogisticCargoService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IEnterpriseService enterpriseService = new EnterpriseService();
        IBaseUserService baseUserService = new BaseUserService();
        IBaseAreaService baseAreaService = new BaseAreaService();
        IBaseDictionaryService baseDictionaryService = new BaseDictionaryService();
        IAttachmentService attachmentService = new AttachmentService();
        
        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmLogisticCargo查询模型，返回VmLogisticCargo视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmLogisticCargo> GetLogisticCargos(SmLogisticCargo searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmLogisticCargo视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmLogisticCargo GetLogisticCargoByID(string id)
        {
            VmLogisticCargo Cargo = new VmLogisticCargo();
            int cid = Utils.ToInt(Security.Decrypt(id));
            var list = GetLogisticCargosWithPage(new SmLogisticCargo() { ID = cid }, 1, 1);
            if (list.rows.Count > 0)
            {
                Cargo = list.rows[0];
                var package = baseDictionaryService.GetBaseDictionaryByID(new FaoB2BEntities(),int.Parse(Cargo.CargoPackage.ToString()));
                Cargo.Package = package != null ? package.ItemName : "";
            }
            return Cargo;
        }

        /// <summary>
        /// 获取分页数据 货源表
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        public LogisticCargoPaging GetLogisticCargosWithPage(SmLogisticCargo searchModel, int pageIndex, int pageCount)
        {
            LogisticCargoPaging page = new LogisticCargoPaging();

            #region 原代码
            //using (var context = new FaoB2BEntities())
            //{
            //    var Cargos = Many(context.LogisticCargoes, null).Where(c => c.IntFlag == 3);
            //    if (searchModel != null)
            //    {
            //        if (searchModel.ID > 0)
            //        {
            //            Cargos = Cargos.Where(c => c.IntCargoID == searchModel.ID);
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.KeyWord))
            //        {
            //            Cargos = Cargos.Where(c => (c.VarCargoTitle.Contains(searchModel.KeyWord) || c.VarDetails.Contains(searchModel.KeyWord)));
            //        }
            //        if (searchModel.AreaIDStart > 0)
            //        {
            //            var area = baseAreaService.Many(context.BaseAreas, null).Where(a => a.IntAreaID == searchModel.AreaIDStart
            //                        || a.IntAreaParentID == searchModel.AreaIDStart).Select(a => a.IntAreaID).ToArray();
            //            Cargos = Cargos.Where(c => area.Contains(c.IntAreaIDStart));
            //        }
            //        if (searchModel.AreaIDEnd > 0)
            //        {
            //            var area = baseAreaService.Many(context.BaseAreas, null).Where(a => a.IntAreaID == searchModel.AreaIDEnd
            //                       || a.IntAreaParentID == searchModel.AreaIDEnd).Select(a => a.IntAreaID).ToArray();
            //            Cargos = Cargos.Where(c => area.Contains(c.IntAreaIDEnd));
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.DteRefreshStart))
            //        {
            //            DateTime dteRefreshStart = new DateTime();
            //            if (DateTime.TryParse(searchModel.DteRefreshStart, out dteRefreshStart))
            //            {
            //                Cargos = Cargos.Where(c => c.DteRefresh >= dteRefreshStart);
            //            }
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.DteRefreshEnd))
            //        {
            //            DateTime dteRefreshEnd = new DateTime();
            //            if (DateTime.TryParse(searchModel.DteRefreshEnd, out dteRefreshEnd))
            //            {
            //                Cargos = Cargos.Where(c => c.DteRefresh <= dteRefreshEnd);
            //            }
            //        }
            //    }

            //    var user = baseUserService.Many(context.BaseUsers, null);
            //    var ent = enterpriseService.Many(context.Enterprises, null);
            //    var dict = baseDictionaryService.Many(context.BaseDictionaries, null);

            //    var entity = from c in Cargos
            //                 join e in ent on c.IntEnterpriseID equals e.IntEnterpriseID
            //                 join u in user on c.IntCreateUserID equals u.IntUserID
            //                 join type in dict on c.IntCargoType equals type.IntItemID
            //                 join cate in dict on c.IntCargoCate equals cate.IntItemID
            //                 join transType in dict on c.IntCargoTransType equals transType.IntItemID
            //                 join transAsk in dict on c.IntCargoTransAsk equals transAsk.IntItemID
            //                 join package in dict on c.IntCargoPackage equals package.IntItemID
            //                 join unit in dict on c.IntFreightUnit equals unit.IntItemID
            //                 select new
            //                 {
            //                     AreaIDEnd = c.IntAreaIDEnd,
            //                     AreaIDStart = c.IntAreaIDStart,
            //                     BrowserCount = c.IntBrowserCount,
            //                     CargoCate = c.IntCargoCate,
            //                     CargoID = c.IntCargoID,
            //                     CargoPackage = c.IntCargoPackage,
            //                     CargoTitle = c.VarCargoTitle,
            //                     CargoTransAsk = c.IntCargoTransAsk,
            //                     CargoTransType = c.IntCargoTransType,
            //                     CargoType = c.IntCargoType,
            //                     CargoWeight = c.VarCargoWeight,
            //                     Cate = cate.VarItemName,
            //                     DecCargoFreight = c.DecCargoFreight,
            //                     DteCreate = c.DteCreate,
            //                     DteRefresh = c.DteRefresh,
            //                     DteValid = c.DteValid,
            //                     EntID = c.IntEnterpriseID,
            //                     EntName = e.VarEnterpriseName,
            //                     FreightUnit = c.IntFreightUnit,
            //                     Package = package.VarItemName,
            //                     TransAsk = transAsk.VarItemName,
            //                     TransType = transType.VarItemName,
            //                     Type = type.VarItemName,
            //                     Unit = unit.VarItemName,
            //                     UserID = c.IntCreateUserID,
            //                     UserName = u.VarRealName,
            //                     Contact = c.VarContact,
            //                     Details = c.VarDetails,
            //                     Phone = c.VarPhone
            //                 };
            //    page.total = entity.Count();

            //    var list = entity.OrderByDescending(c => c.DteRefresh).Skip((pageIndex - 1) * pageCount).Take(pageCount).ToList();

            //    var CargoIDs = list.Select(e => e.CargoID).ToList();

            //    var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 1)
            //           , CargoIDs)
            //           .Select(e => new
            //           {
            //               e.IntBelongTablePrikeyID,
            //               e.VarFilePath
            //           }).ToList();


            //    var areaStartIDs = list.Select(e => e.AreaIDStart).ToList();
            //    var areaEndIDs = list.Select(e => e.AreaIDEnd).ToList();
            //    var areaStartList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaStartIDs);
            //    var areaEndList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaEndIDs);

            //    var rows = (from c in list
            //                join a1 in areaStartList on c.AreaIDStart equals a1.AreaID
            //                join a2 in areaEndList on c.AreaIDEnd equals a2.AreaID
            //                join a in attList on c.CargoID equals a.IntBelongTablePrikeyID
            //                select new VmLogisticCargo
            //                {
            //                    AreaIDEnd = c.AreaIDEnd,
            //                    AreaIDStart = c.AreaIDStart,
            //                    BrowserCount = c.BrowserCount,
            //                    CargoCate = c.CargoCate,
            //                    CargoID = Security.Encrypt(c.CargoID),
            //                    CargoPackage = c.CargoPackage,
            //                    CargoTitle = c.CargoTitle,
            //                    CargoTransAsk = c.CargoTransAsk,
            //                    CargoTransType = c.CargoTransType,
            //                    CargoType = c.CargoType,
            //                    CargoWeight = c.CargoWeight,
            //                    Cate = c.Cate,
            //                    DecCargoFreight = c.DecCargoFreight,
            //                    DteCreate = c.DteCreate.ToString("yyyy-MM-dd"),
            //                    DteRefresh = c.DteRefresh.ToString("yyyy-MM-dd"),
            //                    DteValid = c.DteValid.Year == DateTime.MaxValue.Year ? "永久有效" : Common.Utils.GetDateFormate(c.DteValid),
            //                    EndArea = a2.Name,
            //                    EntID = Security.Encrypt(c.EntID),
            //                    EntName = c.EntName,
            //                    FreightUnit = c.FreightUnit,
            //                    Package = c.Package,
            //                    StartArea = a1.Name,
            //                    TransAsk = c.TransAsk,
            //                    TransType = c.TransType,
            //                    Type = c.Type,
            //                    Unit = c.Unit,
            //                    UserID = c.UserID,
            //                    UserName = c.UserName,
            //                    Contact = c.Contact,
            //                    Phone = c.Phone,
            //                    Details = c.Details,
            //                    ImgUrl = a.VarFilePath
            //                }).ToList();

            //    page.rows = rows;
            //}
            #endregion

            using (var context = new FaoB2BEntities())
            {
                IEnumerable<VmLogisticCargo> entities = null;
                //根据ID获取该条记录
                if (searchModel.ID>0)
                {
                    entities = context.Database.SqlQuery<VmLogisticCargo>("ProcGetSearchCargoByID @p0", searchModel.ID);
                    page.total = entities.Count();
                }
                else
                {
                    //分页数据
                    entities = context.Database.SqlQuery<VmLogisticCargo>(
                    "ProcGetSearchCargo @p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7"
                    , searchModel.AreaIDStart
                    , searchModel.AreaIDEnd
                    , string.IsNullOrWhiteSpace(searchModel.DteRefreshStart) ? string.Empty : searchModel.DteRefreshStart
                    , string.IsNullOrWhiteSpace(searchModel.DteRefreshEnd) ? string.Empty : searchModel.DteRefreshEnd
                    , 6
                    , string.IsNullOrWhiteSpace(searchModel.KeyWord) ? string.Empty : searchModel.KeyWord
                    , pageIndex
                    , pageCount
                    );

                    page.total = context.Database.SqlQuery<int>(
                       "ProcGetSearchCargoCount @p0,@p1,@p2,@p3,@p4,@p5"
                       , searchModel.AreaIDStart
                       , searchModel.AreaIDEnd
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshStart) ? string.Empty : searchModel.DteRefreshStart
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshEnd) ? string.Empty : searchModel.DteRefreshEnd
                       , 6
                       , string.IsNullOrWhiteSpace(searchModel.KeyWord) ? string.Empty : searchModel.KeyWord
                       ).FirstOrDefault();
                }

                //组织数据
                var list = entities.ToList().Select(e => new
                {
                    AreaIDEnd = Utils.ToInt(e.AreaIDEnd.ToString()),
                    AreaIDStart = Utils.ToInt(e.AreaIDStart.ToString()),
                    BrowserCount = e.BrowserCount,
                    CargoCate = e.CargoCate,
                    CargoID = Utils.ToInt(e.CargoID),
                    CargoPackage = e.CargoPackage,
                    CargoTitle = e.CargoTitle,
                    CargoTransAsk = e.CargoTransAsk,
                    CargoTransType = e.CargoTransType,
                    CargoType = e.CargoType,
                    CargoWeight = e.CargoWeight,
                    Cate = e.Cate,

                    DecCargoFreight = e.DecCargoFreight,
                    DteCreate = e.DteCreate,
                    DteRefresh = e.DteRefresh,
                    DteValid = e.DteValid,
                    EntID = e.EntID,
                    EntName = e.EntName,
                    FreightUnit = e.FreightUnit,
                    Package = e.Package,

                    TransAsk = e.TransAsk,
                    TransType = e.TransType,
                    Type = e.Type,
                    Unit = e.Unit,

                    UserID = e.UserID,
                    UserName = e.UserName,
                    Contact = e.Contact,
                    Details = e.Details,
                    Phone = e.Phone,
                    PPCID = e.PPCID,
                    EncriptID = Security.Encrypt(e.EncriptID),

                    EndArea = e.EndArea,
                    StartArea = e.StartArea,

                    ValidDate = e.ValidDate,
                    Sms = e.Sms,

                }).ToList();

                //获取分页数据主键集合
                var CargoIDs = list.Select(e => e.CargoID);

                //获取附件集合
                var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 1)
                      , CargoIDs)
                      .Select(e => new
                      {
                          e.IntBelongTablePrikeyID,
                          e.VarFilePath
                      }).ToList();


                var areaStartIDs = list.Select(e => e.AreaIDStart).ToList();
                var areaEndIDs = list.Select(e => e.AreaIDEnd).ToList();

                var areaStartList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaStartIDs);
                var areaEndList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaEndIDs);

                var rows = (from c in list
                            join a1 in areaStartList on c.AreaIDStart equals a1.AreaID
                            join a2 in areaEndList on c.AreaIDEnd equals a2.AreaID
                            join a in attList on c.CargoID equals a.IntBelongTablePrikeyID
                            select new VmLogisticCargo
                            {
                                AreaIDEnd = c.AreaIDEnd,
                                AreaIDStart = c.AreaIDStart,
                                BrowserCount = c.BrowserCount,
                                CargoCate = c.CargoCate,
                                CargoID = Security.Encrypt(c.CargoID),
                                CargoPackage = c.CargoPackage,
                                CargoTitle = c.CargoTitle,
                                CargoTransAsk = c.CargoTransAsk,
                                CargoTransType = c.CargoTransType,
                                CargoType = c.CargoType,
                                CargoWeight = c.CargoWeight,
                                Cate = c.Cate,
                                DecCargoFreight = c.DecCargoFreight,
                                DteCreate = c.DteCreate,
                                DteRefresh = c.DteRefresh,
                                DteValid = Convert.ToDateTime(c.DteValid).Year == DateTime.MaxValue.Year ? "永久有效" : c.DteValid,
                                EndArea = a2.Name,
                                EntID = Security.Encrypt(c.EntID),
                                EntName = c.EntName,
                                FreightUnit = c.FreightUnit,
                                Package = c.Package,
                                StartArea = a1.Name,
                                TransAsk = c.TransAsk,
                                TransType = c.TransType,
                                Type = c.Type,
                                Unit = c.Unit,
                                UserID = c.UserID,
                                UserName = c.UserName,
                                Contact = c.Contact,
                                Phone = c.Phone,
                                Details = c.Details,
                                ImgUrl = a.VarFilePath,
                                PPCID = c.PPCID,
                                EncriptID = c.EncriptID,
                                Sms = Security.Encrypt(c.Sms)
                            }).ToList();
                page.rows = rows;
            }

            return page;
        }

        /// <summary>
        /// 添加货源信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddLogisticCargoInfo(VmLogisticCargo model, VmB2BInfoPicture picture)
        {
            string msg = "";
            using (var context = new FaoB2BEntities())
            {

                var user = baseUserService.CurrentUser(context.BaseUsers);
                LogisticCargo entity = new LogisticCargo();
                var enterprise = enterpriseService.GetCurrentEnterprise(context);
                if (user == null)
                {
                    msg = "用户未登陆";
                }
                else
                {
                    string strID = string.Empty;
                    int id = 0;
                    if (enterprise != null)
                    {
                        strID = Security.Decrypt(enterprise.EntID);
                        strID = strID == "" ? enterprise.EntID : strID;
                        int.TryParse(strID, out id);
                    }
                    entity.IntCreateUserID = user.IntUserID;
                    entity.IntEnterpriseID = id;
                    entity.DteCreate = DateTime.Now;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.DteRefresh = DateTime.Now;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.IntBrowserCount = 0;
                    entity.VarContact = model.Contact;
                    entity.VarDetails = model.Details == null ? "" : model.Details;
                    entity.VarPhone = model.Phone;
                    entity.VarCargoTitle = model.CargoTitle;
                    entity.IntAreaIDStart = model.AreaIDStart ?? 0;
                    entity.IntAreaIDEnd = model.AreaIDEnd ?? 0;
                    entity.IntCargoType = model.CargoType ?? 0;
                    entity.DecCargoFreight = model.DecCargoFreight ?? 0.00M;
                    entity.IntCargoCate = model.CargoCate ?? 0;
                    entity.IntCargoPackage = model.CargoPackage ?? 0;
                    entity.IntCargoTransType = model.CargoTransType ?? 0;
                    entity.IntCargoTransAsk = model.CargoTransAsk ?? 0;
                    entity.VarCargoWeight = model.CargoWeight;
                    entity.IntFreightUnit = model.FreightUnit ?? 0;
                    context.LogisticCargoes.Add(entity);
                    int flag = context.SaveChanges();
                    SaveImage(context, entity.IntCargoID, picture);

                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 修改货源信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateLogisticCargoInfo(VmLogisticCargo model, VmB2BInfoPicture picture = null)
        {
            string msg = "";
            using (var context = new FaoB2BEntities())
            {
                string strID = Common.Security.Decrypt(model.EncriptID);
                int id;
                if (!int.TryParse(strID, out id))
                {
                    msg = "未提到该记录";
                }
                else
                {
                    var entity = context.LogisticCargoes.Find(id);
                    if (entity != null)
                    {
                        entity.IntFlag = model.Flag ?? 1;
                        entity.DteRefresh = model.RefreshDate ?? DateTime.Now;
                        entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                        entity.VarContact = model.Contact;
                        entity.VarDetails = model.Details == null ? "" : model.Details;
                        entity.VarPhone = model.Phone;
                        entity.VarCargoTitle = model.CargoTitle;
                        entity.IntAreaIDStart = model.AreaIDStart ?? 0;
                        entity.IntAreaIDEnd = model.AreaIDEnd ?? 0;
                        entity.IntCargoType = model.CargoType ?? 0;
                        entity.DecCargoFreight = model.DecCargoFreight ?? 0;
                        entity.IntCargoCate = model.CargoCate ?? 0;
                        entity.IntCargoPackage = model.CargoPackage ?? 0;
                        entity.IntCargoTransType = model.CargoTransType ?? 0;
                        entity.IntCargoTransAsk = model.CargoTransAsk ?? 0;
                        entity.VarCargoWeight = model.CargoWeight;
                        entity.IntFreightUnit = model.FreightUnit ?? 0;
                    }
                    int flag = context.SaveChanges();
                    if (picture != null)
                    {
                        SaveImage(context, entity.IntCargoID, picture);
                        //删除 热词推广 信息
                        //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                        PPCService pPCService = new PPCService();
                        pPCService.DeletePPC(6, entity.IntCargoID);
                    }
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }
        /// <summary>
        /// 根据ID得到货源信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmLogisticCargo GetLogisticCargoInfoBy(string encriptID)
        {
            VmLogisticCargo vm = new VmLogisticCargo();
            using (var context = new FaoB2BEntities())
            {
                string strID = Security.Decrypt(encriptID);
                int id = 0;
                int.TryParse(strID, out id);
                var entity = context.LogisticCargoes.Find(id);
                var attList = attachmentService.GetAttachmentsByTablePK(context, id, 1);
                if (entity != null)
                {
                    var startArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDStart }).FirstOrDefault();
                    var endArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDEnd }).FirstOrDefault();
                    var cargoType = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoType);
                    var cargoCate = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoCate);
                    var cargoTransType = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoTransType);
                    var tranAsk = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoTransAsk);
                    var package = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoPackage);
                    var unit = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntFreightUnit);

                    vm = new VmLogisticCargo()
                    {
                        Unit = unit != null ? unit.ItemName : "",
                        Type = cargoType != null ? cargoType.ItemName : "",
                        Cate = cargoCate != null ? cargoCate.ItemName : "",
                        TransType = cargoTransType != null ? cargoTransType.ItemName : "",
                        TransAsk = tranAsk != null ? tranAsk.ItemName : "",
                        Package = package != null ? package.ItemName : "",
                        EncriptID = Security.Encrypt(id),
                        AreaIDStart = entity.IntAreaIDStart,
                        StartArea = startArea != null ? startArea.Name : "",
                        AreaIDEnd = entity.IntAreaIDEnd,
                        EndArea = endArea != null ? endArea.Name : "",
                        CargoType = entity.IntCargoType,
                        CargoCate = entity.IntCargoCate,
                        CargoTransType = entity.IntCargoTransType,
                        CargoTransAsk = entity.IntCargoTransAsk,
                        CargoPackage = entity.IntCargoPackage,
                        CargoTitle = entity.VarCargoTitle,
                        CargoWeight = entity.VarCargoWeight,
                        DecCargoFreight = decimal.Round(entity.DecCargoFreight, 2),
                        Contact = entity.VarContact,
                        Details = entity.VarDetails,
                        ValidDate = entity.DteValid,
                        Phone = entity.VarPhone,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                        Flag = entity.IntFlag,
                        FreightUnit = entity.IntFreightUnit,
                        DteValid = Utils.GetDateWithHMFormate(entity.DteValid),
                    };
                }
            }
            return vm;
        }


        /// <summary>
        /// 根据ID得到货源信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmLogisticCargo GetLogisticCargoInfoBy(FaoB2BEntities context, string encriptID)
        {
            VmLogisticCargo vm = new VmLogisticCargo();
            string strID = Security.Decrypt(encriptID);
            int id = 0;
            int.TryParse(strID, out id);
            var entity = context.LogisticCargoes.Find(id);
            var attList = attachmentService.GetAttachmentsByTablePK(context, id, 1);
            if (entity != null)
            {
                var startArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDStart }).FirstOrDefault();
                var endArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDEnd }).FirstOrDefault();
                var cargoType = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoType);
                var cargoCate = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoCate);
                var cargoTransType = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoTransType);
                var tranAsk = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoTransAsk);
                var package = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoPackage);
                var unit = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntFreightUnit);

                vm = new VmLogisticCargo()
                {
                    Unit = unit != null ? unit.ItemName : "",
                    Type = cargoType != null ? cargoType.ItemName : "",
                    Cate = cargoCate != null ? cargoCate.ItemName : "",
                    TransType = cargoTransType != null ? cargoTransType.ItemName : "",
                    TransAsk = tranAsk != null ? tranAsk.ItemName : "",
                    Package = package != null ? package.ItemName : "",
                    EncriptID = Security.Encrypt(id),
                    AreaIDStart = entity.IntAreaIDStart,
                    StartArea = startArea != null ? startArea.Name : "",
                    AreaIDEnd = entity.IntAreaIDEnd,
                    EndArea = endArea != null ? endArea.Name : "",
                    CargoType = entity.IntCargoType,
                    CargoCate = entity.IntCargoCate,
                    CargoTransType = entity.IntCargoTransType,
                    CargoTransAsk = entity.IntCargoTransAsk,
                    CargoPackage = entity.IntCargoPackage,
                    CargoTitle = entity.VarCargoTitle,
                    CargoWeight = entity.VarCargoWeight,
                    DecCargoFreight = decimal.Round(entity.DecCargoFreight, 2),
                    Contact = entity.VarContact,
                    Details = entity.VarDetails,
                    ValidDate = entity.DteValid,
                    Phone = entity.VarPhone,
                    ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                    ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                    Flag = entity.IntFlag,
                    FreightUnit = entity.IntFreightUnit,
                    DteValid = Utils.GetDateWithHMFormate(entity.DteValid),
                };
            }
            return vm;
        }


        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public LogisticCargoPaging GetLogisticCargoPager(SmLogisticCargo search, int page, int rows)
        {
            LogisticCargoPaging pager = new LogisticCargoPaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmLogisticCargo>("ProcGetCargoList @p0,@p1,@p2,@p3,@p4,@p5",
                        string.IsNullOrWhiteSpace(search.CargoTitle) ? "" : search.CargoTitle
                        , search.state
                        ,search.ISTG??string.Empty
                        ,user.IntUserID
                        , page
                        , rows);

                    pager.total = context.Database.SqlQuery<int>("ProcGetCargoListCount @p0,@p1,@p2,@p3",
                        string.IsNullOrWhiteSpace(search.CargoTitle) ? "" : search.CargoTitle
                        , search.state
                        , search.ISTG??string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();

                    pager.rows = list.OrderByDescending(l => l.DteRefresh).Skip((page - 1) * rows)
                        .Take(rows).Select(p => new VmLogisticCargo
                        {
                            EncriptID = Security.Encrypt(p.EncriptID),
                            CargoTitle = p.CargoTitle,
                            Type = p.Type,
                            StartArea = p.StartArea,
                            EndArea = p.EndArea,
                            BrowserCount = p.BrowserCount,
                            DteRefresh = p.DteRefresh,
                            ISTG = p.ISTG
                        }).ToList();
                }
            }
            return pager;
        }

        /// <summary>
        /// 得到货源统计信息
        /// </summary>
        /// <returns></returns>
        public VmCountInfo GetLogisticCargoInfoCount()
        {
            VmCountInfo count = new VmCountInfo();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCountInfo>("ProcGetCargoCountInfo @p0", user.IntUserID);
                    count = list.FirstOrDefault();
                }
            }
            return count;
        }
        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,2刷新,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        public string CargoBatch(int type, string chooses)
        {
            int flag = -1;
            using (var context = new FaoB2BEntities())
            {
                string[] IDs = chooses.Split(',');
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.LogisticCargoes.Find(id);
                        if (entity != null)
                        {
                            if (type == 1)
                            {
                                entity.IntFlag = 0;
                            }
                            else if (type == 2 && entity.IntFlag == 3)
                            {
                                entity.DteRefresh = DateTime.Now;
                            }
                            else if (type == 3 && entity.IntFlag == 1)
                            {
                                entity.IntFlag = 2;
                            }
                        }
                    }
                }
                flag = context.SaveChanges();
            }
            if (flag >= 0)
            {
                return "1";
            }
            return "0";
        }

        /// <summary>
        /// 得到审批列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public LogisticCargoPaging GetAuditingPager(SmLogisticCargo sm, int page, int rows)
        {
            LogisticCargoPaging pager = new LogisticCargoPaging();
            using (var context = new FaoB2BEntities())
            {
                var list = context.Database.SqlQuery<VmLogisticCargo>("ProcGetCargoList @p0,@p1,@p2,@p3,@p4,@p5",
                    string.IsNullOrWhiteSpace(sm.CargoTitle) ? "" : sm.CargoTitle, 2, 0, 0,page, rows);

                pager.total = context.Database.SqlQuery<int>("ProcGetCargoListCount @p0,@p1,@p2,@p3",
                    string.IsNullOrWhiteSpace(sm.CargoTitle) ? "" : sm.CargoTitle, 2, 0,0).FirstOrDefault();

                pager.rows = list.OrderByDescending(l => l.DteRefresh).Skip((page - 1) * rows)
                    .Take(rows).Select(p => new VmLogisticCargo
                    {
                        EncriptID = Security.Encrypt(p.EncriptID),
                        CargoTitle = p.CargoTitle,
                        Type = p.Type,
                        StartArea = p.StartArea,
                        EndArea = p.EndArea,
                        BrowserCount = p.BrowserCount,
                        DteRefresh = p.DteRefresh,
                        Contact = p.Contact,
                        DteValid = p.DteValid,
                        ValidDate = p.ValidDate
                    }).ToList();
            }
            return pager;
        }

        /// <summary>
        /// 审批
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        public string Auditing(string ID, int Result)
        {
            string msg = "未找到该信息";
            using (var context = new FaoB2BEntities())
            {
                string strID = Security.Decrypt(ID);
                int id = 0;
                if (int.TryParse(strID, out id))
                {
                    var entity = context.LogisticCargoes.Find(id);
                    if (entity != null)
                    {
                        if (entity.IntFlag != 2)
                        {
                            msg = "该信息不审批";
                        }
                        else
                        {
                            entity.IntFlag = Result;
                            int flag = context.SaveChanges();
                            if (flag >= 0)
                            {
                                msg = "1";
                            }
                        }
                    }
                }
                else
                {
                    msg = "未找到该信息";
                }
            }
            return msg;
        }

        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="model"></param>
        public void UpdateBrowserCount(VmLogisticCargo model)
        {
            using (var context = new FaoB2BEntities())
            {
                int id = Utils.ToInt(Security.Decrypt(model.EncriptID));
                var entity = context.LogisticCargoes.Find(id);
                entity.IntBrowserCount++;
                context.SaveChanges();
            }
        }
        #endregion

        #region 辅助方法

        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="infoID">对应的信息ID</param>
        /// <returns></returns>
        private void SaveImage(FaoB2BEntities context, int infoID, VmB2BInfoPicture picture)
        {
            int i = 0;
            int j = 1;
            while (true)
            {
                if (picture.PictureUrls[i] != "" || picture.PictureIDs[i] != "")
                {
                    int id = 0;
                    string strID = Security.Decrypt(picture.PictureIDs[i]);
                    int.TryParse(strID, out id);
                    if (SaveImage(context, picture.PictureUrls[i], picture.OriginalName[i], infoID, j, id))
                    {
                        j++;
                    }
                }
                i++;
                if (i > 2)
                {
                    break;
                }
            }

        }
        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="originalName"></param>
        /// <param name="infoID"></param>
        /// <param name="orderID"></param>
        /// <param name="imageID"></param>
        private bool SaveImage(FaoB2BEntities context, string fileName, string originalName, int infoID, int orderID, int imageID = 0)
        {
            bool flag = false;
            VmAttachment oldAtt = null;
            if (imageID != 0)
            {
                oldAtt = attachmentService.GetAttachmentByID(context, imageID.ToString());
            }
            if (fileName != "" && originalName != "")
            {
                VmAttachment attachment = new VmAttachment();
                attachment.BelongTable = 1;
                attachment.PK = infoID;
                attachment.FileName = originalName;
                attachment.Path = fileName;
                attachment.Descrip = "";
                attachment.Order = orderID;
                if (imageID == 0)
                {
                    attachmentService.AddAttachment(context, attachment);

                }
                else
                {
                    attachment.ID = imageID;
                    attachmentService.UpdateAttachment(context, attachment);
                }
                flag = true;
            }
            else if (fileName == "" && imageID != 0)
            {
                attachmentService.DeleteAttachment(context, imageID);
                flag = false;
            }
            else if (oldAtt != null && oldAtt.Order != orderID)
            {
                oldAtt.Order = orderID;
                attachmentService.UpdateAttachment(context, oldAtt);
                flag = true;
            }
            else if (fileName != "" && imageID != 0)
            {
                flag = true;
            }
            return flag;
        }

        #endregion


        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(LogisticCargo entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(LogisticCargo entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(LogisticCargo entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public LogisticCargo One(IQueryable<LogisticCargo> query, LogisticCargo entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<LogisticCargo> Many(IQueryable<LogisticCargo> query, LogisticCargo entity)
        {
            var entitys = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntCreateUserID != 0)
                {
                    entitys = entitys.Where(p => p.IntCreateUserID == entity.IntCreateUserID);
                }
            }
            entitys = entitys.Where(e => e.IntFlag != 0);
            return entitys;
        }

        #endregion

    }
}
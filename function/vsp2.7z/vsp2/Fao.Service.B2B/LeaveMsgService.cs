﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Data.Sms.DAL;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LeaveMsg服务实现-Power by CodeGG
    /// </summary>
    public class LeaveMsgService : Entity<LeaveMsg>, ILeaveMsgService
    {

        #region 业务接口引用

        ILogisticCargoService logisticCargoService = new LogisticCargoService();
        IEnterpriseService enterpriseService = new EnterpriseService();
        IB2BInfoService b2BInfoService = new B2BInfoService();
        ILogisticStoreService logisticStoreService = new LogisticStoreService();
        ILogisticVehicleSourceService logisticVehicleSourceService = new LogisticVehicleSourceService();
        ILogisticRouteService logisticRouteService = new LogisticRouteService();
        IAuthenticateService authenticateService = new AuthenticateService();
        IBaseAreaService baseAreaService = new BaseAreaService();
        IBaseUserService baseUserService = new BaseUserService();
        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmLeaveMsg查询模型，返回VmLeaveMsg视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmLeaveMsg> GetLeaveMsgs(SmLeaveMsg searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmLeaveMsg视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmLeaveMsg GetLeaveMsgByID(string id)
        {
            VmLeaveMsg vmLeaveMsg =  new VmLeaveMsg();
            using (var context = new FaoB2BEntities())
            {
                var entity = context.LeaveMsgs.Find(Utils.ToInt(id));
                 
                if (entity != null)
                {
                    vmLeaveMsg = new VmLeaveMsg
                    {
                        IntLeaveMsgID = entity.IntLeaveMsgID,
                        VarTitle = entity.VarTitle,
                        VarContent = entity.VarContent,
                        IntSex = entity.IntSex,
                        VarTelPhone = entity.VarTelPhone,
                        VarQQ = entity.VarQQ,
                        VarEmail = entity.VarEmail,
                         VarContact=entity.VarContact,
                         VarPhone=entity.VarPhone
                    };
                    //查询过后，设置该站内信的flag为2，已读。
                    entity.IntFlag = 2;
                    context.SaveChanges();
                }
               
            }
            return vmLeaveMsg;
        }

        /// <summary>
        /// 根据表名，id集合，返回要询价(报价、留言)的信息列表集合
        /// </summary>
        /// <param name="tableID">来源表</param>
        /// <param name="ids">id主键集合</param>
        /// <returns></returns>
        public List<VMMsgObject> GetMsgObjects(string tableID, string ids)
        {
            List<VMMsgObject> list = new List<VMMsgObject>();
            using (var context = new FaoB2BEntities())
            {
                int tid = Utils.ToInt(tableID);
                var infoIDs = Utils.Split(ids)
                    .Select(i => Utils.ToInt(Security.Decrypt(i)));

                var Enterprise = enterpriseService.Many(context.Enterprises, null);

                //1 (LogisticCargo) 货源表，2(LogisticStore)库源表，3（LogisticVehicle）车辆表 ，
                //4(LogisticVehicleSource)车源表，5(LogisticRoute)物流专线表, 6 (B2BInfo)信息表，7(Authenticate)认证表         
                switch (tid)
                {
                    case 1:
                        {
                            var MsgObject = logisticCargoService
                                .Many(context.LogisticCargoes, new LogisticCargo())
                                .Where(obj => infoIDs.Contains(obj.IntCargoID));
                            list = MsgObject.Join(Enterprise,
                                b => b.IntEnterpriseID,
                                e => e.IntEnterpriseID, (b, e) => new VMMsgObject()
                            {
                                IntObjID = b.IntCargoID,
                                IntEnterpriseID = e.IntEnterpriseID,
                                VarObj = b.VarCargoTitle,
                                VarEnterprise = e.VarEnterpriseName
                            }).ToList();

                            break;
                        }
                    case 2:
                        {
                            var MsgObject = logisticStoreService
                                .Many(context.LogisticStores, new LogisticStore())
                                .Where(obj => infoIDs.Contains(obj.IntStoreID));
                            list = MsgObject.Join(Enterprise,
                                b => b.IntEnterpriseID,
                                e => e.IntEnterpriseID, (b, e) => new VMMsgObject()
                            {
                                IntObjID = b.IntStoreID,
                                IntEnterpriseID = e.IntEnterpriseID,
                                VarObj = b.VarStoreTitle,
                                VarEnterprise = e.VarEnterpriseName
                            }).ToList();
                            break;
                        }
                    case 4:
                        {
                            var MsgObject = logisticVehicleSourceService
                                .Many(context.LogisticVehicleSources, new LogisticVehicleSource())
                                .Where(obj => infoIDs.Contains(obj.IntVehicleSourceID));
                            list = MsgObject.Join(Enterprise,
                                b => b.IntEnterpriseID,
                                e => e.IntEnterpriseID, (b, e) => new VMMsgObject()
                            {
                                IntObjID = b.IntVehicleSourceID,
                                IntEnterpriseID = e.IntEnterpriseID,
                                VarObj = context.BaseAreas.Find(b.IntAreaIDStart) + " >> " + context.BaseAreas.Find(b.IntAreaIDEnd),
                                VarEnterprise = e.VarEnterpriseName
                            }).ToList();
                            break;
                        }
                    case 5:
                        {
                            var MsgObject = logisticRouteService
                                .Many(context.LogisticRoutes, new LogisticRoute())
                                .Where(obj => infoIDs.Contains(obj.IntRouteID));
                            list = MsgObject.Join(Enterprise,
                                b => b.IntEnterpriseID,
                                e => e.IntEnterpriseID,
                                (b, e) => new VMMsgObject()
                            {
                                IntObjID = b.IntRouteID,
                                IntEnterpriseID = e.IntEnterpriseID,
                                VarObj = context.BaseAreas.Find(b.IntAreaIDStart) + " >> " + context.BaseAreas.Find(b.IntAreaIDEnd),
                                VarEnterprise = e.VarEnterpriseName
                            }).ToList();
                            break;
                        }
                    case 6:
                        {
                            var MsgObject = b2BInfoService.Many(context.B2BInfo, new B2BInfo()).Where(obj => infoIDs.Contains(obj.IntInfoID));
                            list = MsgObject.Join(Enterprise, b => b.IntEnterpriseID, e => e.IntEnterpriseID, (b, e) => new VMMsgObject()
                            {
                                IntObjID = b.IntInfoID,
                                IntEnterpriseID = e.IntEnterpriseID,
                                VarObj = b.VaInfoTitle,
                                VarEnterprise = e.VarEnterpriseName,
                                type = b.IntInfoType
                            }).ToList();
                            break;
                        }

                    default:
                        break;
                }
            }
            return list;
        }


        /// <summary>
        /// 添加询价
        /// </summary>
        /// <param name="vmModel">VmLeaveMsg视图模型</param>
        /// <returns></returns>
        public int AddLeaveMsg(VmLeaveMsg vmModel)
        {
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                LeaveMsg entity = GetEntityFrom(vmModel);
                entity.IntFlag = 1;
                entity.DteCreate = DateTime.Now;
                context.LeaveMsgs.Add(entity);
                flag = context.SaveChanges();
            }
            return flag;
        }

        /// <summary>
        /// 添加多个留言
        /// </summary>
        /// <param name="vmModel"></param>
        /// <returns></returns>
        public int AddLeaveMsgByIds(VmLeaveMsg vmModel)
        {
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                if (vmModel == null || string.IsNullOrEmpty(vmModel.Ids))
                    flag = -1;
                else
                {
                    string[] arrStr = vmModel.Ids.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    var result = GetReceiveUserID(context, vmModel.IntBelongTable, arrStr);
                    foreach (var value in result)
                    {
                        LeaveMsg entity = GetEntityFrom(vmModel);
                        entity.IntFlag = 1;
                        entity.IntBelongTablePrikeyID = value.Key;
                        entity.IntReviceUserID = value.Value;
                        entity.DteCreate = DateTime.Now;
                        context.LeaveMsgs.Add(entity);
                    }
                }
                flag = context.SaveChanges();
            }
            return flag;
        }
        public Dictionary<int, int> GetReceiveUserID(FaoB2BEntities context, int blongTable, string[] arrStr)
        {
            int[] ids = arrStr.Select(e => Convert.ToInt32(Security.Decrypt(e))).ToArray();
            Dictionary<int, int> result = new Dictionary<int, int>();
            switch (blongTable)
            {
                case 1:
                    {
                        result = logisticCargoService.Many(context.LogisticCargoes, null).Where(e => ids.Contains(e.IntCargoID)).ToDictionary(e => e.IntCargoID, e => e.IntCreateUserID);
                        break;

                    }
                case 2:
                    {
                        result = logisticStoreService
                                .Many(context.LogisticStores, null).Where(e => ids.Contains(e.IntStoreID)).ToDictionary(e => e.IntStoreID, e => e.IntCreateUserID);
                        break;
                    }
                case 4:
                    {
                        result = logisticVehicleSourceService
                                .Many(context.LogisticVehicleSources, null).Where(e => ids.Contains(e.IntVehicleSourceID)).ToDictionary(e => e.IntVehicleSourceID, e => e.IntCreateUserID);
                        break;
                    }
                case 5:
                    {
                        result = logisticRouteService
                                .Many(context.LogisticRoutes, null).Where(e => ids.Contains(e.IntRouteID)).ToDictionary(e => e.IntRouteID, e => e.InCreatetUserID);
                        break;
                    }
                case 6:
                    {
                        result = b2BInfoService
                                .Many(context.B2BInfo, null).Where(e => ids.Contains(e.IntInfoID)).ToDictionary(e => e.IntInfoID, e => e.IntCreateUserID);
                        break;
                    }
                default: break;
            }
            return result;
        }
        /// <summary>
        /// 返回分而对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public VmLeaveMsgPaging GetLeaveMsgsWithPager(SmLeaveMsg search, int page, int rows)
        {

            VmLeaveMsgPaging pager = new VmLeaveMsgPaging();
            using (var context = new FaoB2BEntities())
            {
                var entity = new LeaveMsg();
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    entity.IntReviceUserID = user.IntUserID;
                }
                entity.VarTitle = search.Title;
                entity.IntMsgType = search.Type;
                entity.IntBelongTable = search.BelongTable;
                var list = Many(context.LeaveMsgs, entity);

                pager.total = list.Count();
                if (page >= 0 && rows > 0)
                {
                    pager.rows = list.OrderByDescending(f => f.DteCreate).Skip((page - 1) * rows).Take(rows).ToList()
                        .Select(p => new VmLeaveMsgForList
                    {
                        BelongTable = p.IntBelongTable == 1 ? "货源" : p.IntBelongTable == 2 ? "库源" : p.IntBelongTable == 3 ? "车辆" : p.IntBelongTable == 4 ? "车源" : p.IntBelongTable == 5 ? "物流专线" : p.IntBelongTable == 6 ? "信息" : "认证",
                        EncriptID = Common.Security.Encrypt(p.IntLeaveMsgID),
                        Contact = p.VarContact,
                        CreateDate = Common.Utils.GetDateTimeFormate(p.DteCreate),
                        Title = p.VarTitle,
                        Type = p.IntMsgType == 1 ? "询价" : p.IntMsgType == 2 ? "报价" : "留言",
                        Phone = p.VarPhone,
                        EncriptPhone = Security.Encrypt(user.IntUserID + "A" + p.VarPhone),
                        Flag = p.IntFlag.ToString()
                    }).ToList();
                }
            }
            return pager;

        }

        /// <summary>
        /// 删除消息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string DeleteLeaveMsg(int id)
        {
            string msg = "0";
            using (var context = new FaoB2BEntities())
            {
                var entity = context.LeaveMsgs.Find(id);
                if (entity != null)
                {
                    entity.IntFlag = 0;
                    int flag = context.SaveChanges();
                    msg = flag >= 0 ? "1" : "0";
                }
            }
            return msg;
        }

        /// <summary>
        /// 批量删除
        /// </summary>
        /// <param name="ids">id集合</param>
        /// <returns></returns>
        public string DeleteLeaveMsgAll(string ids)
        {
            int flag = -1;
            using (var context = new FaoB2BEntities())
            {
                string[] IDs = ids.Split(',');
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.LeaveMsgs.Find(id);
                        if (entity != null)
                        {
                            entity.IntFlag = 0;
                        }
                    }
                }
                flag = context.SaveChanges();
            }
            if (flag >= 0)
            {
                return "1";
            }
            return "0";
        }

        //把VM实例转化成数据库实例
        public LeaveMsg GetEntityFrom(VmLeaveMsg model)
        {
            if (model == null)
                return null;
            return new LeaveMsg()
            {
                IntBelongTable = model.IntBelongTable,
                IntBelongTablePrikeyID = model.IntBelongTablePrikeyID,
                IntFlag = 1,
                IntLeaveMsgID = model.IntLeaveMsgID,
                IntMsgType = model.IntMsgType,
                IntReviceUserID = model.IntReviceUserID,
                VarContact = model.VarContact,
                VarContent = model.VarContent,
                IntSex = model.IntSex,
                VarPhone = model.VarPhone,
                VarEmail = model.VarEmail == null ? string.Empty : model.VarEmail,
                VarQQ = model.VarQQ == null ? string.Empty : model.VarQQ,
                VarTelPhone = model.VarTelPhone == null ? string.Empty : model.VarTelPhone,
                VarTitle = model.VarTitle,
                DteCreate = model.DteCreate
            };
        }

        /// <summary>
        /// datatable to list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static List<T> List<T>(DataTable dt)
        {
            var list = new List<T>();
            Type t = typeof(T);
            var plist = new List<PropertyInfo>(typeof(T).GetProperties());

            foreach (DataRow item in dt.Rows)
            {
                T s = System.Activator.CreateInstance<T>();
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    PropertyInfo info = plist.Find(p => p.Name == dt.Columns[i].ColumnName);
                    if (info != null)
                    {
                        if (!Convert.IsDBNull(item[i]))
                        {
                            info.SetValue(s, item[i], null);
                        }
                    }
                }
                list.Add(s);
            }
            return list;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(LeaveMsg entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(LeaveMsg entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(LeaveMsg entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public LeaveMsg One(IQueryable<LeaveMsg> query, LeaveMsg entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<LeaveMsg> Many(IQueryable<LeaveMsg> query, LeaveMsg entity)
        {
            var entitys = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntBelongTablePrikeyID != 0)
                {
                    entitys = entitys.Where(e => e.IntBelongTablePrikeyID == entity.IntBelongTablePrikeyID);
                }

                if (entity.IntBelongTable != 0)
                {
                    entitys = entitys.Where(e => e.IntBelongTable == entity.IntBelongTable);
                }
                if (entity.IntReviceUserID != 0)
                {
                    entitys = entitys.Where(p => p.IntReviceUserID == entity.IntReviceUserID);
                }
                if (!string.IsNullOrWhiteSpace(entity.VarTitle))
                {
                    entitys = entitys.Where(p => p.VarTitle.Contains(entity.VarTitle));
                }
                if (entity.IntMsgType != 0)
                {
                    entitys = entitys.Where(p => p.IntMsgType == entity.IntMsgType);
                }
            }

            entitys = entitys.Where(e => e.IntFlag != 0);

            return entitys;
        }

        #endregion

    }
}

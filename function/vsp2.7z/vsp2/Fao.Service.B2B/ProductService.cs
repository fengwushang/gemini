﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Product服务实现-Power by CodeGG
    /// </summary>
    public class ProductService : Entity<Product>, IProductService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmProduct查询模型，返回VmProduct视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmProduct> GetProducts(SmProduct searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmProduct视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmProduct GetProductByID(int id)
        {
            VmProduct model = null;
            using (var context = new FaoB2BEntities())
            {
                Product product = One(context.Products, new Product()
                {
                    IntProductID = id
                });
                if (product != null)
                    model = new VmProduct()
                    {
                        IntProductID = product.IntProductID,
                        VarProductName = product.VarProductName
                    };
            }
            return model;
        }

        /// <summary>
        /// 根据询价产品id 集合串，返回VmProduct视图模型列表
        /// </summary>
        /// <param name="ids">询价产品id 集合串</param>
        /// <returns>视图模型列表</returns>
        public List<VmProduct> GetProductsByIDs(string ids)
        {
            List<VmProduct> list = null;
            string[] arrStr = ids.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            int[] arrInt = new int[arrStr.Length];
            for (int i = 0; i < arrStr.Length; i++)
            {
                int n = 0;
                int.TryParse(arrStr[i], out n);
                arrInt[i] = n;
            }
            using (var context = new FaoB2BEntities())
            {
                list = context.Products.Select(p => new VmProduct()
               {
                   IntProductID = p.IntProductID,
                   VarProductName = p.VarProductName
               }).Where(p => arrInt.Any(a => a == p.IntProductID)).ToList();
            }
            return list;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(Product entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(Product entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(Product entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public Product One(IQueryable<Product> query, Product entity)
        {
            var list = query.Select(p => p);
            Product product = new Product();
            if (entity.IntProductID > 0)
                product = list.Where(p => p.IntProductID == entity.IntProductID).FirstOrDefault();
            return product;
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<Product> Many(IQueryable<Product> query, Product entity)
        {
            throw new Exception("没有实现");
        }

        #endregion

    }
}
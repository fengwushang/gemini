﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// LogisticVehicleSource服务实现-Power by CodeGG
    /// </summary>
    public class LogisticVehicleSourceService : Entity<LogisticVehicleSource>, ILogisticVehicleSourceService
    {

        #region 业务接口引用

        IEnterpriseService enterpriseService = new EnterpriseService();
        IBaseUserService baseUserService = new BaseUserService();
        IBaseAreaService baseAreaService = new BaseAreaService();
        IBaseDictionaryService baseDictionaryService = new BaseDictionaryService();
        IAttachmentService attachmentService = new AttachmentService();
        ILogisticVehicleService logisticVehicleService = new LogisticVehicleService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmLogisticVehicleSource查询模型，返回VmLogisticVehicleSource视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmLogisticVehicleSource> GetLogisticVehicleSources(SmLogisticVehicleSource searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmLogisticVehicleSource视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmLogisticVehicleSource GetLogisticVehicleSourceByID(string id)
        {
            VmLogisticVehicleSource vehicleSource = new VmLogisticVehicleSource();
            int cid = Utils.ToInt(Security.Decrypt(id));
            var list = GetLogisticVehicleSourcesWithPage(new SmLogisticVehicleSource() { ID = cid }, 1, 1);
            if (list.rows.Count > 0)
            {
                vehicleSource = list.rows[0];
            }
            return vehicleSource;
        }

        /// <summary>
        /// 获取分页数据 车源
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        public LogisticVehicleSourcePaging GetLogisticVehicleSourcesWithPage(SmLogisticVehicleSource searchModel, int pageIndex, int pageCount)
        {
            LogisticVehicleSourcePaging page = new LogisticVehicleSourcePaging();

            #region 原代码
            //using (var context = new FaoB2BEntities())
            //{
            //    var VehicleSources = Many(context.LogisticVehicleSources, null).Where(c => c.IntFlag == 3);
            //    if (searchModel != null)
            //    {
            //        if (searchModel.ID > 0)
            //        {
            //            VehicleSources = VehicleSources.Where(c => c.IntVehicleSourceID == searchModel.ID);
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.KeyWord))
            //        {
            //            VehicleSources = VehicleSources.Where(c => c.VarDetails.Contains(searchModel.KeyWord));
            //        }
            //        if (searchModel.AreaIDStart > 0)
            //        {
            //            var area = baseAreaService.Many(context.BaseAreas, null).Where(a => a.IntAreaID == searchModel.AreaIDStart
            //                        || a.IntAreaParentID == searchModel.AreaIDStart).Select(a => a.IntAreaID).ToArray();
            //            VehicleSources = VehicleSources.Where(c => area.Contains(c.IntAreaIDStart));
            //        }
            //        if (searchModel.AreaIDEnd > 0)
            //        {
            //            var area = baseAreaService.Many(context.BaseAreas, null).Where(a => a.IntAreaID == searchModel.AreaIDEnd
            //                       || a.IntAreaParentID == searchModel.AreaIDEnd).Select(a => a.IntAreaID).ToArray();
            //            VehicleSources = VehicleSources.Where(c => area.Contains(c.IntAreaIDEnd));
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.DteRefreshStart))
            //        {
            //            DateTime dteRefreshStart = new DateTime();
            //            if (DateTime.TryParse(searchModel.DteRefreshStart, out dteRefreshStart))
            //            {
            //                VehicleSources = VehicleSources.Where(c => c.DteRefresh >= dteRefreshStart);
            //            }
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.DteRefreshEnd))
            //        {
            //            DateTime dteRefreshEnd = new DateTime();
            //            if (DateTime.TryParse(searchModel.DteRefreshEnd, out dteRefreshEnd))
            //            {
            //                VehicleSources = VehicleSources.Where(c => c.DteRefresh <= dteRefreshEnd);
            //            }
            //        }
            //    }

            //    var user = baseUserService.Many(context.BaseUsers, null);
            //    var ent = enterpriseService.Many(context.Enterprises, null);
            //    var dict = baseDictionaryService.Many(context.BaseDictionaries, null);
            //    var vehicle = logisticVehicleService.Many(context.LogisticVehicles, null);

            //    var entity = from c in VehicleSources
            //                 join e in ent on c.IntEnterpriseID equals e.IntEnterpriseID
            //                 join u in user on c.IntCreateUserID equals u.IntUserID
            //                 join v in vehicle on c.IntVehicleID equals v.IntVehicleID
            //                 join d in dict on v.IntVehicleType equals d.IntItemID
            //                 select new
            //                 {
            //                     AreaIDEnd = c.IntAreaIDEnd,
            //                     AreaIDStart = c.IntAreaIDStart,
            //                     Contact = c.VarContact,
            //                     Details = c.VarDetails,
            //                     BrowserCount = c.IntBrowserCount,
            //                     DteCreate = c.DteCreate,
            //                     DteRefresh = c.DteRefresh,
            //                     DteValid = c.DteValid,
            //                     EntID = c.IntEnterpriseID,
            //                     EntName = e.VarEnterpriseName,
            //                     UserID = c.IntCreateUserID,
            //                     UserName = u.VarRealName,
            //                     Flag = c.IntFlag,
            //                     Phone = c.VarPhone,
            //                     VehicleID = c.IntVehicleID,
            //                     VehicleSourceID = c.IntVehicleSourceID,
            //                     Type = d.VarItemName,
            //                     Vehicle = v
            //                 };
            //    page.total = entity.Count();
            //    var list = entity.OrderByDescending(c => c.DteRefresh).Skip((pageIndex - 1) * pageCount).Take(pageCount).ToList();

            //    var VehicleSourceIDs = list.Select(e => e.VehicleSourceID).ToList();

            //    var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 4)
            //           , VehicleSourceIDs)
            //           .Select(e => new
            //           {
            //               e.IntBelongTablePrikeyID,
            //               e.VarFilePath
            //           }).ToList();



            //    var areaStartIDs = list.Select(e => e.AreaIDStart).ToList();
            //    var areaEndIDs = list.Select(e => e.AreaIDEnd).ToList();
            //    var areaStartList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaStartIDs);
            //    var areaEndList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaEndIDs);

            //    var rows = (
            //        from c in list
            //        join a1 in areaStartList on c.AreaIDStart equals a1.AreaID
            //        join a2 in areaEndList on c.AreaIDEnd equals a2.AreaID
            //        join a in attList on c.VehicleSourceID equals a.IntBelongTablePrikeyID
            //        select new VmLogisticVehicleSource
            //        {
            //            AreaIDEnd = c.AreaIDEnd,
            //            AreaIDStart = c.AreaIDStart,
            //            Contact = c.Contact,
            //            Details = c.Details,
            //            BrowserCount = c.BrowserCount,
            //            DteCreate = c.DteCreate.ToString("yyyy-MM-dd"),
            //            DteRefresh = c.DteRefresh.ToString("yyyy-MM-dd"),
            //            DteValid = c.DteValid.Year == DateTime.MaxValue.Year ? "永久有效" : Common.Utils.GetDateFormate(c.DteValid),
            //            EndArea = a2.Name,
            //            EntID = Security.Encrypt(c.EntID),
            //            EntName = c.EntName,
            //            StartArea = a1.Name,
            //            UserID = c.UserID,
            //            UserName = c.UserName,
            //            Flag = c.Flag,
            //            Phone = c.Phone,
            //            VehicleID = c.VehicleID,
            //            VehicleSourceID = Common.Security.Encrypt(c.VehicleSourceID),
            //            ImgUrl = a.VarFilePath,
            //            Vehicle = new VmLogisticVehicle()
            //            {
            //                LicenseNum = c.Vehicle.VarLicenseNum,
            //                VehicleNumber = c.Vehicle.VarVehicleNum,
            //                Type = c.Type,
            //                VehicleSize = c.Vehicle.VaVehicleSize,
            //                MaxLoad = c.Vehicle.VarMaxLoad,
            //                MaxVolume = c.Vehicle.VarMaxVolume,
            //                IsGPS = c.Vehicle.IntIsGPS,
            //                IsInsurance = c.Vehicle.IntIsInsurance,
            //                IsTemp = c.Vehicle.IntIsTemp
            //            }
            //        }).ToList();

            //    page.rows = rows;
            //}
            #endregion

            #region 新代码
            using (var context = new FaoB2BEntities())
            {
                IEnumerable<VmLogisticVehicleSource> entities = null;
                //根据ID获取该条记录
                if (searchModel.ID > 0)
                {
                    entities = context.Database.SqlQuery<VmLogisticVehicleSource>("ProcGetSearchVehicleByID @p0", searchModel.ID);
                    page.total = entities.Count();
                }
                else
                {
                    //分页数据
                    entities = context.Database.SqlQuery<VmLogisticVehicleSource>(
                       "ProcGetSearchVehicle @p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7"
                       , searchModel.AreaIDStart
                       , searchModel.AreaIDEnd
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshStart) ? string.Empty : Utils.ToDateFormate( searchModel.DteRefreshStart)
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshEnd) ? string.Empty : Utils.ToDateFormate(searchModel.DteRefreshEnd)
                       , 8
                       , string.IsNullOrWhiteSpace(searchModel.KeyWord) ? string.Empty : searchModel.KeyWord
                       , pageIndex
                       , pageCount
                       );

                    page.total = context.Database.SqlQuery<int>(
                       "ProcGetSearchVehicleCount @p0,@p1,@p2,@p3,@p4,@p5"
                       , searchModel.AreaIDStart
                       , searchModel.AreaIDEnd
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshStart) ? string.Empty : Utils.ToDateFormate( searchModel.DteRefreshStart)
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshEnd) ? string.Empty : Utils.ToDateFormate( searchModel.DteRefreshEnd)
                       , 8
                       , string.IsNullOrWhiteSpace(searchModel.KeyWord) ? string.Empty : searchModel.KeyWord
                       ).FirstOrDefault();
                }

                var list = entities.ToList().Select(e => new
                {
                    AreaIDEnd = e.AreaIDEnd,
                    AreaIDStart = e.AreaIDStart,
                    Contact = e.Contact,
                    Details = e.Details,
                    BrowserCount = e.BrowserCount,
                    DteCreate = e.DteCreate,
                    DteRefresh = e.DteRefresh,
                    DteValid = e.DteValid,

                    EntID = e.EntID,
                    EntName = e.EntName,
                    UserID = e.UserID,
                    UserName = e.UserName,
                    Flag = e.Flag,
                    Phone = e.Phone,
                    VehicleID = e.VehicleID,
                    VehicleSourceID = Utils.ToInt(e.VehicleSourceID.ToString()),
                    Type = e.Type,
                    Vehicle = e.Vehicle,

                    PPCID = e.PPCID,
                    EndArea = e.EndArea,
                    StartArea = e.StartArea,
                    ValidDate = e.ValidDate,
                    Sms = e.Sms,
                }).ToList();

                //获取分页数据主键集合
                var VehicleSourceIDs = list.Select(e => e.VehicleSourceID);

                //获取附件集合
                var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 4)
                      , VehicleSourceIDs)
                      .Select(e => new
                      {
                          e.IntBelongTablePrikeyID,
                          e.VarFilePath
                      }).ToList();


                var areaStartIDs = list.Select(e => e.AreaIDStart).ToList();
                var areaEndIDs = list.Select(e => e.AreaIDEnd).ToList();

                var areaStartList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaStartIDs);
                var areaEndList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaEndIDs);

                var VehicleService = logisticVehicleService.Many(context.LogisticVehicles, null);

                var rows = (from c in list
                            join a1 in areaStartList on c.AreaIDStart equals a1.AreaID
                            join a2 in areaEndList on c.AreaIDEnd equals a2.AreaID
                            join a in attList on c.VehicleSourceID equals a.IntBelongTablePrikeyID
                            join v in VehicleService on c.VehicleID equals v.IntVehicleID
                            select new VmLogisticVehicleSource
                   {
                       AreaIDEnd = c.AreaIDEnd,
                       AreaIDStart = c.AreaIDStart,
                       Contact = c.Contact,
                       Details = c.Details,
                       BrowserCount = c.BrowserCount,
                       DteCreate = c.DteCreate,
                       DteRefresh = c.DteRefresh,
                       DteValid = Convert.ToDateTime(c.DteValid).Year == DateTime.MaxValue.Year ? "永久有效" : c.DteValid,
                       EndArea = a2.Name,
                       EntID = Security.Encrypt(c.EntID),
                       EntName = c.EntName,
                       StartArea = a1.Name,
                       UserID = c.UserID,
                       UserName = c.UserName,
                       Flag = c.Flag,
                       Phone = c.Phone,
                       VehicleID = c.VehicleID,
                       VehicleSourceID = Common.Security.Encrypt(c.VehicleSourceID),
                       ImgUrl = a.VarFilePath,
                       Vehicle = new VmLogisticVehicle()
                       {
                           LicenseNum = v.VarLicenseNum,
                           VehicleNumber = v.VarVehicleNum,
                           Type = c.Type,
                           VehicleSize = v.VaVehicleSize,
                           MaxLoad = v.VarMaxLoad,
                           MaxVolume = v.VarMaxVolume,
                           IsGPS = v.IntIsGPS,
                           IsInsurance = v.IntIsInsurance,
                           IsTemp = v.IntIsTemp
                       },
                       PPCID = c.PPCID,
                       Sms = Security.Encrypt(c.Sms)
                   }).ToList();
                page.rows = rows;
            }
            #endregion
            return page;
        }


        /// <summary>
        /// 添加车源信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddVechicleSourceInfo(VmLogisticVehicleSource model, VmB2BInfoPicture picture)
        {
            int flag = 0;
            string str = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                LogisticVehicleSource entity = new LogisticVehicleSource();
                var enterprise = enterpriseService.GetCurrentEnterprise(context);
                if (user == null)
                {
                    str = "用户未登陆";
                }
                else
                {
                    string strID = string.Empty;
                    int id = 0;
                    if (enterprise != null)
                    {
                        strID = Security.Decrypt(enterprise.EntID);
                        strID = strID == "" ? enterprise.EntID : strID;
                        int.TryParse(strID, out id);
                    }
                    entity.IntCreateUserID = user.IntUserID;
                    entity.IntEnterpriseID = id;
                    entity.DteCreate = DateTime.Now;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.IntVehicleID = model.VehicleID;
                    entity.DteRefresh = DateTime.Now;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.IntAreaIDEnd = model.AreaIDEnd;
                    entity.IntAreaIDStart = model.AreaIDStart;
                    entity.IntBrowserCount = 0;
                    entity.VarContact = model.Contact;
                    entity.VarDetails = model.Details == null ? string.Empty : model.Details;
                    entity.VarPhone = model.Phone;
                    context.LogisticVehicleSources.Add(entity);
                    flag = context.SaveChanges();
                    SaveImage(context, entity.IntVehicleSourceID, picture);
                    if (flag >= 0)
                    {
                        str = "1";
                    }
                    else
                    {
                        str = "保存失败";
                    }
                }

            }
            return str;
        }

        /// <summary>
        /// 修改车源信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateVehicleSourceInfo(VmLogisticVehicleSource model, VmB2BInfoPicture picture = null)
        {
            int flag = 0;
            string strID = Common.Security.Decrypt(model.VehicleSourceID);
            int id;
            if (!int.TryParse(strID, out id))
            {
                return "未提到该记录";
            }
            using (var context = new FaoB2BEntities())
            {
                var entity = context.LogisticVehicleSources.Find(id);
                if (entity != null)
                {
                    entity.IntFlag = model.Flag ?? 1;
                    entity.IntVehicleID = model.VehicleID;
                    entity.DteRefresh = model.RefreshDate ?? DateTime.Now;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.IntAreaIDEnd = model.AreaIDEnd;
                    entity.IntAreaIDStart = model.AreaIDStart;
                    entity.VarContact = model.Contact;
                    entity.VarDetails = model.Details == null ? string.Empty : model.Details;
                    entity.VarPhone = model.Phone;
                }
                flag = context.SaveChanges();
                if (picture != null)
                {
                    SaveImage(context, entity.IntVehicleSourceID, picture);
                    //删除 热词推广 信息
                    //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                    PPCService pPCService = new PPCService();
                    pPCService.DeletePPC(8, entity.IntVehicleSourceID);
                }
            }
            if (flag >= 0)
            {
                return "1";
            }
            return "保存失败";
        }

        /// <summary>
        /// 根据ID得到车源信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmLogisticVehicleSource GetVehicleSourceInfoBy(string encriptID)
        {
            VmLogisticVehicleSource vm = null;
            using (var context = new FaoB2BEntities())
            {
                string strID = Security.Decrypt(encriptID);
                int id = 0;
                int.TryParse(strID, out id);
                var entity = context.LogisticVehicleSources.Find(id);
                var attList = attachmentService.GetAttachmentsByTablePK(context, id, 4);
                if (entity != null)
                {
                    var startArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDStart }).FirstOrDefault();
                    var endArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDEnd }).FirstOrDefault();
                    var vehicle = logisticVehicleService.GetLogisticVehicleByID(context, Security.Encrypt(entity.IntVehicleID));
                    vm = new VmLogisticVehicleSource()
                    {
                        VehicleSourceID = Security.Encrypt(id),
                        AreaIDEnd = entity.IntAreaIDEnd,
                        AreaIDStart = entity.IntAreaIDStart,
                        Contact = entity.VarContact,
                        Details = entity.VarDetails,
                        ValidDate = entity.DteValid,
                        Phone = entity.VarPhone,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                        StartArea = startArea != null ? startArea.Name : "",
                        EndArea = endArea != null ? endArea.Name : "",
                        VehicleID = entity.IntVehicleID,
                        Flag = entity.IntFlag,
                        LicenseNum = vehicle != null ? vehicle.LicenseNum : "",
                        DteValid = Utils.GetDateWithHMFormate(entity.DteValid)
                    };
                }
                return vm;
            }
        }

        /// <summary>
        /// 根据ID得到车源信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmLogisticVehicleSource GetVehicleSourceInfoBy(FaoB2BEntities context, string encriptID)
        {
            VmLogisticVehicleSource vm = null;
            string strID = Security.Decrypt(encriptID);
            int id = 0;
            int.TryParse(strID, out id);
            var entity = context.LogisticVehicleSources.Find(id);
            var attList = attachmentService.GetAttachmentsByTablePK(context, id, 4);
            if (entity != null)
            {
                var startArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDStart }).FirstOrDefault();
                var endArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDEnd }).FirstOrDefault();
                var vehicle = logisticVehicleService.GetLogisticVehicleByID(context, Security.Encrypt(entity.IntVehicleID));
                vm = new VmLogisticVehicleSource()
                {
                    VehicleSourceID = Security.Encrypt(id),
                    AreaIDEnd = entity.IntAreaIDEnd,
                    AreaIDStart = entity.IntAreaIDStart,
                    Contact = entity.VarContact,
                    Details = entity.VarDetails,
                    ValidDate = entity.DteValid,
                    Phone = entity.VarPhone,
                    ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                    ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                    StartArea = startArea != null ? startArea.Name : "",
                    EndArea = endArea != null ? endArea.Name : "",
                    VehicleID = entity.IntVehicleID,
                    Flag = entity.IntFlag,
                    LicenseNum = vehicle != null ? vehicle.LicenseNum : "",
                    DteValid = Utils.GetDateWithHMFormate(entity.DteValid)
                };
            }
            return vm;
        }


        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public LogisticVehicleSourcePaging GetVehicleSourcePager(SmLogisticVehicleSource search, int page, int rows)
        {
            LogisticVehicleSourcePaging pager = new LogisticVehicleSourcePaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmLogisticVehicleSource>("ProcGetVehicleSourceList @p0,@p1,@p2,@p3,@p4,@p5",
                    string.IsNullOrWhiteSpace(search.LicenseNum) ? "" : search.LicenseNum
                    , search.state
                     , search.ISTG ?? string.Empty
                    , user.IntUserID
                    , page
                    , rows);

                    pager.total = context.Database.SqlQuery<int>("ProcGetVehicleSourceListCount @p0,@p1,@p2,@p3",
                        string.IsNullOrWhiteSpace(search.LicenseNum) ? "" : search.LicenseNum
                        , search.state
                         , search.ISTG ?? string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();

                    pager.rows = list.OrderByDescending(l => l.RefreshDate).Skip((page - 1) * rows)
                        .Take(rows).Select(p => new VmLogisticVehicleSource
                        {
                            VehicleSourceID = Security.Encrypt(p.VehicleSourceID),
                            LicenseNum = p.LicenseNum,
                            StartArea = p.StartArea,
                            EndArea = p.EndArea,
                            BrowserCount = p.BrowserCount,
                            DteRefresh = p.DteRefresh,
                            ISTG = p.ISTG
                        }).ToList();
                }
            }
            return pager;
        }

        /// <summary>
        /// 得到统计车辆信息
        /// </summary>
        /// <param name="type"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public VmCountInfo GetVehicleSourceInfoCount()
        {
            VmCountInfo count = new VmCountInfo();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCountInfo>("ProcGetVehicleSourceCountInfo @p0", user.IntUserID);
                    count = list.FirstOrDefault();
                }
            }
            return count;
        }


        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,2刷新,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        public string VehicleSourceBatch(int type, string chooses)
        {
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                string[] IDs = chooses.Split(',');
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.LogisticVehicleSources.Find(id);
                        if (entity != null)
                        {
                            if (type == 1)
                            {
                                entity.IntFlag = 0;
                            }
                            else if (type == 2 && entity.IntFlag == 3)
                            {
                                entity.DteRefresh = DateTime.Now;
                            }
                            else if (type == 3 && entity.IntFlag == 1)
                            {
                                entity.IntFlag = 2;
                            }
                        }
                    }
                }
                flag = context.SaveChanges();
            }
            if (flag >= 0)
            {
                return "1";
            }
            return "0";
        }

        /// <summary>
        /// 得到审批分页信息
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public LogisticVehicleSourcePaging GetAuditingPager(SmLogisticVehicleSource sm, int page, int rows)
        {
            LogisticVehicleSourcePaging pager = new LogisticVehicleSourcePaging();
            using (var context = new FaoB2BEntities())
            {
                var list = context.Database.SqlQuery<VmLogisticVehicleSource>("ProcGetVehicleSourceList @p0,@p1,@p2,@p3,@p4,@p5", 
                    string.IsNullOrWhiteSpace(sm.LicenseNum) ? "" : sm.LicenseNum
                    , 2
                    , 0
                    ,0
                    ,page
                    ,rows
                    );

                pager.total = context.Database.SqlQuery<int>("ProcGetVehicleSourceListCount @p0,@p1,@p2,@p3",
                    string.IsNullOrWhiteSpace(sm.LicenseNum) ? "" : sm.LicenseNum, 2, 0,0).FirstOrDefault();

                pager.rows = list.OrderBy(l => l.VehicleSourceID).Skip((page - 1) * rows)
                    .Take(rows).Select(p => new VmLogisticVehicleSource
                    {
                        VehicleSourceID = Security.Encrypt(p.VehicleSourceID),
                        LicenseNum = p.LicenseNum,
                        StartArea = p.StartArea,
                        EndArea = p.EndArea,
                        BrowserCount = p.BrowserCount,
                        DteRefresh = p.DteRefresh,
                        Contact = p.Contact
                    }).ToList();

            }
            return pager;
        }

        /// <summary>
        /// 审批信息
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        public string Auditing(string ID, int Result)
        {
            string str = "未找到该信息";
            string strID = Security.Decrypt(ID);
            int id = 0;
            if (!int.TryParse(strID, out id))
            {
                return str;
            }
            using (var context = new FaoB2BEntities())
            {
                var entity = context.LogisticVehicleSources.Find(id);
                if (entity != null)
                {
                    if (entity.IntFlag != 2)
                    {
                        str = "该信息不审批";
                    }
                    else
                    {
                        entity.IntFlag = Result;
                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            str = "1";
                        }
                    }
                }
            }
            return str;
        }
        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="model"></param>
        public void UpdateBrowserCount(VmLogisticVehicleSource model)
        {
            using (var context = new FaoB2BEntities())
            {
                int id = Utils.ToInt(Security.Decrypt(model.VehicleSourceID));
                var entity = context.LogisticVehicleSources.Find(id);
                entity.IntBrowserCount++;
                context.SaveChanges();
            }
        }

        #endregion

        #region 辅助方法

        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="infoID">对应的信息ID</param>
        /// <returns></returns>
        private void SaveImage(FaoB2BEntities context, int infoID, VmB2BInfoPicture picture)
        {
            int i = 0;
            int j = 1;
            while (true)
            {
                if (picture.PictureUrls[i] != "" || picture.PictureIDs[i] != "")
                {
                    int id = 0;
                    string strID = Security.Decrypt(picture.PictureIDs[i]);
                    int.TryParse(strID, out id);
                    if (SaveImage(context, picture.PictureUrls[i], picture.OriginalName[i], infoID, j, id))
                    {
                        j++;
                    }
                }
                i++;
                if (i > 2)
                {
                    break;
                }
            }

        }
        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="originalName"></param>
        /// <param name="infoID"></param>
        /// <param name="orderID"></param>
        /// <param name="imageID"></param>
        private bool SaveImage(FaoB2BEntities context, string fileName, string originalName, int infoID, int orderID, int imageID = 0)
        {
            bool flag = false;
            VmAttachment oldAtt = null;
            if (imageID != 0)
            {
                oldAtt = attachmentService.GetAttachmentByID(context, imageID.ToString());
            }
            if (fileName != "" && originalName != "")
            {
                VmAttachment attachment = new VmAttachment();
                attachment.BelongTable = 4;
                attachment.PK = infoID;
                attachment.FileName = originalName;
                attachment.Path = fileName;
                attachment.Descrip = "";
                attachment.Order = orderID;
                if (imageID == 0)
                {
                    attachmentService.AddAttachment(context, attachment);

                }
                else
                {
                    attachment.ID = imageID;
                    attachmentService.UpdateAttachment(context, attachment);
                }
                flag = true;
            }
            else if (fileName == "" && imageID != 0)
            {
                attachmentService.DeleteAttachment(context, imageID);
                flag = false;
            }
            else if (oldAtt != null && oldAtt.Order != orderID)
            {
                oldAtt.Order = orderID;
                attachmentService.UpdateAttachment(context, oldAtt);
                flag = true;
            }
            else if (fileName != "" && imageID != 0)
            {
                flag = true;
            }
            return flag;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(LogisticVehicleSource entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(LogisticVehicleSource entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(LogisticVehicleSource entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public LogisticVehicleSource One(IQueryable<LogisticVehicleSource> query, LogisticVehicleSource entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<LogisticVehicleSource> Many(IQueryable<LogisticVehicleSource> query, LogisticVehicleSource entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntCreateUserID != 0)
                {
                    entities = entities.Where(p => p.IntCreateUserID == entity.IntCreateUserID);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;


namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Area服务实现-Power by CodeGG
    /// </summary>
    public class BaseAreaService : Entity<BaseArea>, IBaseAreaService
    {

        #region 业务接口引用

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmArea查询模型，返回VmArea视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmBaseArea> GetAreas(SmBaseArea searchModel)
        {
            var vmAreaList = new List<VmBaseArea>();
            using (var context = new FaoB2BEntities())
            {
                //var list = Many(context.BaseAreas, null)
                //    .Where(p => p.IntAreaParentID == searchModel.ParentID).OrderBy(p => p.IntOrderID)
                //    .ToList();
                var list = Many(context.BaseAreas, null)
                    .Where(p => p.IntAreaParentID == searchModel.ParentID).OrderBy(p => p.IntOrderID)
                    .ToList();
                if (searchModel.ParentID == 0)
                {
                    var arealist = Many(context.BaseAreas, new BaseArea { IntAreaParentID = 836 }).Where(a => a.IntAreaParentID==836).Select(e => e.IntAreaID);
                    list = Many(context.BaseAreas, null)
                        .Where(p => arealist.Contains(p.IntAreaParentID))
                        .OrderBy(p => p.IntOrderID).ToList()
                        .ToList();
                }
                
                vmAreaList = list.Select(a => new VmBaseArea
                {
                    _parentId = a.IntAreaParentID,
                    AbbName = a.VaAreaNameAbb,
                    Name = a.VarAreaName,
                    AreaID = a.IntAreaID,
                    Code = a.VarAreaCode,
                    Zip = a.VarZipCode,
                    IsPost = a.IntIsPost.ToString(),
                    ParentID = a.IntAreaParentID,
                    state = "closed"
                }).ToList();
            }

            return vmAreaList;
        }

        /// <summary>
        /// 根据id，返回VmArea视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmBaseArea GetAreaByID(string id)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除地区,1删除成功，2已删除，其他为删除失败
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int DeleteArea(int id)
        {
            int rv = 0;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseAreas.Find(id);
                if (entity == null)
                {
                    rv = 2;
                }
                else
                {
                    entity.IntFlag = 0;
                    rv = context.SaveChanges();
                }
            }

            return rv;
        }

        /// <summary>
        /// 更新地区
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateArea(VmBaseArea model)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                if (model == null)
                {
                    rv = "保存失败";
                }
                else
                {
                    string name = model.Name;
                    int parentID = model.ParentID;
                    int id = model.AreaID;
                    var e = Many(context.BaseAreas, null).Where(p => p.VarAreaName == name && p.IntAreaParentID == parentID && p.IntAreaID != id).Count();
                    if (e > 0)
                    {
                        rv = "该地区名称已存在";
                    }
                    else
                    {
                        var entity = context.BaseAreas.Find(model.AreaID);
                        if (entity != null)
                        {
                            entity.VarAreaName = model.Name;
                            entity.VaAreaNameAbb = model.AbbName;
                            entity.IntIsPost = Utils.ToInt(model.IsPost);
                            entity.VarZipCode = model.Zip == null ? string.Empty : model.Zip;
                            entity.VarAreaCode = model.Code == null ? string.Empty : model.Code;
                            int flag = context.SaveChanges();
                            if (flag >= 0)
                            {
                                rv = "1";
                            }
                            else
                            {
                                rv = "保存失败";
                            }
                        }
                        else
                        {
                            rv = "保存失败";
                        }
                    }
                }
            }

            return rv;
        }

        /// <summary>
        /// 添加地区
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddArea(VmBaseArea model)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var adminID = HtmlHelper.GetCookieValue("AdminID");
                string name = model.Name;
                int parentID = model.ParentID;
                var e = Many(context.BaseAreas, null).Where(p => p.VarAreaName == name && p.IntAreaParentID == parentID).Count();
                if (e > 0)
                {
                    rv = "该地区名称已存在";
                }
                else
                {
                    int orderID = Many(context.BaseAreas, null).Where(p => p.IntAreaParentID == model.ParentID).Count();
                    var entity = new BaseArea
                    {
                        DteCreate = DateTime.Now,
                        IntAreaParentID = model.ParentID,
                        VarAreaName = model.Name,
                        VaAreaNameAbb = model.AbbName,
                        IntIsPost = Utils.ToInt(model.IsPost),
                        VarZipCode = model.Zip == null ? string.Empty : model.Zip,
                        VarAreaCode = model.Code == null ? string.Empty : model.Code,
                        IntOrderID = orderID + 1,
                        IntCreateUserID = Utils.ToInt(adminID),
                        IntFlag = 1,
                        VarSearch = string.Empty,
                        IntAreaID = 0
                    };

                    context.BaseAreas.Add(entity);
                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        rv = "1";
                    }
                    else
                    {
                        rv = "保存失败";
                    }
                }
            }
            return rv;
        }

        /// <summary>
        /// 地区上移
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string ItemUP(int id)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseAreas.Find(id);
                if (entity != null)
                {
                    if (entity.IntOrderID > 1)
                    {
                        entity.IntOrderID--;
                        var pre = Many(context.BaseAreas, null)
                            .Where(p => p.IntAreaParentID == entity.IntAreaParentID && p.IntOrderID == entity.IntOrderID)
                            .FirstOrDefault();
                        if (pre != null)
                        {
                            pre.IntOrderID++;
                        }
                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            rv = "1";
                        }
                        else
                        {
                            rv = "-1";
                        }
                    }
                    else
                    {
                        rv = "该项已经是第一位，不能再移了";
                    }

                }
                else
                {
                    rv = "";
                }
            }
            return rv;
        }

        /// <summary>
        /// 地区下移
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string ItemDown(int id)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseAreas.Find(id);
                if (entity != null)
                {
                    var max = Many(context.BaseAreas, null).Where(p => p.IntAreaParentID == entity.IntAreaParentID).Max(p => p.IntOrderID);
                    if (entity.IntOrderID < max)
                    {
                        entity.IntOrderID++;
                        var pre = Many(context.BaseAreas, null)
                            .Where(p => p.IntAreaParentID == entity.IntAreaParentID && p.IntOrderID == entity.IntOrderID)
                            .FirstOrDefault();
                        if (pre != null)
                        {
                            pre.IntOrderID--;
                        }
                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            rv = "1";
                        }
                        else
                        {
                            rv = "-1";
                        }
                    }
                    else
                    {
                        rv = "该项已经是最后一位，不能再移了";
                    }

                }
                else
                {
                    rv = "";
                }
            }
            return rv;
        }


        /// <summary>
        /// 返回地区信息的id，名称，父地区名称数据等。
        /// </summary>
        /// <param name="areaIDs">需要获取的地区id集合</param>
        /// <returns></returns>
        public List<VmBaseArea> GetAreasWithParentName(IQueryable<BaseArea> query, List<int> areaIDs)
        {
            var discAreaIDs = areaIDs.Distinct();

            var areas = Many(query, null)
                .Where(a => discAreaIDs.Contains(a.IntAreaID));
            var joinArea = areas.GroupJoin(Many(query, null),
                  a => a.IntAreaParentID,
                  p => p.IntAreaID,
                  (a, ja) =>
                     new
                     {
                         a = a,
                         ja = ja
                     }
               )
               .SelectMany(
                  temp0 => temp0.ja.DefaultIfEmpty(),
                  (temp0, j) =>
                     new
                     {
                         ID = temp0.a.IntAreaID,
                         Name = temp0.a.VarAreaName,
                         Name2 = j.VarAreaName
                     }
               );

            var list = joinArea.ToList().Select(a => new VmBaseArea
            {
                AreaID = a.ID,
                Name = a.Name2 + " " + a.Name
            }).ToList();

            var dbAreaIDs = list.Select(a => a.AreaID).ToList();

            foreach (var aid in discAreaIDs)
            {
                if (!dbAreaIDs.Contains(aid))
                {
                    list.Add(new VmBaseArea
                    {
                        AreaID = aid,
                        Name = "无效地区"
                    });
                }
            }

            return list;

        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(BaseArea entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(BaseArea entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(BaseArea entity)
        {
            if (entity != null)
            {
                entity.IntFlag = 0;
            }

            return string.Empty;
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public BaseArea One(IQueryable<BaseArea> query, BaseArea entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<BaseArea> Many(IQueryable<BaseArea> query, BaseArea entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntAreaID > 0)
                {
                    entities = entities.Where(e => e.IntAreaID == entity.IntAreaID);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion


    }
}
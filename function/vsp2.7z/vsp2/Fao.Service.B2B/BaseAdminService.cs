﻿using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Data.B2B;
using Fao.Common;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-21 10:32:34
    /// BaseAdmin服务实现-Power by CodeGG
    /// </summary>
    public class BaseAdminService : Entity<BaseAdmin>, IBaseAdminService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmBaseAdmin查询模型，返回VmBaseAdmin分页数据
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <param name="pageIndex">页所引</param>
        /// <param name="pageCount">页记录数</param>
        /// <returns>分页数据</returns>
        public BaseAdminPaging GetBaseAdmins(SmBaseAdmin searchModel, int pageIndex, int pageCount)
        {
            BaseAdminPaging page = new BaseAdminPaging();
            using (var context = new FaoB2BEntities())
            {


                var baseAdmin = context.BaseAdmins.Select(a => a);

                baseAdmin = baseAdmin.Where(a => a.IntFlag != 0);

                if (!string.IsNullOrEmpty(searchModel.VarAdminName))
                    baseAdmin = baseAdmin.Where(a => a.VarAdminName.Contains(searchModel.VarAdminName));

                if (!string.IsNullOrEmpty(searchModel.VarRealName))
                    baseAdmin = baseAdmin.Where(a => a.VarRealName.Contains(searchModel.VarRealName));

                if (!string.IsNullOrEmpty(searchModel.VarAuthority))
                    baseAdmin = baseAdmin.Where(a => a.VarAuthority.Contains(searchModel.VarAuthority));

                page.total = baseAdmin.Count();

                var rows = baseAdmin.Select(a => new VmBaseAdmin
                {
                    IntAdminID = a.IntAdminID,
                    IntSex = a.IntSex,
                    VarAdminName = a.VarAdminName,
                    VarAuthority = a.VarAuthority,
                    VarRealName = a.VarRealName
                }).OrderByDescending(a => a.IntAdminID).Skip((pageIndex - 1) * pageCount).Take(pageCount);

                page.rows = rows.ToList();


            }
            return page;
        }


        /// <summary>
        /// 逻辑删除管理员
        /// </summary>
        /// <param name="id">管理员id</param>
        /// <returns></returns>
        public int RemoveAdminByID(int id)
        {
            int rv = 0;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseAdmins.Find(id);
                if (entity == null)
                {
                    rv = 1;
                }
                else
                {
                    entity.IntFlag = 0;
                    rv = context.SaveChanges();
                }
            }

            return rv;
        }

        /// <summary>
        /// 添加字典项
        /// </summary>
        /// <param name="model">VmBaseAdmin 视图模型</param>
        /// <returns></returns>
        public int AddAdmin(VmBaseAdmin model)
        {
            int rv = 0;
            using (var context = new FaoB2BEntities())
            {
                int count = context.BaseAdmins.Where(a => a.VarAdminName == model.VarAdminName && a.IntFlag!=0).Count();
                if (count > 0)
                {
                    rv = -1;
                }
                else
                {
                    BaseAdmin entity = GetEntityFrom(model);
                    context.BaseAdmins.Add(entity);
                    rv = context.SaveChanges();
                }
            }
            return rv;
        }

        public BaseAdmin GetEntityFrom(VmBaseAdmin model)
        {

            return new BaseAdmin()
            {
                IntSex = model.IntSex ?? 0,
                VarAdminName = model.VarAdminName,
                VarAuthority = model.VarAuthority,
                VarRealName = model.VarRealName,
                VarPassWord = Security.MD5(model.VarPassWord),
                IntFlag = 1
            };

        }

        /// <summary>
        /// 修改管理员
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int UpdateAdmin(VmBaseAdmin model)
        {
            int rv = 0;
            using (var context = new FaoB2BEntities())
            {
                if (model != null)
                {
                    var count = context.BaseAdmins.Where(a => a.VarAdminName == model.VarAdminName && a.IntAdminID != model.IntAdminID && a.IntFlag != 0).Count();
                    if (count > 0)
                    {
                        rv = -1;
                    }
                    else
                    {
                        var entity = context.BaseAdmins.Find(model.IntAdminID);
                        if (entity != null)
                        {
                            entity.IntSex = model.IntSex ?? 0;
                            entity.VarAdminName = model.VarAdminName;
                            entity.VarAuthority = model.VarAuthority;
                            entity.VarPassWord = Security.MD5(model.VarPassWord);
                            entity.VarRealName = model.VarRealName;
                            rv = context.SaveChanges();
                            if (rv >= 0)
                            {
                                rv = 1;
                            }
                        }
                    }
                }
            }
            return rv;
        }

        /// <summary>
        /// 根据id，返回VmBaseAdmin视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmBaseAdmin GetBaseAdminByID(string id)
        {
            VmBaseAdmin vmAdmin = null;
            int adminid = Fao.Common.Utils.ToInt(id);
            using (var context = new FaoB2BEntities())
            {
                var admin = context.BaseAdmins.Find(adminid);
                vmAdmin = new VmBaseAdmin
                {
                        IntAdminID = admin.IntAdminID,
                        IntSex = admin.IntSex,
                        VarAdminName = admin.VarAdminName,
                        VarRealName = admin.VarRealName,
                        VarAuthority = admin.VarAuthority
                };
            }
            return vmAdmin;
        }

        public VmBaseAdmin ValidateUser(string adminName, string passWord)
        {
            VmBaseAdmin vmAdmin = null;
            using (var context = new FaoB2BEntities())
            {
                string encryptpassword = Security.MD5(passWord);
                var admin = context.BaseAdmins.Where(p => p.VarAdminName == adminName && p.VarPassWord == encryptpassword && p.IntFlag == 1).FirstOrDefault();
                if (admin != null)
                {
                    vmAdmin = new VmBaseAdmin
                    {
                        IntAdminID = admin.IntAdminID,
                        IntSex = admin.IntSex,
                        VarAdminName = admin.VarAdminName,
                        VarRealName = admin.VarRealName,
                        VarAuthority = admin.VarAuthority
                    };
                }

            }

            return vmAdmin;

        }


        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(BaseAdmin entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(BaseAdmin entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(BaseAdmin entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public BaseAdmin One(IQueryable<BaseAdmin> query, BaseAdmin entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<BaseAdmin> Many(IQueryable<BaseAdmin> query, BaseAdmin entity)
        {
            throw new Exception("没有实现");
        }



        #endregion

    }
}
﻿using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using System;
using System.Linq;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-20 10:18:31
    /// BaseLog服务实现-Power by CodeGG
    /// </summary>
    public class BaseLogService : Entity<BaseLog>, IBaseLogService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里


        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmBaseLog查询模型，返回VmBaseLog分页数据
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <param name="pageIndex">页所引</param>
        /// <param name="pageCount">页记录数</param>
        /// <returns>分页数据</returns>
        public BaseLogPaging GetBaseLogs(SmBaseLog searchModel, int pageIndex, int pageCount)
        {
            BaseLogPaging page = new BaseLogPaging();
            using (var context = new FaoB2BEntities())
            { 
                IBaseUserService baseUserService = new BaseUserService();
                var user = baseUserService.Many(context.BaseUsers, new BaseUser());

                var baseLog = context.BaseLogs.Select(b => b);

                if (searchModel.IntLogType > 0)
                    baseLog = baseLog.Where(b => b.IntLogType == searchModel.IntLogType);

                if (searchModel.IntLogID > 0)
                    baseLog = baseLog.Where(b => b.IntLogID == searchModel.IntLogID);

                page.total = baseLog.Count();

                var rows = baseLog.Join(user, b => b.IntCreateUserID, u => u.IntUserID,
                    (b, u) => new VmBaseLog
                    {
                        IntLogID = b.IntLogID,
                        IntLogType = b.IntLogType,
                        IntPlatform = b.IntPlatform,
                        IntUserID = b.IntCreateUserID,
                        VarInfo = b.VarInfo,
                        VarIP = b.VarIP,
                        VarModel = b.VarModel,
                        VarUname = string.IsNullOrEmpty(u.VarRealName)?u.VarNickName:u.VarRealName,
                        DateCreate = b.DteCreate
                    }).OrderByDescending(b => b.DateCreate).Skip((pageIndex - 1) * pageCount).Take(pageCount);

                page.rows = rows.ToList();
            }
            return page;

        }


        /// <summary>
        /// 根据id，返回VmBaseLog视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmBaseLog GetBaseLogByID(string id)
        {
            int logID = 0;
            int.TryParse(id, out logID);
            VmBaseLog baseLog = new VmBaseLog();

            BaseLogPaging page = GetBaseLogs(new SmBaseLog() { IntLogID = logID }, 1, 1);
            if (page.total > 0)
                baseLog = page.rows[0];
            return baseLog;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(BaseLog entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(BaseLog entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(BaseLog entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public BaseLog One(IQueryable<BaseLog> query, BaseLog entity)
        {
            var logs = query.Select(b => b);

            BaseLog baseLog = new BaseLog();
            if (entity.IntLogID > 0)
                baseLog = logs.SingleOrDefault(b => b.IntLogID == entity.IntLogID);
            return baseLog;

        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<BaseLog> Many(IQueryable<BaseLog> query, BaseLog entity)
        {
            var baseLog = query.Select(log => log);

            baseLog = baseLog.Where(log => log.DteCreate == entity.DteCreate);

            if (entity.IntLogType > 0)
                baseLog = baseLog.Where(log => log.IntLogType == entity.IntLogType);

            return baseLog;
        }

        public void WriteLog(FaoB2BEntities context, VmBaseLog vmBaseLog)
        { 
            var baseLog = new BaseLog()
            {
                IntCreateUserID = vmBaseLog.IntUserID,
                IntPlatform = vmBaseLog.IntPlatform,
                IntLogType = vmBaseLog.IntLogType,
                VarInfo = vmBaseLog.VarInfo,
                VarIP = vmBaseLog.VarIP,
                VarModel = vmBaseLog.VarModel,
                DteCreate = vmBaseLog.DateCreate,
                IntFlag = 1
            };

            context.BaseLogs.Add(baseLog);
            context.SaveChanges();
        }
        #endregion
    }
}
﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// SMSBuyLog服务实现-Power by CodeGG
    /// </summary>
    public class SMSBuyLogService : Entity<SMSBuyLog>, ISMSBuyLogService
    {
        //一条短信的价格
        public static string SMSUnitPrice = ConfigurationManager.AppSettings["SMSUintPrice"];
        //当前短信号段类别
        public static string SMSInterval = ConfigurationManager.AppSettings["SMSInterval"];

        #region 业务接口引用
        IUserTransactionService userTransactionService = new UserTransactionService();
        IBaseUserService baseUserService = new BaseUserService();
        #endregion

        #region 实现业务接口


        /// <summary>
        /// 登录用户购买短信
        /// </summary>
        /// <param name="buySum"></param>
        /// <param name="payPwd"></param>
        /// <returns></returns>
        public string BuyPhoneSms(string buySum, string payPwd)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                var e = userTransactionService.GetCurrentUserTransaction(context);
                if (e == null)
                {
                    msg = "用户没有登录";
                }
                else
                { 
                    if (Security.MD5(payPwd) != e.PaymentPwd)
                    {
                        msg = "支付密码出错，请重写！";
                    }
                    else
                    {
                        decimal smsValue = decimal.Parse(buySum) * decimal.Parse(SMSUnitPrice);
                        if (smsValue > e.AccountBalance)
                        {
                            msg = "所买短信的花费超过了账户余额，请充值！";
                        }
                        else
                        {
                            // var userDetail = Context.Database.SqlQuery<VmSMSBuyLog>("ProcUpdateUserTransaction @p0,@p1,@p2,@p3", e.UserID, buySum, smsValue, SMSInterval).FirstOrDefault();
                            //修改用户扩展信息，扣钱、加短信条数，给短信子号段,添加到购买记录表中
                            msg = userTransactionService.BuyMsg(context, int.Parse(buySum), smsValue, int.Parse(SMSInterval));
                            SMSBuyLog sy = new SMSBuyLog();
                            sy.IntBuyUserID = e.UserID;
                            sy.IntFlag = 1;
                            sy.IntBuyNum = int.Parse(buySum);
                            sy.DteCreate = System.DateTime.Now;
                            //AddToEntity(sy);
                            context.SMSBuyLogs.Add(sy);
                            context.SaveChanges();
                            msg = "1";
                        }
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 发短信时，减去要发的短信条数
        /// </summary>
        /// <param name="sumCount"></param>
        /// <returns></returns>
        public string updateMsgCount(int sendCount)
        {
            string msg = null;
            var e = userTransactionService.GetCurrentUserTransaction();
            if (e == null)
            {
                msg= "用户没有登录";
            }
            else
            {
                if (sendCount > e.PhoneMsgSum)
                {
                    msg= "要发的条数大于剩余的条数";
                }
                else
                {
                    //var userDetail = Context.Database.SqlQuery<VmSMSBuyLog>("ProcUpdateUserMsgCount @p0,@p1", e.UserID, sendCount).FirstOrDefault();
                    msg= userTransactionService.updateMsgCount(sendCount);
                }
            }
            return msg;
        }

        /// <summary>
        /// 根据条件得到 购买记录 的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VmSMSBuyLogPaging GetSmSMSBuyLogPager(SmSMSBuyLog search,int pageIndex, int pageCount)
        { 
            VmSMSBuyLogPaging pager = new VmSMSBuyLogPaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser();
                if (user == null)
                    return null;
                var baseLog = context.SMSBuyLogs.Where(b => b.IntBuyUserID == user.IntUserID && b.IntFlag == 1);
                if (!string.IsNullOrEmpty(search.SendStartDate))
                {
                    DateTime startDate = Convert.ToDateTime(search.SendStartDate);
                    baseLog = baseLog.Where(b => b.DteCreate >= startDate);
                }
                if (!string.IsNullOrEmpty(search.SendEndDate))
                {
                    DateTime endDate = Convert.ToDateTime(search.SendEndDate).AddDays(1);
                    baseLog = baseLog.Where(b => b.DteCreate < endDate);
                }
                pager.total = baseLog.Count();

                if (pageIndex >= 0 && pageCount > 0)
                {
                    pager.rows = baseLog.OrderByDescending(b => b.DteCreate).Skip((pageIndex - 1) * pageCount).Take(pageCount).ToList().Select(p => new VmSMSBuyLog
                    {
                        DteCreate = Utils.GetDateTimeFormate(p.DteCreate),
                        IntBuyNum = p.IntBuyNum

                    }).ToList();
                }
                //var rows = baseLog.Select(b => new VmSMSBuyLog
                //  {
                //      DteCreate = b.DteCreate,
                //      IntBuyNum = b.IntBuyNum

                //  }).OrderByDescending(b => b.DteCreate).Skip((pageIndex - 1) * pageCount).Take(pageCount);
                //pager.rows = rows.ToList();
             
            }

            return pager; 
        }

        /// <summary>
        /// 根据SmSMSBuyLog查询模型，返回VmSMSBuyLog视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmSMSBuyLog> GetSMSBuyLogs(SmSMSBuyLog searchModel)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmSMSBuyLog视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmSMSBuyLog GetSMSBuyLogByID(string id)
        {
            throw new Exception("没有实现");
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(SMSBuyLog entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(SMSBuyLog entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(SMSBuyLog entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public SMSBuyLog One(IQueryable<SMSBuyLog> query, SMSBuyLog entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<SMSBuyLog> Many(IQueryable<SMSBuyLog> query, SMSBuyLog entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntBuyUserID > 0)
                {
                    entities = entities.Where(e => e.IntBuyUserID == entity.IntBuyUserID);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
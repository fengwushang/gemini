﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// BaseIndustry服务实现-Power by CodeGG
    /// </summary>
    public class BaseIndustryService : Entity<BaseIndustry>, IBaseIndustryService
    {


        #region 业务接口引用


        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmBaseIndustry查询模型，返回VmBaseIndustry视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmBaseIndustry> GetBaseIndustrys(SmBaseIndustry searchModel)
        {
            var indList = new List<VmBaseIndustry>();
            using (var context = new FaoB2BEntities())
            {
                var list = Many(context.BaseIndustries, null)
                    .Where(p => p.IntIndustryParentID == searchModel.ParentID).OrderBy(p => p.IntOrderID).ToList();

                indList = list.Select(a => new VmBaseIndustry
                {
                    _parentId = a.IntIndustryParentID,
                    AbbName = a.VarIndustryNameAbb,
                    Name = a.VarIndustryName,
                    IndID = a.IntIndustryID,

                    ParentID = a.IntIndustryParentID,
                    state = "closed"
                }).ToList();
            }

            return indList;
        }


        /// <summary>
        /// 根据id，返回VmBaseIndustry视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmBaseIndustry GetBaseIndustryByID(string id)
        {
            var indVM = new VmBaseIndustry();
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseIndustries.Find(int.Parse(id));
                if (entity != null)
                {
                    indVM = new VmBaseIndustry
                    {
                        Name = entity.VarIndustryName,
                        AbbName = entity.VarIndustryNameAbb,
                        IndID = entity.IntIndustryID,
                        ParentID = entity.IntIndustryParentID,
                        _parentId = entity.IntIndustryParentID
                    };
                }
            }
            return indVM;
        }

        /// <summary>
        /// 根把ID 返回VmBaseIndustry 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public List<VmBaseIndustry> GetIndustryWithParentName(List<int> industryIDs)
        {
            //首先自联合表查出

            var indList = new List<VmBaseIndustry>();

            using (var context = new FaoB2BEntities())
            {
                var industries = Many(context.BaseIndustries, null)
                    .Where(a => industryIDs.Contains(a.IntIndustryID));
                var joinIndustry = industries.GroupJoin(Many(context.BaseIndustries, null),
                      a => a.IntIndustryParentID,
                      p => p.IntIndustryID,
                      (a, ja) =>
                         new
                         {
                             a = a,
                             ja = ja
                         }
                   )
                   .SelectMany(
                      temp0 => temp0.ja.DefaultIfEmpty(),
                      (temp0, j) =>
                         new
                         {
                             ID = temp0.a.IntIndustryID,
                             Name = temp0.a.VarIndustryName,
                             Name2 = j.VarIndustryName
                         }
                   );

                var joinIndustryList = joinIndustry.ToList();
                indList = joinIndustryList.Select(a => new VmBaseIndustry
                {
                    IndID = a.ID,
                    Name = a.Name2 + " " + a.Name
                }).ToList();
            }
            return indList;
        }


        /// <summary>
        /// 删除地区,1删除成功，2已删除，其他为删除失败
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int DeleteInd(int id)
        {
            int flag;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseIndustries.Find(id);
                if (entity == null)
                {
                    flag = 2;
                }
                entity.IntFlag = 0;
                flag= context.SaveChanges();
            }
            return flag;
        }

        /// <summary>
        /// 更新地区
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateInd(VmBaseIndustry model)
        {
            string str = "";
            using (var context = new FaoB2BEntities())
            {
                if (model == null)
                {
                    str = "保存失败";
                }
                else
                {
                    string name = model.Name;
                    int parentID = model.ParentID;
                    int id = model.IndID;
                    var e = Many(context.BaseIndustries, null).Where(p => p.VarIndustryName == name && p.IntIndustryParentID == parentID && p.IntIndustryID != id).Count();
                    if (e > 0)
                    {
                        str = "该行业名称已存在";
                    }
                    else
                    {
                        var entity = context.BaseIndustries.Find(model.IndID);
                        if (entity != null)
                        {
                            entity.VarIndustryName = model.Name;
                            entity.VarIndustryNameAbb = model.AbbName;
                            int flag = context.SaveChanges();
                            if (flag >= 0)
                            {
                                str = "1";
                            }
                            else
                                str = "保存失败";
                        }
                        else
                            str = "保存失败";
                    }
                }
            }
            return str;
        }

        /// <summary>
        /// 添加地区
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddInd(VmBaseIndustry model)
        {
            string str;
            using (var context = new FaoB2BEntities())
            {
                var adminID = HtmlHelper.GetCookieValue("AdminID");
                string name = model.Name;
                int parentID = model.ParentID;
                var e = Many(context.BaseIndustries, null).Where(p => p.VarIndustryName == name && p.IntIndustryParentID == parentID).Count();
                if (e > 0)
                {
                    str = "该行业名称已存在";
                }
                else
                {
                    int orderID = Many(context.BaseIndustries, null).Where(p => p.IntIndustryParentID == model.ParentID).Count();
                    var entity = new BaseIndustry
                    {
                        DteCreate = DateTime.Now,
                        IntIndustryParentID = model.ParentID,
                        VarIndustryName = model.Name,
                        VarIndustryNameAbb = model.AbbName,

                        IntOrderID = orderID + 1,
                        IntCreateUserID = Utils.ToInt(adminID),
                        IntFlag = 1,
                        VarSearch = string.Empty,
                        IntIndustryID = 0
                    };

                    context.BaseIndustries.Add(entity);
                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        str = "1";
                    }
                    else
                        str = "保存失败";
                }
            }
            return str;
        }

        /// <summary>
        /// 地区上移
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string ItemUP(int id)
        {
            string str;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseIndustries.Find(id);
                if (entity != null)
                {
                    if (entity.IntOrderID > 1)
                    {
                        entity.IntOrderID--;
                        var pre = Many(context.BaseIndustries, null)
                            .Where(p => p.IntIndustryParentID == entity.IntIndustryParentID && p.IntOrderID == entity.IntOrderID)
                            .FirstOrDefault();
                        if (pre != null)
                        {
                            pre.IntOrderID++;
                        }

                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            str = "1";
                        }
                        else
                        {
                            str = "-1";
                        }
                    }
                    else
                    {
                        str = "该项已经是第一位，不能再移了";
                    }
                 
                }
                else
                    str = "";
            }
            return str;
        }

        /// <summary>
        /// 地区下移
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string ItemDown(int id)
        {
            string str;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseIndustries.Find(id);
                if (entity != null)
                {
                    var max = Many(context.BaseIndustries, null).Where(p => p.IntIndustryParentID == entity.IntIndustryParentID).Max(p => p.IntOrderID);
                    if (entity.IntOrderID < max)
                    {
                        entity.IntOrderID++;
                        var pre = Many(context.BaseIndustries, null)
                            .Where(p => p.IntIndustryParentID == entity.IntIndustryParentID && p.IntOrderID == entity.IntOrderID)
                            .FirstOrDefault();
                        if (pre != null)
                        {
                            pre.IntOrderID--;
                        }

                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            str = "1";
                        }
                        else
                        {
                            str = "-1";
                        }
                    }
                    else
                    {
                        str = "该项已经是最后一位，不能再移了";
                    } 
                }
                else 
                    str = "";
            }
            return str;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(BaseIndustry entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(BaseIndustry entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(BaseIndustry entity)
        {
            if (entity != null)
            {
                entity.IntFlag = 0;
            }

            return string.Empty;
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public BaseIndustry One(IQueryable<BaseIndustry> query, BaseIndustry entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<BaseIndustry> Many(IQueryable<BaseIndustry> query, BaseIndustry entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {

            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion


    }
}
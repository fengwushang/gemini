﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: chf  2013年7月11日11:39:26
    /// BasePlatform服务实现-Power by CodeGG
    /// </summary>
    public class BasePlatformService : Entity<BasePlatform>, IBasePlatformService
    {
         
        /// <summary>
        /// 添加一个新数据
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int AddBasePlatform(BasePlatform model)
        {
            int re = 0;
            using (var context = new FaoB2BEntities())
            {
                context.BasePlatforms.Add(model);
                re = context.SaveChanges();
            } 
            return re;
        }

        /// <summary>
        /// 得到对应平台的用户ID
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="tid"></param>
        /// <returns></returns>
        public int GetPlatformID(int uid, int tid)
        {
            int re = 0;
            using (var context = new FaoB2BEntities())
            {
                var user = context.BasePlatforms.Where(p => p.IntCreateUserID == uid && p.IntTypeID == tid).FirstOrDefault();
                if (user != null)
                    re = Utils.ToInt(user.IntUserID.ToString());
            }
            return re;
        }


        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(BasePlatform entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(BasePlatform entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(BasePlatform entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public BasePlatform One(IQueryable<BasePlatform> query, BasePlatform entity)
        {
            var bUser = new BasePlatform();
            using (var context = new FaoB2BEntities())
            {
                if (entity != null)
                {
                    if (entity.IntUserID > 0)
                    {
                        //return Current.Find(entity.IntUserID);
                        bUser = query.FirstOrDefault(t => t.IntUserID == entity.IntUserID);
                    }
                }
            }
            return bUser;
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<BasePlatform> Many(IQueryable<BasePlatform> query, BasePlatform entity)
        {
            var users = query.Select(u => u);

            if (entity != null)
            {

            }

            return users;
        }

        #endregion
    }
}

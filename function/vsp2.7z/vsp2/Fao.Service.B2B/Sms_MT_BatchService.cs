﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Data.Sms.DAL;
using System.Text;
using System.Collections;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-03-13 17:03:47
    /// Sms_MT_Batch服务实现-Power by CodeGG
    /// </summary>
    public class Sms_MT_BatchService : Entity<Sms_MT_Batch>, ISms_MT_BatchService
    {

        #region 业务接口引用

        IBaseUserService baseUserService = new BaseUserService();

        #endregion

        #region 实现业务接口


        /// <summary>
        /// 根据条件得到发件箱 的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VmSms_MT_BatchPaging GetSmSmsBatchPager(SmSms_MT_Batch search, int page, int rows)
        {
            StringBuilder sb = new StringBuilder();

            VmSms_MT_BatchPaging pager = new VmSms_MT_BatchPaging();

            using (var context = new FaoB2BEntities())
            {

                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    sb.Append(string.Format("select * from (select row_number() over(order by BigBatchID asc) as RowNum,BigBatchID,MsgType,MsgContent,CONVERT(nvarchar(30), SendTime, 120) as SendTime,OperatorID  from  dbo.Sms_MT_Batch where Flag<>0  and OperatorID={0}", user.IntUserID.ToString()));

                    if (!string.IsNullOrEmpty(search.SendStartDate))
                        sb.Append(string.Format(" and SendTime>='{0}'", search.SendStartDate));
                    if (!string.IsNullOrEmpty(search.SendEndDate))
                        sb.Append(string.Format(" and SendTime<dateadd(day,1,'{0}')", search.SendEndDate));

                    sb.Append(string.Format(" ) as t where  t.RowNum>({0} -1)*{1} and t.RowNum<=({0} * {1})",page,rows));

                    var list = context.Database.SqlQuery<VmSms_MT_Batch>(sb.ToString()).OrderBy(t => t.RowNum).ToList();
                    
                    pager.total = list.Count(); //此处出错 sql 未修改，也将上面一条语句使用Ado.net访问数据库

                    pager.rows = list.OrderByDescending(l => l.RowNum).Select(p => new VmSms_MT_Batch
                        {
                            RowNum = p.RowNum,
                            MsgContent = p.MsgContent,
                            MsgType = p.MsgType,
                            SendTime = p.SendTime,
                            OperatorID = p.OperatorID,
                            BigBatchID = p.BigBatchID
                        }).ToList();
                }
            }
            return pager;
        }

        /// <summary>
        /// 删除短信
        /// </summary>
        /// <param name="idList"></param>
        /// <returns></returns>
        public string DeleteSMSChoose(string idList)
        {
            ArrayList al = new ArrayList();
            string msg = null;
            al.Add(string.Format("update Sms_MT_Batch set Flag=0 where BigBatchID in ({0})", idList));
            al.Add(string.Format("update Sms_MT_Detail set Flag=0 where BatchID in ({0})", idList));
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user == null)
                {
                    msg= "没有登录";
                }
                else
                {
                    SQLPlus.ExecuteSqlTran(al);
                    msg = "1";
                }
            }
            return msg;
        }

        /// <summary>
        /// 根据SmSms_MT_Batch查询模型，返回VmSms_MT_Batch视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmSms_MT_Batch> GetSms_MT_Batchs(SmSms_MT_Batch searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmSms_MT_Batch视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmSms_MT_Batch GetSms_MT_BatchByID(string id)
        {
            throw new Exception("没有实现");
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(Sms_MT_Batch entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(Sms_MT_Batch entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(Sms_MT_Batch entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public Sms_MT_Batch One(IQueryable<Sms_MT_Batch> query, Sms_MT_Batch entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<Sms_MT_Batch> Many(IQueryable<Sms_MT_Batch> query, Sms_MT_Batch entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {

            }



            return entities;
        }

        #endregion

    }
}
﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// UserFriend服务实现-Power by CodeGG
    /// </summary>
    public class UserFriendService : Entity<UserFriend>, IUserFriendService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();
        IEnterpriseService enterpriseService = new EnterpriseService();
        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmUserFriend查询模型，返回VmUserFriend视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmUserFriend> GetUserFriends(SmUserFriend searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmUserFriend视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmUserFriend GetUserFriendByID(int id)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 添加一条好友或关注记录。返回添加信息
        /// </summary>
        /// <param name="userid">要添加的用户id</param>
        /// <param name="type">该好友的类型id，2为加关注，1为加好友</param>
        /// <returns>0为操作失败，1为操作成功，2为当前用户未登录，3为已存在该记录</returns>
        public string AddFriend(int userid, int type)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                string success = string.Empty;
                //判断当前用户是否登录
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user == null)
                {
                    //当前用户未登录
                    msg = "2";
                }
                else
                {
                    //判断当前用户，是否和要关注的、添加的好友id相同
                    if (user.IntUserID == userid)
                    {
                        msg = "4";
                    }
                    else
                    {
                        var userFriend = new UserFriend
                        {
                            IntFriendType = type,
                            IntSourceUserID = user.IntUserID,
                            IntFriendUserID = userid
                        };
                        //判断是否已添加好友、或关注
                        if (Many(context.UserFriends, userFriend).Count() >= 1)
                        {
                            msg = "3";
                        }
                        else
                        {

                            userFriend.DteCreate = DateTime.Now;
                            userFriend.IntFlag = 1;

                            //实现添加好友，或关注
                            // AddToEntity(userFriend);
                            context.UserFriends.Add(userFriend);

                            //return Save().ToString();
                            msg = context.SaveChanges().ToString();
                        }
                    }
                }
            }
            return msg;
        }


        /// <summary>
        /// 返回好友或关注列表
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public VmUserFriendPaging GetUserFriendsWithPage(SmUserFriend search, int page, int rows)
        {
            using (var context = new FaoB2BEntities())
            {
                var entity = new UserFriend();
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    entity.IntSourceUserID = user.IntUserID;
                }
                entity.IntFriendType = search.FriendType;

                var users = baseUserService.Many(context.BaseUsers, null);

                var enterprise = enterpriseService.Many(context.Enterprises, null);

                var list = Many(context.UserFriends, entity).Join(users, e => e.IntFriendUserID, u => u.IntUserID, (e, u) => new
                {
                    UserID = u.IntUserID,
                    RealName = u.VarRealName,
                    FriendType = e.IntFriendType == 1 ? "好友" : "关注",
                    FriendID = e.IntFriendID,
                    CreateDate = e.DteCreate
                }).Join(enterprise, f => f.UserID, e => e.IntCreateUserID, (f, e) => new
                {
                    UserID = f.UserID,
                    RealName = f.RealName,
                    FriendType = f.FriendType,
                    FriendID = f.FriendID,
                    CreateDate = f.CreateDate,
                    EnterpriseName = e.VarEnterpriseName,
                    Phone = e.VarContactPhone
                });

                VmUserFriendPaging vmList = new VmUserFriendPaging();
                vmList.total = list.Count();
                if (page >= 0 && rows > 0)
                {
                    vmList.rows = list.OrderBy(f => f.UserID).Skip((page - 1) * rows)
                        .Take(rows).ToList()
                        .Select(f => new VmUserFriend
                        {
                            FriendID = Common.Security.Encrypt(f.FriendID),
                            UserID = f.UserID,
                            RealName = f.RealName,
                            EnterpriseName = f.EnterpriseName,
                            ContactPhone = f.Phone,
                            CreateDate = Common.Utils.GetDateTimeFormate(f.CreateDate),
                            Type = f.FriendType
                        }).ToList();
                }

                return vmList;
            }
        }

        /// <summary>
        /// 删除好友或关注信息
        /// </summary>
        /// <param name="friendID"></param>
        /// <returns></returns>
        public string DeleteFriend(int friendID)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.UserFriends.Find(friendID);
                if (entity != null)
                {
                    entity.IntFlag = 0;
                    int flag = context.SaveChanges();
                    msg = flag >= 0 ? "1" : "0";
                }
                else
                {
                    msg= "1";
                }
            }
            return msg;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(UserFriend entity)
        {

            throw new Exception("没有实现");

        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(UserFriend entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(UserFriend entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public UserFriend One(IQueryable<UserFriend> query, UserFriend entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<UserFriend> Many(IQueryable<UserFriend> query, UserFriend entity)
        {
            var entitys = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntFriendType != 0)
                {
                    entitys = entitys.Where(e => e.IntFriendType == entity.IntFriendType);
                }

                if (entity.IntFriendUserID != 0)
                {
                    entitys = entitys.Where(e => e.IntFriendUserID == entity.IntFriendUserID);
                }

                if (entity.IntSourceUserID != 0)
                {
                    entitys = entitys.Where(e => e.IntSourceUserID == entity.IntSourceUserID);
                }
            }

            entitys = entitys.Where(e => e.IntFlag != 0);

            return entitys;
        }

        #endregion

    }
}
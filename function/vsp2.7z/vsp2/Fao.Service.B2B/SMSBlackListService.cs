﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;


namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: sjp , 2013-07-18
    /// SMSBlackList服务实现-Power by sjp
    /// </summary>
    public class SMSBlackListService:Entity<VmSMSBlackList>,ISMSBlackListService
    {
        #region 业务接口引用
        IBaseAdminService baseAdminService = new BaseAdminService();
        IBaseUserService baseUserService = new BaseUserService();
        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmSMSBlackList查询模型，返回SMSBlackList视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <param name="page">当前页数</param>
        /// <param name="rows">页大小</param>
        /// <returns>手机黑名单 视图模型列表</returns>
        public List<VmSMSBlackList> GetSMSBlackLists(SmSMSBlackList searchModel)
        {
            
            return null;
        }

        /// <summary>
        /// 根据id，返回SMSBlackList视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>手机黑名单 视图模型</returns>
        public VmSMSBlackList GetSMSBlackListByID(string id)
        {
            int smsID = Utils.ToInt(id);
            VmSMSBlackList pager = new VmSMSBlackList();
            using (var context = new FaoB2BEntities())
            {
                SMSBlackList SMSBlack = context.SMSBlackLists.Where(s => s.IntSMSBlackListID == smsID && s.IntFlag == 1).FirstOrDefault();

                pager.VarPhone = SMSBlack.VarPhone;
                pager.IntSMSBlackListID = SMSBlack.IntSMSBlackListID.ToString();
                pager.IntUserID = SMSBlack.IntUserID.ToString();
                pager.UserName = SMSBlack.IntUserID == 0 ? "系统用户" : context.BaseUsers.Where(bu => bu.IntUserID == SMSBlack.IntUserID).SingleOrDefault().VarNickName.ToString();

            }
            return pager;
        }

        /// <summary>
        /// 手机黑名单 获取分页数据
        /// </summary>
        /// <param name="sm">关键字，发布时间</param>
        /// <param name="page">当前页数</param>
        /// <param name="rows">页大小</param>
        /// <returns></returns>
        public VmSMSBlackListList GetSMSBlackListList(SmSMSBlackList sm, string page, string rows,string isNotSystemUser)
        {
            VmSMSBlackListList pager = new VmSMSBlackListList();
            using (var context = new FaoB2BEntities())
            {
                var SMSBlack = context.SMSBlackLists.Where(s => s.IntFlag == 1);
                if (isNotSystemUser != "0")
                {
                    int smsID = Utils.ToInt(baseUserService.CurrentUserID());
                    SMSBlack = SMSBlack.Where(b => b.IntUserID == smsID);
                }
                if (sm.varPhone != null)
                {
                    SMSBlack = SMSBlack.Where(b => b.VarPhone.Contains(sm.varPhone));
                }
                if (sm.startDate != null)
                {
                    DateTime startDate = Convert.ToDateTime(sm.startDate);
                    SMSBlack = SMSBlack.Where(b => b.DteCreate >= startDate);
                }
                if (sm.endDate != null)
                {
                    DateTime endDate = Convert.ToDateTime(sm.endDate).AddDays(1);
                    SMSBlack = SMSBlack.Where(b => b.DteCreate < endDate);
                }
                pager.total = SMSBlack.Count();
                if (Utils.ToInt( page) >= 0 && Utils.ToInt( rows) > 0)
                {
                    pager.rows = SMSBlack.OrderByDescending(b => b.DteCreate).Skip((Utils.ToInt(page) - 1) * Utils.ToInt(rows)).Take(Utils.ToInt(rows)).ToList().Select(p => new VmSMSBlackList
                    {
                        //DteCreate = Utils.GetDateTimeFormate(p.DteCreate),
                        //IntBuyNum = p.IntBuyNum
                        VarPhone = p.VarPhone,
                        IntSMSBlackListID = p.IntSMSBlackListID.ToString(),
                        IntUserID = p.IntUserID.ToString(),
                        UserName = p.IntUserID == 0?"系统用户":context.BaseUsers.Where(bu=>bu.IntUserID==p.IntUserID).FirstOrDefault().VarNickName.ToString()

                    }).ToList();
                }
            }
            return pager;
        }

        /// <summary>
        /// 保存 手机黑名单
        /// </summary>
        /// <returns></returns>
        public string Save(VmSMSBlackList model, string isNotSystemUser)
        {
            string result = string.Empty;
            if (isNotSystemUser == "0")
            {
                model.IntCreateUserID = HtmlHelper.GetCookieValue("AdminID");
            }
            else
            {
                model.IntCreateUserID = baseUserService.CurrentUserID();
                model.IntUserID = baseUserService.CurrentUserID();
            }
            if (Utils.ToInt(model.IntSMSBlackListID) == 0)
            {
                result = AddToEntity(model);
            }
            else
            {
                result = ResetToEntity(model);
            }
            return result;
        }

        #endregion    

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(VmSMSBlackList entity)
        {
            using (var context = new FaoB2BEntities())
            {
                //判断是否已添加该数据
                int smsCount = context.SMSBlackLists.Where(s => s.VarPhone == entity.VarPhone && s.IntFlag==1).Count();

                if (smsCount > 0) { return "33"; }
                else
                {
                    SMSBlackList smsBlack = new SMSBlackList();

                    //添加数据
                    smsBlack.VarPhone = entity.VarPhone;
                    smsBlack.IntUserID = Utils.ToInt(entity.IntUserID);
                    smsBlack.IntFlag = 1;
                    smsBlack.DteCreate = System.DateTime.Now;
                    smsBlack.DteUpdate = System.DateTime.Now;
                    smsBlack.IntCreateUserID = Utils.ToInt(entity.IntCreateUserID);
                    smsBlack.IntUpdateAdminID = Utils.ToInt(entity.IntCreateUserID);

                    context.SMSBlackLists.Add(smsBlack);
                    int result = context.SaveChanges();
                    if (result > 0)
                    {
                        return result.ToString();
                    }
                    else
                    {
                        return "0";
                    }
                }
            }
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(VmSMSBlackList entity)
        {
            int smsID =Utils.ToInt(entity.IntSMSBlackListID); 
            using (var context = new FaoB2BEntities())
            {
                int smsCount = context.SMSBlackLists.Where(s => s.VarPhone == entity.VarPhone).Count();

                if (smsCount > 0) { return "33"; }
                else
                {
                    SMSBlackList smsBlack = context.SMSBlackLists.Where(s => s.IntSMSBlackListID == smsID).FirstOrDefault();

                    //修改数据
                    smsBlack.VarPhone = entity.VarPhone;
                    smsBlack.DteUpdate = System.DateTime.Now;
                    smsBlack.IntUpdateAdminID = Utils.ToInt(entity.IntCreateUserID);

                    int result = context.SaveChanges();
                    if (result > 0)
                    {
                        return result.ToString();
                    }
                    else
                    {
                        return "0";
                    }
                }
            }
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(VmSMSBlackList entity)
        {
            int smsID = Utils.ToInt(entity.IntSMSBlackListID);
            using (var context = new FaoB2BEntities())
            {
                SMSBlackList SMSBlackLists = context.SMSBlackLists.Where(s => s.IntSMSBlackListID == smsID).FirstOrDefault();

                SMSBlackLists.IntFlag = 0;

                int result = context.SaveChanges();
                if (result > 0)
                {
                    return result.ToString();
                }
                else
                {
                    return "0";
                }
            }
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public VmSMSBlackList One(IQueryable<VmSMSBlackList> query, VmSMSBlackList entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<VmSMSBlackList> Many(IQueryable<VmSMSBlackList> query, VmSMSBlackList entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (Utils.ToInt(entity.IntCreateUserID) > 0)
                {
                    entities = entities.Where(e => e.IntCreateUserID == entity.IntCreateUserID);
                }
            }

           // entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion
    }
}

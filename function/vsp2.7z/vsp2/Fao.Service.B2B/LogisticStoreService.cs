﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticStore服务实现-Power by CodeGG
    /// </summary>
    public class LogisticStoreService : Entity<LogisticStore>, ILogisticStoreService
    {

        #region 业务接口引用

        IEnterpriseService enterpriseService = new EnterpriseService();
        IBaseUserService baseUserService = new BaseUserService();
        IBaseAreaService baseAreaService = new BaseAreaService();
        IBaseDictionaryService baseDictionaryService = new BaseDictionaryService();
        IAttachmentService attachmentService = new AttachmentService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmLogisticStore查询模型，返回VmLogisticStore视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmLogisticStore> GetLogisticStores(SmLogisticStore searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmLogisticStore视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmLogisticStore GetLogisticStoreByID(string id)
        {

            VmLogisticStore Store = new VmLogisticStore();
            int sid = Utils.ToInt(Security.Decrypt(id));
            var list = GetLogisticStoreWithPage(new SmLogisticStore() { ID = sid }, 1, 1);
            if (list.rows.Count > 0)
            {
                Store = list.rows[0];
            }
            return Store;

        }

        /// <summary>
        /// 获取分页数据  库源
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        public LogisticStorePaging GetLogisticStoreWithPage(SmLogisticStore searchModel, int pageIndex, int pageCount)
        {
            LogisticStorePaging page = new LogisticStorePaging();

            #region 旧代码
            //using (var context = new FaoB2BEntities())
            //{
            //    var Store = Many(context.LogisticStores, null).Where(c => c.IntFlag == 3);
            //    if (searchModel != null)
            //    {
            //        if (searchModel.ID > 0)
            //        {
            //            Store = Store.Where(c => c.IntStoreID == searchModel.ID);
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.KeyWord))
            //        {
            //            Store = Store.Where(c => (c.VarStoreTitle.Contains(searchModel.KeyWord) || c.VarDetails.Contains(searchModel.KeyWord)));
            //        }
            //        if (searchModel.AreaID > 0)
            //        {
            //            var area = baseAreaService.Many(context.BaseAreas, null).Where(a => a.IntAreaID == searchModel.AreaID
            //                        || a.IntAreaParentID == searchModel.AreaID).Select(a => a.IntAreaID).ToArray();
            //            Store = Store.Where(c => area.Contains(c.IntAreaID));
            //        }
            //        if (searchModel.StoreType > 0)
            //        {
            //            Store = Store.Where(c => c.IntStoreType == searchModel.StoreType);
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.DteRefreshStart))
            //        {
            //            DateTime dteRefreshStart = new DateTime();
            //            if (DateTime.TryParse(searchModel.DteRefreshStart, out dteRefreshStart))
            //            {
            //                Store = Store.Where(c => c.DteRefresh >= dteRefreshStart);
            //            }
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.DteRefreshEnd))
            //        {
            //            DateTime dteRefreshEnd = new DateTime();
            //            if (DateTime.TryParse(searchModel.DteRefreshEnd, out dteRefreshEnd))
            //            {
            //                Store = Store.Where(c => c.DteRefresh <= dteRefreshEnd);
            //            }
            //        }
            //    }

            //    var user = baseUserService.Many(context.BaseUsers, null);
            //    var ent = enterpriseService.Many(context.Enterprises, null);
            //    var dict = baseDictionaryService.Many(context.BaseDictionaries, null);

            //    var entity = from s in Store
            //                 join e in ent on s.IntEnterpriseID equals e.IntEnterpriseID
            //                 join u in user on s.IntCreateUserID equals u.IntUserID
            //                 join type in dict on s.IntStoreType equals type.IntItemID
            //                 join shelf in dict on s.IntStoreShelfType equals shelf.IntItemID
            //                 select new
            //                 {
            //                     AreaID = s.IntAreaID,
            //                     Contact = s.VarContact,
            //                     Details = s.VarDetails,
            //                     Phone = s.VarPhone,
            //                     ShelfType = shelf.VarItemName,
            //                     StoreCapacity = s.IntStoreCapacity,
            //                     StoreID = s.IntStoreID,
            //                     StoreShelfType = s.IntStoreShelfType,
            //                     StoreType = s.IntStoreType,
            //                     StoreUseCapacity = s.IntStoreUseCapacity,
            //                     StoreTitle = s.VarStoreTitle,
            //                     VarUnit = s.VarUnit,
            //                     BrowserCount = s.IntBrowserCount,
            //                     DteCreate = s.DteCreate,
            //                     DteRefresh = s.DteRefresh,
            //                     DteValid = s.DteValid,
            //                     EntID = s.IntEnterpriseID,
            //                     EntName = e.VarEnterpriseName,
            //                     Type = type.VarItemName,
            //                     UserID = s.IntCreateUserID,
            //                     UserName = u.VarRealName

            //                 };
            //    page.total = entity.Count();
            //    var list = entity.OrderByDescending(s => s.DteRefresh).Skip((pageIndex - 1) * pageCount).Take(pageCount).ToList();

            //    var CargoIDs = list.Select(e => e.StoreID).ToList();
            //    var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 2)
            //            , CargoIDs)
            //            .Select(e => new
            //            {
            //                e.IntBelongTablePrikeyID,
            //                e.VarFilePath
            //            }).ToList();

            //    var areaStartIDs = list.Select(e => e.AreaID).ToList();
            //    var areaStartList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaStartIDs);

            //    var rows = (
            //        from c in list
            //        join a1 in areaStartList on c.AreaID equals a1.AreaID
            //        join a in attList on c.StoreID equals a.IntBelongTablePrikeyID
            //        select new VmLogisticStore
            //        {
            //            AreaID = c.AreaID,
            //            AreaName = a1.Name,
            //            Contact = c.Contact,
            //            Details = c.Details,
            //            Phone = c.Phone,
            //            ShelfType = c.ShelfType,
            //            StoreCapacity = c.StoreCapacity,
            //            EncriptID = Security.Encrypt(c.StoreID),
            //            StoreShelfType = c.StoreShelfType,
            //            StoreType = c.StoreType,
            //            StoreUseCapacity = c.StoreUseCapacity,
            //            StoreTitle = c.StoreTitle,
            //            VarUnit = c.VarUnit,
            //            BrowserCount = c.BrowserCount,
            //            DteCreate = c.DteCreate.ToString("yyyy-MM-dd"),
            //            DteRefresh = c.DteRefresh.ToString("yyyy-MM-dd"),
            //            DteValid = c.DteValid.Year == DateTime.MaxValue.Year ? "永久有效" : Common.Utils.GetDateFormate(c.DteValid),
            //            EntID = Security.Encrypt(c.EntID),
            //            EntName = c.EntName,
            //            Type = c.Type,
            //            UserID = c.UserID,
            //            UserName = c.UserName,
            //            ImgUrl = a.VarFilePath
            //        }).ToList();

            //    page.rows = rows;
            //}
            #endregion

            #region 新代码
            using (var context = new FaoB2BEntities())
            {
                IEnumerable<VmLogisticStore> entities = null;
                //根据ID获取该条记录
                if (searchModel.ID > 0)
                {
                    entities = context.Database.SqlQuery<VmLogisticStore>("ProcGetSearchStoreByID @p0", searchModel.ID);
                    page.total = entities.Count();
                }
                else
                {
                    entities = context.Database.SqlQuery<VmLogisticStore>(
                       "ProcGetSearchStore @p0,@p1,@p2,@p3,@p4,@p5,@p6"
                       , searchModel.AreaID
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshStart) ? string.Empty : Utils.ToDateFormate(searchModel.DteRefreshStart)
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshEnd) ? string.Empty : Utils.ToDateFormate(searchModel.DteRefreshEnd)
                       , 7
                       , string.IsNullOrWhiteSpace(searchModel.KeyWord) ? string.Empty : searchModel.KeyWord
                       , pageIndex
                       , pageCount
                       );

                    page.total = context.Database.SqlQuery<int>(
                       "ProcGetSearchStoreCount @p0,@p1,@p2,@p3,@p4"
                       , searchModel.AreaID
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshStart) ? string.Empty : Utils.ToDateFormate(searchModel.DteRefreshStart)
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshEnd) ? string.Empty : Utils.ToDateFormate(searchModel.DteRefreshEnd)
                       , 7
                       , string.IsNullOrWhiteSpace(searchModel.KeyWord) ? string.Empty : searchModel.KeyWord
                       ).FirstOrDefault();
                }

                var list = entities.ToList().Select(e => new
                {
                    AreaID = Utils.ToInt(e.AreaID.ToString()),
                    Contact = e.Contact,
                    Details = e.Details,
                    Phone = e.Phone,
                    ShelfType = e.ShelfType,
                    StoreCapacity = e.StoreCapacity,
                    StoreID = Utils.ToInt(e.StoreID.ToString()),

                    StoreShelfType = e.StoreShelfType,
                    StoreType = e.StoreType,
                    StoreUseCapacity = e.StoreUseCapacity,
                    StoreTitle = e.StoreTitle,
                    VarUnit = e.VarUnit,
                    BrowserCount = e.BrowserCount,
                    DteCreate = e.DteCreate,
                    DteRefresh = e.DteRefresh,
                    DteValid = e.DteValid,

                    EntID = e.EntID,
                    EntName = e.EntName,
                    Type = e.Type,
                    UserID = e.UserID,
                    UserName = e.UserName,

                    PPCID = e.PPCID,
                    EncriptID = Security.Encrypt(e.EncriptID),
                    ValidDate = e.ValidDate,
                    Sms = e.Sms,

                }).ToList();

                //获取分页数据主键集合
                var StoreIDs = list.Select(e => e.StoreID);

                //获取附件集合
                var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 2)
                      , StoreIDs)
                      .Select(e => new
                      {
                          e.IntBelongTablePrikeyID,
                          e.VarFilePath
                      }).ToList();


                var areaIDs = list.Select(e => e.AreaID).ToList();

                var areaList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaIDs);

                var rows = (from c in list
                            join a1 in areaList on c.AreaID equals a1.AreaID
                            join a in attList on c.StoreID equals a.IntBelongTablePrikeyID
                            select new VmLogisticStore
                            {
                                AreaID = c.AreaID,
                                AreaName = a1.Name,
                                Contact = c.Contact,
                                Details = c.Details,
                                Phone = c.Phone,
                                ShelfType = c.ShelfType,
                                StoreCapacity = c.StoreCapacity,
                                EncriptID = Security.Encrypt(c.StoreID),
                                StoreShelfType = c.StoreShelfType,
                                StoreType = c.StoreType,
                                StoreUseCapacity = c.StoreUseCapacity,
                                StoreTitle = c.StoreTitle,
                                VarUnit = c.VarUnit,
                                BrowserCount = c.BrowserCount,
                                DteCreate = c.DteCreate,
                                DteRefresh = c.DteRefresh,
                                DteValid = Convert.ToDateTime(c.DteValid).Year == DateTime.MaxValue.Year ? "永久有效" : c.DteValid,
                                EntID = Security.Encrypt(c.EntID),
                                EntName = c.EntName,
                                Type = c.Type,
                                UserID = c.UserID,
                                UserName = c.UserName,
                                ImgUrl = a.VarFilePath,
                                PPCID = c.PPCID,
                                Sms = Security.Encrypt(c.Sms)
                            }).ToList();
                page.rows = rows;
            }
            #endregion

            return page;
        }

        /// <summary>
        /// 添加仓库信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddLogisticStoreInfo(VmLogisticStore model, VmB2BInfoPicture picture)
        {
            string str = null;
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                LogisticStore entity = new LogisticStore();
                var enterprise = enterpriseService.GetCurrentEnterprise(context);

                if (user == null)
                {
                    str = "用户未登陆";
                }
                else
                {

                    string strID = string.Empty;
                    int id = 0;
                    if (enterprise != null)
                    {
                        strID = Security.Decrypt(enterprise.EntID);
                        strID = strID == "" ? enterprise.EntID : strID;
                        int.TryParse(strID, out id);
                    }
                    entity.IntCreateUserID = user.IntUserID;
                    entity.IntEnterpriseID = id;
                    entity.DteCreate = DateTime.Now;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.DteRefresh = DateTime.Now;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.IntBrowserCount = 0;
                    entity.VarContact = model.Contact;
                    entity.VarDetails = model.Details == null ? "" : model.Details;
                    entity.VarPhone = model.Phone;
                    entity.IntStoreType = model.StoreType ?? 0;
                    entity.VarStoreTitle = model.StoreTitle;
                    entity.IntStoreShelfType = model.StoreShelfType ?? 0;
                    entity.IntStoreCapacity = model.StoreCapacity;
                    entity.IntStoreUseCapacity = model.StoreUseCapacity;
                    entity.VarUnit = model.VarUnit;
                    entity.IntAreaID = model.AreaID ?? 0;
                    context.LogisticStores.Add(entity);
                    flag = context.SaveChanges();
                    SaveImage(context, entity.IntStoreID, picture);
                }
            }
            if (flag >= 0)
            {
                str = "1";
            }
            else
            {
                str = "保存失败";
            }
            return str;
        }

        /// <summary>
        /// 修改仓库信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateLogisticStoreInfo(VmLogisticStore model, VmB2BInfoPicture picture = null)
        {
            string strID = Common.Security.Decrypt(model.EncriptID);
            int id;
            if (!int.TryParse(strID, out id))
            {
                return "未提到该记录";
            }
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.LogisticStores.Find(id);
                if (entity != null)
                {
                    entity.IntFlag = model.Flag ?? 1;
                    entity.DteRefresh = model.RefreshDate ?? DateTime.Now;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.VarContact = model.Contact;
                    entity.VarDetails = model.Details == null ? "" : model.Details;
                    entity.VarPhone = model.Phone;
                    entity.IntStoreType = model.StoreType ?? 0;
                    entity.VarStoreTitle = model.StoreTitle;
                    entity.IntStoreShelfType = model.StoreShelfType ?? 0;
                    entity.IntStoreCapacity = model.StoreCapacity;
                    entity.IntStoreUseCapacity = model.StoreUseCapacity;
                    entity.VarUnit = model.VarUnit;
                    entity.IntAreaID = model.AreaID ?? 0;
                }
                flag = context.SaveChanges();
                if (picture != null)
                {
                    SaveImage(context, entity.IntStoreID, picture);
                    //删除 热词推广 信息
                    //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                    PPCService pPCService = new PPCService();
                    pPCService.DeletePPC(7, entity.IntStoreID);
                }
            }
            if (flag >= 0)
            {
                return "1";
            }
            return "保存失败";
        }

        /// <summary>
        /// 根据ID得到仓库信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmLogisticStore GetLogisticStoreInfoBy(string encriptID)
        {
            VmLogisticStore vm = null;
            using (var context = new FaoB2BEntities())
            {
                string strID = Security.Decrypt(encriptID);
                int id = 0;
                int.TryParse(strID, out id);
                var entity = context.LogisticStores.Find(id);
                var attList = attachmentService.GetAttachmentsByTablePK(context, id, 2);
                if (entity != null)
                {
                    var startArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaID }).FirstOrDefault();
                    var type = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntStoreType);
                    var shelftype = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntStoreShelfType);
                    vm = new VmLogisticStore()
                    {
                        EncriptID = Security.Encrypt(id),
                        AreaID = entity.IntAreaID,
                        AreaName = startArea != null ? startArea.Name : "",
                        Contact = entity.VarContact,
                        Details = entity.VarDetails,
                        ValidDate = entity.DteValid,
                        Phone = entity.VarPhone,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                        Flag = entity.IntFlag,
                        StoreType = entity.IntStoreType,
                        StoreTitle = entity.VarStoreTitle,
                        StoreShelfType = entity.IntStoreShelfType,
                        StoreCapacity = entity.IntStoreCapacity,
                        StoreUseCapacity = entity.IntStoreUseCapacity,
                        VarUnit = entity.VarUnit,
                        Type = type.ItemName,
                        ShelfType = shelftype.ItemName,
                        DteValid = Utils.GetDateTimeFormate(entity.DteValid)
                    };
                }
                return vm;
            }
        }

        /// <summary>
        /// 根据ID得到仓库信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmLogisticStore GetLogisticStoreInfoBy(FaoB2BEntities context, string encriptID)
        {
            VmLogisticStore vm = null;
            string strID = Security.Decrypt(encriptID);
            int id = 0;
            int.TryParse(strID, out id);
            var entity = context.LogisticStores.Find(id);
            var attList = attachmentService.GetAttachmentsByTablePK(context, id, 2);
            if (entity != null)
            {
                var startArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaID }).FirstOrDefault();
                var type = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntStoreType);
                var shelftype = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntStoreShelfType);
                vm = new VmLogisticStore()
                {
                    EncriptID = Security.Encrypt(id),
                    AreaID = entity.IntAreaID,
                    AreaName = startArea != null ? startArea.Name : "",
                    Contact = entity.VarContact,
                    Details = entity.VarDetails,
                    ValidDate = entity.DteValid,
                    Phone = entity.VarPhone,
                    ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                    ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                    Flag = entity.IntFlag,
                    StoreType = entity.IntStoreType,
                    StoreTitle = entity.VarStoreTitle,
                    StoreShelfType = entity.IntStoreShelfType,
                    StoreCapacity = entity.IntStoreCapacity,
                    StoreUseCapacity = entity.IntStoreUseCapacity,
                    VarUnit = entity.VarUnit,
                    Type = type.ItemName,
                    ShelfType = shelftype.ItemName
                };
            }
            return vm;
        }


        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public LogisticStorePaging GetLogisticStorePager(SmLogisticStore search, int page, int rows)
        {
            LogisticStorePaging pager = new LogisticStorePaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmLogisticStore>("ProcGetStoreList @p0,@p1,@p2,@p3,@p4,@p5",
                        string.IsNullOrWhiteSpace(search.StoreTitle) ? "" : search.StoreTitle
                        , search.state
                         , search.ISTG ?? string.Empty
                        , user.IntUserID
                        , page
                        , rows);

                    pager.total = context.Database.SqlQuery<int>("ProcGetStoreListCount @p0,@p1,@p2,@p3",
                        string.IsNullOrWhiteSpace(search.StoreTitle) ? "" : search.StoreTitle
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();

                    //pager.rows = list.OrderByDescending(l => l.DteRefresh).Skip((page - 1) * rows)
                    //    .Take(rows).Select(p => new VmLogisticStore
                    pager.rows = list.Select(p => new VmLogisticStore
                         {
                             EncriptID = Security.Encrypt(p.EncriptID),
                             StoreTitle = p.StoreTitle,
                             Type = p.Type,
                             AreaName = p.AreaName,
                             BrowserCount = p.BrowserCount,
                             DteRefresh = p.DteRefresh,
                             ISTG = p.ISTG
                         }).ToList();
                }
            }
            return pager;
        }

        /// <summary>
        /// 得到仓库统计信息
        /// </summary>
        /// <returns></returns>
        public VmCountInfo GetLogisticStoreInfoCount()
        {
            VmCountInfo count = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCountInfo>("ProcGetStoreCountInfo @p0", user.IntUserID);
                    count = list.FirstOrDefault();
                }
            }
            return count;
        }

        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,2刷新,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        public string StoreBatch(int type, string chooses)
        {
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                string[] IDs = chooses.Split(',');
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.LogisticStores.Find(id);
                        if (entity != null)
                        {
                            if (type == 1)
                            {
                                entity.IntFlag = 0;
                            }
                            else if (type == 2 && entity.IntFlag == 3)
                            {
                                entity.DteRefresh = DateTime.Now;
                            }
                            else if (type == 3 && entity.IntFlag == 1)
                            {
                                entity.IntFlag = 2;
                            }
                        }
                    }
                }
                flag = context.SaveChanges();
            }
            if (flag >= 0)
            {
                return "1";
            }
            return "0";
        }

        /// <summary>
        /// 得到审批列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public LogisticStorePaging GetAuditingPager(SmLogisticStore sm, int page, int rows)
        {
            LogisticStorePaging pager = new LogisticStorePaging();

            using (var context = new FaoB2BEntities())
            {
                var list = context.Database.SqlQuery<VmLogisticStore>("ProcGetStoreList @p0,@p1,@p2,@p3,@p4,@p5"
                    , string.IsNullOrWhiteSpace(sm.StoreTitle) ? "" : sm.StoreTitle
                    , 2
                    , 0
                    , 0
                    , page
                    , rows);

                pager.total = context.Database.SqlQuery<int>("ProcGetStoreListCount @p0,@p1,@p2,@p3",
                    string.IsNullOrWhiteSpace(sm.StoreTitle) ? "" : sm.StoreTitle, 2, 0, 0).FirstOrDefault();

                pager.rows = list.OrderByDescending(l => l.DteRefresh).Skip((page - 1) * rows)
                    .Take(rows).Select(p => new VmLogisticStore
                    {
                        EncriptID = Security.Encrypt(p.EncriptID),
                        StoreTitle = p.StoreTitle,
                        Type = p.Type,
                        AreaName = p.AreaName,
                        BrowserCount = p.BrowserCount,
                        DteRefresh = p.DteRefresh,
                        DteValid = p.DteValid,
                        ValidDate = p.ValidDate,
                        Contact = p.Contact,
                        ISTG = p.ISTG
                    }).ToList();
            }
            return pager;
        }
        /// <summary>
        /// 审批操作
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        public string Auditing(string ID, int Result)
        {

            string strID = Security.Decrypt(ID);
            int id = 0;
            if (!int.TryParse(strID, out id))
            {
                return "未找到该信息";
            }
            string str = "该信息不审批";
            using (var context = new FaoB2BEntities())
            {
                var entity = context.LogisticStores.Find(id);
                if (entity != null)
                {
                    if (entity.IntFlag == 2)
                    {
                        entity.IntFlag = Result;
                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            str = "1";
                        }
                    }
                }
            }
            return str;
        }

        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="model"></param>
        public void UpdateBrowserCount(VmLogisticStore model)
        {
            using (var context = new FaoB2BEntities())
            {
                int id = Utils.ToInt(Security.Decrypt(model.EncriptID));
                var entity = context.LogisticStores.Find(id);
                entity.IntBrowserCount++;
                context.SaveChanges();
            }
        }
        #endregion

        #region 辅助方法

        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="infoID">对应的信息ID</param>
        /// <returns></returns>
        private void SaveImage(FaoB2BEntities context, int infoID, VmB2BInfoPicture picture)
        {
            int i = 0;
            int j = 1;
            while (true)
            {
                if (picture.PictureUrls[i] != "" || picture.PictureIDs[i] != "")
                {
                    int id = 0;
                    string strID = Security.Decrypt(picture.PictureIDs[i]);
                    int.TryParse(strID, out id);
                    if (SaveImage(context, picture.PictureUrls[i], picture.OriginalName[i], infoID, j, id))
                    {
                        j++;
                    }
                }
                i++;
                if (i > 2)
                {
                    break;
                }
            }

        }
        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="originalName"></param>
        /// <param name="infoID"></param>
        /// <param name="orderID"></param>
        /// <param name="imageID"></param>
        private bool SaveImage(FaoB2BEntities context, string fileName, string originalName, int infoID, int orderID, int imageID = 0)
        {
            bool flag = false;
            VmAttachment oldAtt = null;
            if (imageID != 0)
            {
                oldAtt = attachmentService.GetAttachmentByID(context, imageID.ToString());
            }
            if (fileName != "" && originalName != "")
            {
                VmAttachment attachment = new VmAttachment();
                attachment.BelongTable = 2;
                attachment.PK = infoID;
                attachment.FileName = originalName;
                attachment.Path = fileName;
                attachment.Descrip = "";
                attachment.Order = orderID;
                if (imageID == 0)
                {
                    attachmentService.AddAttachment(context, attachment);

                }
                else
                {
                    attachment.ID = imageID;
                    attachmentService.UpdateAttachment(context, attachment);
                }
                flag = true;
            }
            else if (fileName == "" && imageID != 0)
            {
                attachmentService.DeleteAttachment(context, imageID);
                flag = false;
            }
            else if (oldAtt != null && oldAtt.Order != orderID)
            {
                oldAtt.Order = orderID;
                attachmentService.UpdateAttachment(context, oldAtt);
                flag = true;
            }
            else if (fileName != "" && imageID != 0)
            {
                flag = true;
            }
            return flag;
        }

        #endregion


        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(LogisticStore entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(LogisticStore entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(LogisticStore entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public LogisticStore One(IQueryable<LogisticStore> query, LogisticStore entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<LogisticStore> Many(IQueryable<LogisticStore> query, LogisticStore entity)
        {
            var entitys = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntCreateUserID != 0)
                {
                    entitys = entitys.Where(p => p.IntCreateUserID == entity.IntCreateUserID);
                }
            }
            entitys = entitys.Where(e => e.IntFlag != 0);
            return entitys;
        }

        #endregion

    }
}
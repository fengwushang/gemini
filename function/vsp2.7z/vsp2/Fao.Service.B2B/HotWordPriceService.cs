﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common; 

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// HotWordPrice服务实现-Power by CodeGG
    /// </summary>
    public class HotWordPriceService : Entity<HotWordPrice>, IHotWordPriceService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmHotWordPrice查询模型，返回VmHotWordPrice视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmHotWordPrice> GetHotWordPrices(SmHotWordPrice searchModel)
        {
            throw new Exception("没有实现");
        }


        /// <summary>
        /// 取得该类型，该词的推广状态
        /// </summary>
        /// <param name="id"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public List<VmHotWordPrice> GetOneHotWordPrices(string keyword)
        {
            List<VmHotWordPrice> entities = new List<VmHotWordPrice>();
            using (var context = new FaoB2BEntities())
            {
                entities = context.Database.SqlQuery<VmHotWordPrice>("ProcGetOneHotWordPrice @p0", keyword).ToList();
                //var rows = entities.Select(e => new VmHotWordPrice
                //    { 
                //        IntWordType = e.IntWordType,
                //        DecStartPrice = e.DecStartPrice,
                //        DecStepPrice = e.DecStepPrice
                //    }).ToList();
                //page.rows = rows;
                //page.total = 0;
                //return page;
             
            }  
            return entities;
        }

         
        /// <summary>
        /// 根据id，返回VmHotWordPrice视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmHotWordPrice GetHotWordPriceByID(string id)
        {
            throw new Exception("没有实现");
        }


        /// <summary>
        /// 得到热词价格
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VmHotWordPricePaging GetHotWordPricePaging(SmHotWordPrice sm, int page, int rows)
        {
            string hotword = sm.WordKey == null ? string.Empty : sm.WordKey;
            int wordtype = sm.Type;
            DateTime startTime, endTime;
            if (!DateTime.TryParse(sm.StartTime, out startTime))
            {
                startTime = DateTime.Parse("1/1/1753 12:00:00");
            }
            if (!DateTime.TryParse(sm.EndTime, out endTime))
            {
                endTime = DateTime.MaxValue;
            }
            if (endTime != DateTime.MaxValue)
            {
                endTime = endTime.AddDays(1);
            }
            VmHotWordPricePaging list = new VmHotWordPricePaging();
            using (var context = new FaoB2BEntities())
            {
                list.rows = context.Database.SqlQuery<VmHotWordPrice>("ProcGetHotWordPriceList @p0,@p1,@p2,@p3,@p4,@p5", hotword, wordtype, startTime, endTime, page, rows).ToList();
                list.total = context.Database.SqlQuery<int>("ProcGetHotWordPriceListCount @p0,@p1,@p2,@p3", hotword, wordtype, startTime, endTime).FirstOrDefault();
            }
            list.rows.ForEach(l => l.EncriptID = Security.Encrypt(l.EncriptID));
            return list;

        }

        /// <summary>
        /// 删除热词价格
        /// </summary>
        /// <param name="EncriptID"></param>
        /// <returns></returns>
        public string DeleteHotWordPrice(string EncriptID)
        {
            string strID = Security.Decrypt(EncriptID);
            int id = Utils.ToInt(strID);
            string msg;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.HotWordPrices.Find(id);
                if (entity != null)
                {
                    entity.IntFlag = 0;
                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "删除失败";
                    }
                }
                else
                {
                    msg = "未找到该记录";
                }
            }
            return msg;
        }

        /// <summary>
        /// 添加热词价格
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddHotWordPrice(VmHotWordPrice model)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var adminID = HtmlHelper.GetCookieValue("AdminID");
                string name = model.VarWord;
                int type=model.IntWordType;
                var e = Many(context.HotWordPrices, null).Where(p => p.VarWord == name && p.IntWordType == type).Count();
                if (e > 0)
                {
                    rv = "该热词已存在";
                }
                else
                {
                    HotWordPrice entity = new HotWordPrice();
                    entity.IntFlag = 1;
                    entity.VarWord = model.VarWord;
                    entity.DteCreate = DateTime.Now;
                    entity.DecStartPrice = model.DecStartPrice;
                    entity.DecStepPrice = model.DecStepPrice;
                    entity.IntWordType = model.IntWordType;
                    context.HotWordPrices.Add(entity);
                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        rv = "1";
                    }
                    else
                    {
                        rv = "保存失败";
                    }
                }
            }

            return rv;
        }

        /// <summary>
        /// 修改热词价格
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateHotWordPrice(VmHotWordPrice model)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                if (model == null)
                {
                    rv = "保存失败";
                }
                else
                {
                    string strid = Security.Decrypt(model.EncriptID);
                    string name = model.VarWord;
                    int type = model.IntWordType;
                    int id = Utils.ToInt(strid);
                    var e = Many(context.HotWordPrices, null).Where(p => p.VarWord == name && p.IntWordType == type && p.IntWordPriceId != id).Count();
                    if (e > 0)
                    {
                        rv = "该热词已存在";
                    }
                    else
                    {
                        var entity = context.HotWordPrices.Find(id);
                        if (entity != null)
                        {
                            entity.VarWord = model.VarWord;
                            entity.DecStartPrice = model.DecStartPrice;
                            entity.DecStepPrice = model.DecStepPrice;
                            entity.IntWordType = model.IntWordType;
                            int flag = context.SaveChanges();
                            if (flag >= 0)
                            {
                                rv = "1";
                            }
                            else
                            {
                                rv = "保存失败";
                            }
                        }
                        else
                        {
                            rv = "保存失败";
                        }
                    }
                }
            }

            return rv;
        }
        #endregion    

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(HotWordPrice entity)
        {
            throw new Exception("没有实现");
        }
         
        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(HotWordPrice entity)
        {
            throw new Exception("没有实现");
        }
          
        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(HotWordPrice entity)
        {
            throw new Exception("没有实现");
        }
        
        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public HotWordPrice One(IQueryable<HotWordPrice> query, HotWordPrice entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<HotWordPrice> Many(IQueryable<HotWordPrice> query, HotWordPrice entity)
        {
            var entities = query.Select( e => e);

            if (entity != null)
            { 
                
            }

            entities = entities.Where( e => e.IntFlag != 0);

            return entities;
        }

        #endregion    

    }
}
﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// PPCRecord服务实现-Power by CodeGG
    /// </summary>
    public class PPCRecordService : Entity<PPCRecord>, IPPCRecordService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmPPCRecord查询模型，返回VmPPCRecord视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmPPCRecord> GetPPCRecords(SmPPCRecord searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmPPCRecord视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmPPCRecord GetPPCRecordByID(string id)
        {
            throw new Exception("没有实现");
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(PPCRecord entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(PPCRecord entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(PPCRecord entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public PPCRecord One(IQueryable<PPCRecord> query, PPCRecord entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作 
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<PPCRecord> Many(IQueryable<PPCRecord> query, PPCRecord entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntPPCID != 0)
                {
                    entities = entities.Where(e => e.IntPPCID == entity.IntPPCID);
                }

                if (entity.DateCreate != null)
                {
                    //扣费判断日期是否相等
                    entities = entities.Where(e => e.DateCreate == entity.DateCreate);
                }

                if (!string.IsNullOrEmpty(entity.VarVisitIP))
                {
                    //扣费判断ip是否相等
                    entities = entities.Where(e => e.VarVisitIP == entity.VarVisitIP);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
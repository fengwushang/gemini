﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Fao.Common;
using Fao.Data.Sms.DAL;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// B2BInfo服务实现-Power by CodeGG
    /// </summary>
    public class B2BInfoService : Entity<B2BInfo>, IB2BInfoService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();
        IEnterpriseService enterpriseService = new EnterpriseService();
        IBaseAreaService baseAreaService = new BaseAreaService();

        IAttachmentService attachmentService = new AttachmentService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmB2BInfo查询模型，返回VmB2BInfo视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmB2BInfo> GetB2BInfos(SmB2BInfo searchModel)
        {
            throw new Exception("没有实现");
        }


        /// <summary>
        /// 根据id，返回VmB2BInfo视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmB2BInfo GetB2BInfoByID(int id)
        {
            var info = new VmB2BInfo();
            using (var context = new FaoB2BEntities())
            {
                var entity = context.B2BInfo.Find(id);

                info = GetVMFrom(context, entity);
            }

            return info;
        }

        /// <summary>
        /// 根据id，返回VmB2BInfo视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmB2BInfo GetB2BInfoByID(FaoB2BEntities context, int id)
        {
            var info = new VmB2BInfo();
            var entity = context.B2BInfo.Find(id);
            info = GetVMFrom(context, entity);
            return info;
        }

        /// <summary>
        /// 审批B2B信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string AuditingB2BInfo(string Encriptid, int auditingResult)
        {
            string msg = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                string strID = Security.Decrypt(Encriptid);
                int id = Utils.ToInt(strID);

                var entity = context.B2BInfo.FirstOrDefault(e => e.IntInfoID == id);
                if (entity != null)
                {
                    if (entity.IntFlag != 2)
                    {
                        msg = "该信息不审批";
                    }
                    else
                    {
                        entity.IntFlag = auditingResult;
                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            msg = "1";
                        }
                    }
                }
                else
                {
                    msg = "未找到该信息";
                }

            }

            return msg;
        }

        /// <summary>
        /// 返回分布列表
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        public VMB2BInfoList GetAuditingPager(SmB2BInfo searchModel, int page, int rows)
        {
            VMB2BInfoList pager = new VMB2BInfoList();
            using (var context = new FaoB2BEntities())
            {
                var list = context.Database.SqlQuery<VmB2BInfo>("ProcGetAuditingB2BList @p0,@p1,@p2,@p3",
                    searchModel.InfoTitle == null ? "" : searchModel.InfoTitle, searchModel.Type, page, rows);

                pager.total = context.Database.SqlQuery<int>("ProcGetAuditingB2BListCount @p0,@p1",
                    searchModel.InfoTitle == null ? "" : searchModel.InfoTitle, searchModel.Type).FirstOrDefault();

                pager.rows = list.Select(c => new VmB2BInfo
                {
                    InfoID = Security.Encrypt(c.InfoID),
                    TypeName = c.TypeID == 1 ? "供应信息" : c.TypeID == 2 ? "求购信息" : c.TypeID == 4 ? "合作信息" : c.TypeID == 3 ? "招商信息" : "代理信息",
                    Email = c.Email,
                    DateValid = c.DateValid,
                    DateCreate = c.DateCreate,
                    DateRefresh = c.DateRefresh,
                    Flag = c.Flag,
                    Title = c.Title,
                    Content = c.Content,
                    UserName = c.UserName
                }).ToList();

            }
            return pager;
        }


        /// <summary>
        /// 返回电商门户页面需要的供需信息列表。
        /// </summary>
        /// <param name="info">查询条件</param>
        /// <param name="page">当前第几页</param>
        /// <param name="rows">每页多少条</param>
        /// <returns></returns>
        public VmInfoForHomePaging SearchInfosPaging(SmB2BInfo info, int page, int rows)
        {
            VmInfoForHomePaging pager = new VmInfoForHomePaging();
            using (var context = new FaoB2BEntities())
            {
                var entities = context.Database.SqlQuery<VmInfoForHome>(
                    "ProcGetSearchInfos @p0,@p1,@p2,@p3,@p4"
                    , info.Category
                    , info.Type
                    , string.IsNullOrWhiteSpace(info.InfoTitle) ? string.Empty : info.InfoTitle
                    , page
                    , rows
                    );
                pager.total = context.Database.SqlQuery<int>(
                    "ProcGetSearchInfosCount @p0,@p1,@p2"
                    , info.Category
                    , info.Type
                    , string.IsNullOrWhiteSpace(info.InfoTitle) ? string.Empty : info.InfoTitle

                    ).FirstOrDefault();
                var list = entities.Select(e => new
                    {
                        ID = e.ID,
                        Sms = e.Sms,
                        Title = e.Title,
                        Detail = e.Detail,
                        RefreshDate = e.RefreshDate,
                        CreateUserID = e.CreateUserID,
                        EntName = e.EntName,
                        Area = e.Area,
                        OrderCount = e.OrderCount,
                        Total = e.Total,
                        Unit = e.Unit,
                        Price = e.Price,
                        PPCID = e.PPCID
                    }).ToList();
                //查找第一个附件
                var infoIDs = list.Select(e => Utils.ToInt(e.ID));
                var attList = attachmentService.GetMainAttachments(context.Attachments, infoIDs)
                    .Select(e => new
                    {
                        e.IntBelongTablePrikeyID,
                        e.VarFilePath
                    }).ToList();

                //查找地区列表数据 
                var areaIDs = list.Select(e => Utils.ToInt(e.Area)).ToList();

                var areaList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaIDs);

                var centerlist = list.Join(areaList, p => p.Area, a => a.AreaID.ToString(), (p, a) => new
                   {
                       Sms = p.Sms,
                       ID = p.ID,
                       Title = p.Title,
                       Detail = p.Detail,
                       RefreshDate = p.RefreshDate,
                       CreateUserID = p.CreateUserID,
                       EntName = p.EntName,
                       Area = a.Name,
                       AreaID = a.AreaID,
                       OrderCount = p.OrderCount,
                       Total = p.Total,
                       Unit = p.Unit,
                       Price = p.Price,
                       PPCID = p.PPCID
                   });
                var conterList2 = centerlist.Join(attList, p => p.ID, a => a.IntBelongTablePrikeyID.ToString(), (p, a) => new
                {
                    Sms = p.Sms,
                    ID = p.ID,
                    Title = p.Title,
                    Detail = p.Detail,
                    RefreshDate = p.RefreshDate,
                    CreateUserID = p.CreateUserID,
                    EntName = p.EntName,
                    Area = p.Area,
                    AreaID = p.AreaID,
                    OrderCount = p.OrderCount,
                    Total = p.Total,
                    Unit = p.Unit,
                    Price = p.Price,
                    ImgUrl = a.VarFilePath,
                    PPCID = p.PPCID
                });

                pager.rows = conterList2.Select(p => new VmInfoForHome
                {
                    Sms = Common.Security.Encrypt(p.Sms),
                    ID = Common.Security.Encrypt(p.ID),
                    Title = p.Title,
                    Detail = Utils.SubString(p.Detail, 150),
                    RefreshDate = p.RefreshDate,
                    CreateUserID = Common.Security.Encrypt(p.CreateUserID),
                    EntName = p.EntName,
                    Area = p.Area,
                    OrderCount = p.OrderCount,
                    Total = p.Total,
                    Unit = p.Unit,
                    Price = p.Price,
                    ImgUrl = p.ImgUrl,
                    PPCID = p.PPCID
                }).ToList();


            }


            return pager;
        }

        //public VmInfoForHomePaging SearchInfosPaging(SmB2BInfo info, int page, int rows)
        //{
        //    using (FaoB2BEntities context = new FaoB2BEntities())
        //    {
        //        VmInfoForHomePaging model = new VmInfoForHomePaging();
        //        string selectString = "";
        //        string tableName = "B2BInfo";
        //        string primaryKey = "IntInfoID";
        //        string filter = "";
        //        string whereString1 = " and VaInfoTitle like '%{0}%' or VarInfoContent like '%{1}%'";
        //        whereString1 = string.Format(whereString1, info.InfoTitle, info.InfoTitle);
        //        filter += whereString1;
        //        selectString = SQLServerHelper.BuildPageSQL(tableName, primaryKey, filter, page, rows);

        //        IList<B2BInfo> b2bInfoList = context.B2BInfo.SqlQuery(selectString).ToList();
        //        foreach (B2BInfo b2bInfo in b2bInfoList)
        //        {
        //            VmInfoForHome item = new VmInfoForHome();
        //            Enterprise enterprise = context.Enterprises.Find(b2bInfo.IntEnterpriseID);
        //            BaseUser user = context.BaseUsers.Find(enterprise.IntCreateUserID);
        //            UserTransaction userTransaction = context.UserTransactions.FirstOrDefault(m => m.IntUserID == user.IntUserID);
        //            BaseArea area = context.BaseAreas.Find(b2bInfo.IntAreaID);
        //            Attachment attachment = context.Attachments.Find(enterprise.IntEnterpriseID);
        //            item.ID = b2bInfo.IntInfoID.ToString();
        //            item.Sms = user.IntPhoneVerify.ToString();
        //            item.Title = b2bInfo.VaInfoTitle;
        //            item.Detail = b2bInfo.VarInfoContent;
        //            item.RefreshDate = b2bInfo.DteRefresh.ToString("yyyy-MM-dd");
        //            item.CreateUserID = b2bInfo.IntCreateUserID.ToString();
        //            item.EntName = enterprise.VarEnterpriseName;
        //            item.Area = area.VarAreaName;
        //            item.OrderCount = "1";
        //            item.Total = "1";
        //            item.Unit = "1";
        //            item.Price = 1;
        //            item.ImgUrl = attachment.VarFilePath;
        //            item.PPCID = "1";
        //        }
        //        return model;
        //    }
        //}
        /// <summary>
        /// 删除选择记录
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        public string DeleteChooses(string[] IDs)
        {
            string rv = "0";
            using (var context = new FaoB2BEntities())
            {
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.B2BInfo.Find(id);
                        if (entity != null)
                        {
                            entity.IntFlag = 0;
                        }
                    }
                }
                int flag = context.SaveChanges();
                if (flag >= 0)
                {
                    rv = "1";
                }

            }
            return rv;
        }

        /// <summary>
        /// 刷新选中记录
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        public string RefreshChooses(string[] IDs)
        {
            string rv = "0";
            using (var context = new FaoB2BEntities())
            {
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.B2BInfo.Find(id);
                        if (entity != null && entity.IntFlag == 3)
                        {
                            entity.DteRefresh = DateTime.Now;
                        }
                    }
                }
                int flag = context.SaveChanges();
                if (flag >= 0)
                {
                    rv = "1";
                }

            }
            return rv;
        }

        /// <summary>
        /// 提交选中记录
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        public string ApproveChooses(string[] IDs)
        {
            string rv = "0";
            using (var context = new FaoB2BEntities())
            {
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.B2BInfo.Find(id);
                        if (entity != null && entity.IntFlag == 1)
                        {
                            entity.IntFlag = 2;
                        }
                    }
                }
                int flag = context.SaveChanges();
                if (flag >= 0)
                {
                    rv = "1";
                }

            }
            return rv;
        }


        #region 供应信息

        /// <summary>
        /// 添加供应信息
        /// </summary>
        /// <param name="model">要添加的数据</param>
        /// <returns></returns>
        public string AddSupplyInfo(VmSupply model, VmB2BInfoPicture picture)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                var enterprise = enterpriseService.GetCurrentEnterprise(context);
                if (user == null)
                {
                    rv = "用户未登陆";
                }
                else
                {
                    B2BInfo entity = GetDefault();
                    entity.IntCreateUserID = user.IntUserID;
                    entity.IntEnterpriseID = enterprise != null ? Common.Utils.ToInt(enterprise.EntID) : 0;
                    entity.IntAreaID = model.AreaID ?? 0;
                    entity.IntCategoryId = model.CategoryID ?? 0;
                    entity.VarModel = model.Model == null ? string.Empty : model.Model;
                    entity.VaInfoTitle = model.Title;
                    entity.VarSpecifications = model.Specification == null ? string.Empty : model.Specification;
                    entity.VarInfoContent = model.Content == null ? string.Empty : model.Content;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.VarUnitName = model.UnitName == null ? string.Empty : model.UnitName;
                    entity.DecUnitPrice = model.UnitPrice ?? 0M;
                    entity.IntMOQ = model.MOQ ?? 0;
                    entity.IntTotalAvailability = model.Total ?? 0;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.IntInfoType = 1;
                    context.B2BInfo.Add(entity);
                    int flag = context.SaveChanges();
                    SaveImage(context, entity.IntInfoID, picture);
                    if (flag >= 0)
                    {
                        rv = "1";
                    }
                    else
                    {
                        rv = "保存失败";
                    }
                }
            }

            return rv;
        }

        /// <summary>
        /// 修改供信息
        /// </summary>
        /// <param name="model">要更新的数据</param>
        /// <returns></returns>
        public string UpdateSupplyInfo(VmSupply model, VmB2BInfoPicture picture = null)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                string strID = Common.Security.Decrypt(model.EncriptID);
                int id;
                if (!int.TryParse(strID, out id))
                {
                    rv = "未提到该记录";
                }
                else
                {
                    var entity = context.B2BInfo.Find(id);
                    if (entity != null)
                    {
                        entity.IntAreaID = model.AreaID ?? 0;
                        entity.IntCategoryId = model.CategoryID ?? 0;
                        entity.VaInfoTitle = model.Title;
                        entity.VarModel = model.Model == null ? string.Empty : model.Model;
                        entity.VarSpecifications = model.Specification ?? string.Empty;
                        entity.VarInfoContent = model.Content;
                        entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                        entity.VarUnitName = model.UnitName == null ? string.Empty : model.UnitName;
                        entity.DecUnitPrice = model.UnitPrice ?? 0M;
                        entity.IntMOQ = model.MOQ ?? 0;
                        entity.IntTotalAvailability = model.Total ?? 0;
                        entity.DteRefresh = DateTime.Now;
                        entity.IntFlag = model.Flag ?? 1;
                        entity.VarInfoContent = entity.VarInfoContent ?? "";
                    }

                    int flag = context.SaveChanges();
                    if (picture != null)
                    {
                        SaveImage(context, entity.IntInfoID, picture);
                        //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                        PPCService pPCService = new PPCService();
                        pPCService.DeletePPC(1, entity.IntInfoID);
                    }
                    if (flag >= 0)
                    {
                        rv = "1";
                    }
                    else
                    {
                        rv = "保存失败";
                    }
                }
            }
            return rv;
        }

        /// <summary>
        /// 根据ID得到供应信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmSupply GetSupplyInfoBy(int id)
        {
            VmSupply supply = null;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.B2BInfo.Find(id);
                if (entity != null && entity.IntInfoType == 1)
                {
                    var areaList = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int> { entity.IntAreaID });

                    var attList = attachmentService.GetAttachmentsByTablePK(context, id);
                    supply = new VmSupply
                    {
                        EncriptID = Common.Security.Encrypt(entity.IntInfoID),
                        AreaID = entity.IntAreaID,
                        CategoryID = entity.IntCategoryId,
                        Title = entity.VaInfoTitle,
                        Model = entity.VarModel,
                        Specification = entity.VarSpecifications,
                        Content = entity.VarInfoContent??"",
                        ValidDate = entity.DteValid,
                        StrValidDate = Common.Utils.GetDateTimeFormate(entity.DteValid),
                        UnitName = entity.VarUnitName,
                        UnitPrice = decimal.Round(entity.DecUnitPrice,2),
                        MOQ = entity.IntMOQ,
                        Total = entity.IntTotalAvailability,
                        CreateDate = entity.DteCreate,
                        StrCreateDate = Common.Utils.GetDateTimeFormate(entity.DteCreate),
                        RefreshDate = entity.DteRefresh,
                        StrRefreshDate = Common.Utils.GetDateTimeFormate(entity.DteRefresh),
                        Flag = entity.IntFlag,
                        AreaName = (areaList != null && areaList.Count > 0) ? areaList[0].Name : "",
                        CategoryName = entity.Category.VarCategoryName,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>()

                    };
                }
            }
            return supply;
        }

        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public VMSupplyPaging GetSupplyPager(SmSupply search, int page, int rows)
        {
            IEnumerable<VmSupply> list = null;
            VMSupplyPaging pager = new VMSupplyPaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    list = context.Database.SqlQuery<VmSupply>("ProcGetB2BList @p0,@p1,@p2,@p3,@p4,@p5,@p6",
                        search.Title == null ? string.Empty : search.Title
                        , 1
                        , search.state
                        ,search.ISTG??string.Empty
                        , user.IntUserID
                        , page
                        , rows
                        );

                    pager.total = context.Database.SqlQuery<int>("ProcGetB2BListCount @p0,@p1,@p2,@p3,@p4",
                        search.Title == null ? string.Empty : search.Title
                        , 1
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();
                    pager.rows = list.Select(p => new VmSupply
                        {
                            EncriptID = Security.Encrypt(p.EncriptID),
                            CategoryName = p.CategoryName,
                            Flag = p.Flag,
                            StrRefreshDate = p.StrRefreshDate,
                            Title = p.Title,
                            BrowserCount = p.BrowserCount,
                            FirstImageUrl = p.FirstImageUrl,
                            ISTG = p.ISTG
                        }).ToList();
                }
            }
            return pager;
        }


        #endregion

        #region 求购信息

        /// <summary>
        /// 添加求购信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddBuyInfo(VmBuy model, VmB2BInfoPicture picture)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                var enterprise = enterpriseService.GetCurrentEnterprise(context);
                if (user == null)
                {
                    msg = "用户未登陆";
                }
                else
                {
                    B2BInfo entity = GetDefault();
                    entity.IntCreateUserID = user.IntUserID;
                    entity.IntEnterpriseID = enterprise != null ? Common.Utils.ToInt(enterprise.EntID) : 0;
                    entity.IntAreaID = model.AreaID ?? 0;
                    entity.IntCategoryId = model.CategoryID ?? 0;
                    entity.VaInfoTitle = model.Title;
                    entity.VarSpecifications = model.Specification == null ? string.Empty : model.Specification;
                    entity.VarInfoContent = model.Content == null ? string.Empty : model.Content;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.IntTotalAvailability = model.Total ?? 0;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.IntInfoType = 2;
                    entity.VarPackagingrequire = model.Packagingrequire == null ? string.Empty : model.Packagingrequire;
                    entity.VarPriceAsk = model.PriceAsk == null ? string.Empty : model.PriceAsk;
                    entity.VarUnitName = model.UnitName ?? "";
                    context.B2BInfo.Add(entity);
                    int flag = context.SaveChanges();
                    SaveImage(context, entity.IntInfoID, picture);
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 修改求购信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateBuyInfo(VmBuy model, VmB2BInfoPicture picture = null)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                string strID = Common.Security.Decrypt(model.EncriptID);
                int id;
                if (!int.TryParse(strID, out id))
                {
                    msg = "未提到该记录";
                }
                else
                {
                    var entity = context.B2BInfo.Find(id);
                    if (entity != null)
                    {
                        entity.IntAreaID = model.AreaID ?? 0;
                        entity.IntCategoryId = model.CategoryID ?? 0;
                        entity.VaInfoTitle = model.Title;
                        entity.VarSpecifications = model.Specification == null ? string.Empty : model.Specification;
                        entity.VarInfoContent = model.Content??"";
                        entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                        entity.IntTotalAvailability = model.Total ?? 0;
                        entity.DteRefresh = DateTime.Now;
                        entity.IntFlag = model.Flag ?? 1;
                        entity.VarPackagingrequire = model.Packagingrequire == null ? string.Empty : model.Packagingrequire;
                        entity.VarPriceAsk = model.PriceAsk == null ? string.Empty : model.PriceAsk;
                        entity.VarUnitName = model.UnitName ?? "";
                    }

                    int flag = context.SaveChanges();
                    if (picture != null)
                    {
                        SaveImage(context, entity.IntInfoID, picture);

                        //删除 热词推广 信息
                        //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                        PPCService pPCService = new PPCService();
                        pPCService.DeletePPC(6, entity.IntInfoID);
                    }
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 根据ID得到求购信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmBuy GetBuyInfoBy(int id)
        {
            VmBuy model = null;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.B2BInfo.Find(id);
                if (entity == null || entity.IntInfoType != 2)
                {
                    model = null;
                }
                else
                {
                    var areaList = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int> { entity.IntAreaID });

                    var attList = attachmentService.GetAttachmentsByTablePK(context, id);
                    model = new VmBuy
                    {
                        EncriptID = Common.Security.Encrypt(entity.IntInfoID),
                        AreaID = entity.IntAreaID,
                        CategoryID = entity.IntCategoryId,

                        Title = entity.VaInfoTitle,
                        Specification = entity.VarSpecifications,
                        Content = entity.VarInfoContent,
                        ValidDate = entity.DteValid,
                        StrValidDate = Common.Utils.GetDateTimeFormate(entity.DteValid),
                        Total = entity.IntTotalAvailability,
                        CreateDate = entity.DteCreate,
                        StrCreateDate = Common.Utils.GetDateTimeFormate(entity.DteCreate),
                        RefreshDate = entity.DteRefresh,
                        StrRefreshDate = Common.Utils.GetDateTimeFormate(entity.DteRefresh),
                        Flag = entity.IntFlag,
                        AreaName = (areaList != null && areaList.Count > 0) ? areaList[0].Name : "",
                        CategoryName = entity.Category.VarCategoryName,
                        PriceAsk = entity.VarPriceAsk,
                        Packagingrequire = entity.VarPackagingrequire,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                        UnitName= entity.VarUnitName
                    };
                }
            }
            return model;
        }

        /// <summary>
        /// 根据条件得到求购信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public VmBuyPaging GetBuyPager(SmBuy search, int page, int rows)
        {
            VmBuyPaging pager = new VmBuyPaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmBuy>("ProcGetB2BList @p0,@p1,@p2,@p3,@p4,@p5,@p6",
                        search.Title == null ? string.Empty : search.Title
                        , 2
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        , page
                        , rows
                        );

                    pager.total = context.Database.SqlQuery<int>("ProcGetB2BListCount @p0,@p1,@p2,@p3,@p4",
                        search.Title == null ? string.Empty : search.Title
                        , 2
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();
                    pager.rows = list.Select(p => new VmBuy
                        {
                            EncriptID = Security.Encrypt(p.EncriptID),
                            CategoryName = p.CategoryName,
                            Flag = p.Flag,
                            StrRefreshDate = p.StrRefreshDate,
                            Title = p.Title,
                            BrowserCount = p.BrowserCount,
                            FirstImageUrl = p.FirstImageUrl,
                            ISTG = p.ISTG
                        }).ToList();
                }
            }

            return pager;
        }
        #endregion

        #region 合作信息

        /// <summary>
        /// 添加合作信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddCooperationInfo(VmCooperationInfo model, VmB2BInfoPicture picture)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                var enterprise = enterpriseService.GetCurrentEnterprise(context);
                if (user == null)
                {
                    msg = "用户未登陆";
                }
                B2BInfo entity = GetDefault();
                entity.IntCreateUserID = user.IntUserID;
                entity.IntEnterpriseID = enterprise != null ? Common.Utils.ToInt(enterprise.EntID) : 0;
                entity.IntAreaID = model.AreaID ?? 0;
                entity.IntCategoryId = model.CategoryID ?? 0;
                entity.VaInfoTitle = model.Title;
                entity.VarInfoContent = model.Content == null ? string.Empty : model.Content;
                entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                entity.IntFlag = model.Flag ?? 1;
                entity.IntInfoType = 4;
                context.B2BInfo.Add(entity);
                int flag = context.SaveChanges();
                SaveImage(context, entity.IntInfoID, picture);
                if (flag >= 0)
                {
                    msg = "1";
                }
                else
                {
                    msg = "保存失败";
                }
            }
            return msg;
        }

        /// <summary>
        /// 修改合作信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateCooperationInfo(VmCooperationInfo model, VmB2BInfoPicture picture = null)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                string strID = Common.Security.Decrypt(model.EncriptID);
                int id;
                if (!int.TryParse(strID, out id))
                {
                    msg = "未提到该记录";
                }
                else
                {
                    var entity = context.B2BInfo.Find(id);
                    if (entity != null)
                    {
                        entity.IntAreaID = model.AreaID ?? 0;
                        entity.IntCategoryId = model.CategoryID ?? 0;
                        entity.VaInfoTitle = model.Title;
                        entity.VarInfoContent = model.Content??"";
                        entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                        entity.DteRefresh = DateTime.Now;
                        entity.IntFlag = model.Flag ?? 1;
                    }
                    int flag = context.SaveChanges();
                    if (picture != null)
                    {
                        SaveImage(context, entity.IntInfoID, picture);
                        //删除 热词推广 信息
                        //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                        PPCService pPCService = new PPCService();
                        pPCService.DeletePPC(4, entity.IntInfoID);
                    }
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 根据ID得到合作信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmCooperationInfo GetCooperationInfoBy(int id)
        {
            VmCooperationInfo model = null;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.B2BInfo.Find(id);
                if (entity == null || entity.IntInfoType != 4)
                {
                    model = null;
                }
                else
                {
                    var areaList = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int> { entity.IntAreaID });

                    var attList = attachmentService.GetAttachmentsByTablePK(context, id);
                    model = new VmCooperationInfo
                    {
                        EncriptID = Common.Security.Encrypt(entity.IntInfoID),
                        AreaID = entity.IntAreaID,
                        CategoryID = entity.IntCategoryId,
                        Title = entity.VaInfoTitle,
                        Content = entity.VarInfoContent,
                        ValidDate = entity.DteValid,
                        StrValidDate = Common.Utils.GetDateTimeFormate(entity.DteValid),
                        CreateDate = entity.DteCreate,
                        StrCreateDate = Common.Utils.GetDateTimeFormate(entity.DteCreate),
                        RefreshDate = entity.DteRefresh,
                        StrRefreshDate = Common.Utils.GetDateTimeFormate(entity.DteRefresh),
                        Flag = entity.IntFlag,
                        AreaName = (areaList != null && areaList.Count > 0) ? areaList[0].Name : "",
                        CategoryName = entity.Category.VarCategoryName,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>()
                    };
                }
            }
            return model;
        }

        /// <summary>
        /// 根据条件得到合作信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public VmCooperationPaging GetCooperationPager(SmCooperation search, int page, int rows)
        {
            VmCooperationPaging pager = new VmCooperationPaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCooperationInfo>("ProcGetB2BList @p0,@p1,@p2,@p3,@p4,@p5,@p6",
                        search.Title == null ? string.Empty : search.Title
                        , 4
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        , page
                        , rows
                        );
                    pager.total = context.Database.SqlQuery<int>("ProcGetB2BListCount @p0,@p1,@p2,@p3,@p4",
                        search.Title == null ? string.Empty : search.Title
                        , 4
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();
                    pager.rows = list.Select(p => new VmCooperationInfo
                    {
                        EncriptID = Security.Encrypt(p.EncriptID),
                        CategoryName = p.CategoryName,
                        Flag = p.Flag,
                        StrRefreshDate = p.StrRefreshDate,
                        Title = p.Title,
                        BrowserCount = p.BrowserCount,
                        FirstImageUrl = p.FirstImageUrl,
                        ISTG = p.ISTG
                    }).ToList();
                }
            }
            return pager;

        }
        #endregion

        #region 招商信息

        /// <summary>
        /// 添加招商信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddCanvassBussinessInfo(VmCanvassBussiness model, VmB2BInfoPicture picture)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                var enterprise = enterpriseService.GetCurrentEnterprise(context);
                if (user == null)
                {
                    msg = "用户未登陆";
                }
                else
                {
                    var entity = GetDefault();
                    entity.IntCreateUserID = user.IntUserID;
                    entity.IntEnterpriseID = enterprise != null ? Common.Utils.ToInt(enterprise.EntID) : 0;
                    entity.IntAreaID = model.AreaID ?? 0;
                    entity.IntCategoryId = model.CategoryID ?? 0;
                    entity.VaInfoTitle = model.Title;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.IntInfoType = 3;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.IntMinSecurityDeposit = model.SecurityDeposit ?? 0;
                    entity.VarInfoContent = model.Content == null ? string.Empty : model.Content;
                    context.B2BInfo.Add(entity);
                    int flag = context.SaveChanges();
                    SaveImage(context, entity.IntInfoID, picture);
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 修改招商信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateCanvassBussinessInfo(VmCanvassBussiness model, VmB2BInfoPicture picture = null)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                string strID = Common.Security.Decrypt(model.EncriptID);
                int id;
                if (!int.TryParse(strID, out id))
                {
                    msg = "未提到该记录";
                }
                else
                {
                    var entity = context.B2BInfo.Find(id);
                    if (entity != null)
                    {
                        entity.IntAreaID = model.AreaID ?? 0;
                        entity.IntCategoryId = model.CategoryID ?? 0;
                        entity.VaInfoTitle = model.Title;
                        entity.VarInfoContent = model.Content;
                        entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                        entity.DteRefresh = DateTime.Now;
                        entity.IntFlag = model.Flag ?? 1;
                        entity.IntMinSecurityDeposit = model.SecurityDeposit ?? 0;
                    }
                    int flag = context.SaveChanges();
                    if (picture != null)
                    {
                        SaveImage(context, entity.IntInfoID, picture);

                        //删除 热词推广 信息
                        //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                        PPCService pPCService = new PPCService();
                        pPCService.DeletePPC(3, entity.IntInfoID);
                    }
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 根据ID得到招商信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmCanvassBussiness GetCanvassBussinessInfoBy(int id)
        {
            VmCanvassBussiness model = null;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.B2BInfo.Find(id);
                if (entity == null || entity.IntInfoType != 3)
                {
                    model = null;
                }
                else
                {
                    var areaList = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int> { entity.IntAreaID });

                    var attList = attachmentService.GetAttachmentsByTablePK(context, id);
                    model = new VmCanvassBussiness
                    {
                        EncriptID = Common.Security.Encrypt(entity.IntInfoID),
                        AreaID = entity.IntAreaID,
                        CategoryID = entity.IntCategoryId,
                        Title = entity.VaInfoTitle,
                        Content = entity.VarInfoContent,
                        ValidDate = entity.DteValid,
                        StrValidDate = Common.Utils.GetDateTimeFormate(entity.DteValid),
                        CreateDate = entity.DteCreate,
                        StrCreateDate = Common.Utils.GetDateTimeFormate(entity.DteCreate),
                        RefreshDate = entity.DteRefresh,
                        StrRefreshDate = Common.Utils.GetDateTimeFormate(entity.DteRefresh),
                        Flag = entity.IntFlag,
                        AreaName = (areaList != null && areaList.Count > 0) ? areaList[0].Name : "",
                        CategoryName = entity.Category.VarCategoryName,
                        SecurityDeposit = entity.IntMinSecurityDeposit,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>()

                    };
                }
            }
            return model;

        }

        /// <summary>
        /// 根据条件得到招商信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public VmCanvassBussinessPaging GetCanvassBussinessPager(SmCanvassBussiness search, int page, int rows)
        {
            VmCanvassBussinessPaging pager = new VmCanvassBussinessPaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCanvassBussiness>("ProcGetB2BList @p0,@p1,@p2,@p3,@p4,@p5,@p6",
                        search.Title == null ? string.Empty : search.Title
                        , 3
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        , page
                        , rows
                        );
                    pager.total = context.Database.SqlQuery<int>("ProcGetB2BListCount @p0,@p1,@p2,@p3,@p4",
                        search.Title == null ? string.Empty : search.Title
                        , 3
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();
                    pager.rows = list.Select(p => new VmCanvassBussiness
                        {
                            EncriptID = Security.Encrypt(p.EncriptID),
                            CategoryName = p.CategoryName,
                            Flag = p.Flag,
                            StrRefreshDate = p.StrRefreshDate,
                            Title = p.Title,
                            BrowserCount = p.BrowserCount,
                            FirstImageUrl = p.FirstImageUrl,
                            ISTG = p.ISTG
                        }).ToList();
                }
            }
            return pager;
        }


        /// <summary>
        /// 添加代理信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddProxyInfo(VmProxy model, VmB2BInfoPicture picture)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                var enterprise = enterpriseService.GetCurrentEnterprise(context);
                if (user == null)
                {
                    msg = "用户未登陆";
                }
                else
                {
                    var entity = GetDefault();
                    entity.IntCreateUserID = user.IntUserID;
                    entity.IntEnterpriseID = enterprise != null ? Common.Utils.ToInt(enterprise.EntID) : 0;
                    entity.IntAreaID = model.AreaID ?? 0;
                    entity.IntCategoryId = model.CategoryID ?? 0;
                    entity.VaInfoTitle = model.Title;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.IntInfoType = 5;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.IntMinSecurityDeposit = model.SecurityDeposit ?? 0;
                    entity.VarInfoContent = model.Content == null ? string.Empty : model.Content;
                    context.B2BInfo.Add(entity);
                    int flag = context.SaveChanges();

                    //保存图片
                    SaveImage(context, entity.IntInfoID, picture);
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 修改代理信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateProxyInfo(VmProxy model, VmB2BInfoPicture picture = null)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                string strID = Common.Security.Decrypt(model.EncriptID);
                int id;
                if (!int.TryParse(strID, out id))
                {
                    msg = "未提到该记录";
                }
                else
                {
                    var entity = context.B2BInfo.Find(id);
                    if (entity != null)
                    {
                        entity.IntAreaID = model.AreaID ?? 0;
                        entity.IntCategoryId = model.CategoryID ?? 0;
                        entity.VaInfoTitle = model.Title;
                        entity.VarInfoContent = model.Content;
                        entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                        entity.DteRefresh = DateTime.Now;
                        entity.IntFlag = model.Flag ?? 1;
                        entity.IntMinSecurityDeposit = model.SecurityDeposit ?? 0;
                        entity.VarInfoContent = entity.VarInfoContent ?? "";
                    }
                    int flag = context.SaveChanges();
                    //保存图片
                    if (picture != null)
                    {
                        SaveImage(context, entity.IntInfoID, picture);
                        //删除 热词推广 信息
                        //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                        PPCService pPCService = new PPCService();
                        pPCService.DeletePPC(5, entity.IntInfoID);
                    }
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 根据ID得到代理信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmProxy GetProxyInfoBy(int id)
        {
            VmProxy model = null;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.B2BInfo.Find(id);
                if (entity == null || entity.IntInfoType != 5)
                {
                    model = null;
                }
                else
                {
                    var areaList = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int> { entity.IntAreaID });

                    var attList = attachmentService.GetAttachmentsByTablePK(context, id);
                    model = new VmProxy
                    {
                        EncriptID = Common.Security.Encrypt(entity.IntInfoID),
                        AreaID = entity.IntAreaID,
                        CategoryID = entity.IntCategoryId,
                        Title = entity.VaInfoTitle,
                        Content = entity.VarInfoContent,
                        ValidDate = entity.DteValid,
                        StrValidDate = Common.Utils.GetDateTimeFormate(entity.DteValid),
                        CreateDate = entity.DteCreate,
                        StrCreateDate = Common.Utils.GetDateTimeFormate(entity.DteCreate),
                        RefreshDate = entity.DteRefresh,
                        StrRefreshDate = Common.Utils.GetDateTimeFormate(entity.DteRefresh),
                        Flag = entity.IntFlag,
                        AreaName = (areaList != null && areaList.Count > 0) ? areaList[0].Name : "",
                        CategoryName = entity.Category.VarCategoryName,
                        SecurityDeposit = entity.IntMinSecurityDeposit,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>()
                    };
                }
            }
            return model;

        }

        /// <summary>
        /// 根据条件得到代理信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public VmProxyPaging GetProxyPager(SmProxy search, int page, int rows)
        {
            VmProxyPaging pager = new VmProxyPaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCanvassBussiness>("ProcGetB2BList @p0,@p1,@p2,@p3,@p4,@p5,@p6",
                        search.Title == null ? string.Empty : search.Title
                        , 5
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        , page
                        , rows
                        );

                    pager.total = context.Database.SqlQuery<int>("ProcGetB2BListCount @p0,@p1,@p2,@p3,@p4",
                        search.Title == null ? string.Empty : search.Title
                        , 5
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();
                    pager.rows = list.Select(p => new VmProxy
                        {
                            EncriptID = Security.Encrypt(p.EncriptID),
                            CategoryName = p.CategoryName,
                            Flag = p.Flag,
                            StrRefreshDate = p.StrRefreshDate,
                            Title = p.Title,
                            BrowserCount = p.BrowserCount,
                            FirstImageUrl = p.FirstImageUrl,
                            ISTG = p.ISTG
                        }).ToList();
                }
            }
            return pager;
        }

        /// <summary>
        /// 得到统计B2B信息
        /// </summary>
        /// <param name="type"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public VmCountInfo GetB2BInfoCount(int type)
        {
            VmCountInfo count = new VmCountInfo();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCountInfo>("ProcGetB2bCountInfo @p0,@p1", user.IntUserID, type);
                    count = list.FirstOrDefault();
                }
            }
            return count;
        }
        #endregion

        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="b2bInfo"></param>
        public void UpdateBrowserCount(VmB2BInfo b2bInfo)
        { 
            using (var context = new FaoB2BEntities())
            {
                int id = Utils.ToInt(Security.Decrypt(b2bInfo.InfoID));
                var model = context.B2BInfo.Find(id);
                model.IntBrowserCount++;
                context.SaveChanges();
            }
            
        }
        #endregion

        #region 辅助方法

        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="infoID">对应的信息ID</param>
        /// <returns></returns>
        private void SaveImage(FaoB2BEntities context, int infoID, VmB2BInfoPicture picture)
        {
            int i = 0;
            int j = 1;
            while (true)
            {
                if (picture.PictureUrls[i] != "" || picture.PictureIDs[i] != "")
                {
                    int id = 0;
                    string strID = Security.Decrypt(picture.PictureIDs[i]);
                    int.TryParse(strID, out id);
                    if (SaveImage(context, picture.PictureUrls[i], picture.OriginalName[i], infoID, j, id))
                    {
                        j++;
                    }
                }
                i++;
                if (i > 2)
                {
                    break;
                }
            }

        }
        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="originalName"></param>
        /// <param name="infoID"></param>
        /// <param name="orderID"></param>
        /// <param name="imageID"></param>
        private bool SaveImage(FaoB2BEntities context, string fileName, string originalName, int infoID, int orderID, int imageID = 0)
        {
            bool flag = false;
            VmAttachment oldAtt = null;
            if (imageID != 0)
            {
                oldAtt = attachmentService.GetAttachmentByID(context, imageID.ToString());
            }
            if (fileName != "" && originalName != "")
            {
                VmAttachment attachment = new VmAttachment();
                attachment.BelongTable = 6;
                attachment.PK = infoID;
                attachment.FileName = originalName;
                attachment.Path = fileName;
                attachment.Descrip = "";
                attachment.Order = orderID;
                if (imageID == 0)
                {
                    attachmentService.AddAttachment(context, attachment);

                }
                else
                {
                    attachment.ID = imageID;
                    attachmentService.UpdateAttachment(context, attachment);
                }
                flag = true;
            }
            else if (fileName == "" && imageID != 0)
            {
                attachmentService.DeleteAttachment(context, imageID);
                flag = false;
            }
            else if (oldAtt != null && oldAtt.Order != orderID)
            {
                oldAtt.Order = orderID;
                attachmentService.UpdateAttachment(context, oldAtt);
                flag = true;
            }
            else if (fileName != "" && imageID != 0)
            {
                flag = true;
            }
            return flag;
        }

        /// <summary>
        /// 从数据库实体中获得VM
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private VmB2BInfo GetVMFrom(FaoB2BEntities context, B2BInfo entity)
        {
            if (entity == null)
            {
                return new VmB2BInfo();
            }
            var en = context.B2BInfo.FirstOrDefault(e => e.IntInfoID == entity.IntInfoID);


            var area = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int> { en.IntAreaID });
            var enterprise = enterpriseService.GetEnterpriseByID(context, Security.Encrypt(entity.IntEnterpriseID));
            var vm = new VmB2BInfo
            {
                InfoID = Security.Encrypt(en.IntInfoID),
                TypeID = en.IntInfoType,
                BrowserCount = en.IntBrowserCount,
                CategoryName = en.Category != null ? en.Category.VarCategoryName : "",
                Content = en.VarInfoContent,
                DateCreate = Common.Utils.GetDateFormate(en.DteCreate),
                DateRefresh = Common.Utils.GetDateFormate(en.DteRefresh),
                DateValid = en.DteValid.Year == DateTime.MaxValue.Year ? "永久有效" : Common.Utils.GetDateFormate(en.DteValid),
                Email = en.VarEmail,
                EnterpriseID = Common.Security.Encrypt(en.IntEnterpriseID),
                EnterpriseName = enterprise != null ? enterprise.EntName : "",
                InfoContact = en.VarInfoContact,
                MinSecurityDeposit = en.IntMinSecurityDeposit,
                MobilePhone = en.VarMobilePhone,
                MOQ = en.IntMOQ,
                Model = en.VarModel,
                Specifications = en.VarSpecifications,
                Packagingrequire = en.VarPackagingrequire,
                Phone = en.VarPhone,
                PriceAsk = en.VarPriceAsk,
                Title = en.VaInfoTitle,
                TotalAvailability = en.IntTotalAvailability,
                UnitName = en.VarUnitName,
                UnitPrice = en.DecUnitPrice
            };

            switch (vm.TypeID)
            {
                case 1:
                    vm.TypeName = "供应信息";
                    break;
                case 2:
                    vm.TypeName = "求购信息";
                    break;
                case 3:
                    vm.TypeName = "合作信息";
                    break;
                case 4:
                    vm.TypeName = "招商信息";
                    break;
                case 5:
                    vm.TypeName = "代理信息";
                    break;
                default:
                    vm.TypeName = "供应信息";
                    break;
            }

            SmAttachment sm = new SmAttachment()
            {
                IntBelongTable = 6,
                IntBelongTablePrikeyID = entity.IntInfoID
            };
            if (area != null && area.Count > 0)
            {
                vm.AreaName = area[0].Name;
            }

            vm.Attachment = attachmentService.GetAttachments(context, sm);

            return vm;
        }



        /// <summary>
        /// 返回一个默认实体
        /// </summary>
        /// <returns></returns>
        private B2BInfo GetDefault()
        {
            return new B2BInfo
            {
                IntCreateUserID = 0,
                IntEnterpriseID = 0,
                IntAreaID = 0,
                IntIndustryID = 0,
                VaInfoTitle = string.Empty,
                VarModel = string.Empty,
                VarSpecifications = string.Empty,
                VarInfoContent = string.Empty,
                DteValid = DateTime.MaxValue,
                VarUnitName = string.Empty,
                DecUnitPrice = 0,
                IntMOQ = 0,
                IntTotalAvailability = 0,
                DteCreate = DateTime.Now,
                DteRefresh = DateTime.Now,
                IntFlag = 1,
                VarEmail = string.Empty,
                IntCategoryId = 0,
                IntInfoType = 1,
                IntMinSecurityDeposit = 0,
                VarInfoContact = string.Empty,
                VarMobilePhone = string.Empty,
                VarPackagingrequire = string.Empty,
                VarPhone = string.Empty,
                VarPriceAsk = string.Empty,
                IntBrowserCount = 0
            };
        }

        /// <summary>
        /// 获取比对信息列表
        /// </summary>
        /// <param name="ids">加密信息id集合字符串，用“,”分割</param>
        /// <returns></returns>
        public List<VmB2BInfo> GetCompareInfos(string ids)
        {
            var infos = new List<VmB2BInfo>();
            using (var context = new FaoB2BEntities())
            {


                var idArray = Utils.Split(ids);
                var idList = idArray.Select(id => Utils.ToInt(Security.Decrypt(id)));
                if (idArray.Length >= 1)
                {
                    var entities = Many(context.B2BInfo, null)
                        .Where(e => idList.Contains(e.IntInfoID))
                        .Select(e => new
                        {
                            AreaName = e.IntAreaID,
                            BrowserCount = e.IntBrowserCount,
                            CategoryName = e.Category.VarCategoryName,
                            Content = e.VarInfoContent,
                            DateCreate = e.DteCreate,
                            DateRefresh = e.DteRefresh,
                            DateValid = e.DteValid,
                            Email = e.VarEmail,
                            EnterpriseID = e.IntEnterpriseID,
                            InfoContact = e.VarInfoContact,
                            InfoID = e.IntInfoID,
                            MinSecurityDeposit = e.IntMinSecurityDeposit,
                            MobilePhone = e.VarMobilePhone,
                            Model = e.VarModel,
                            MOQ = e.IntMOQ,
                            Phone = e.VarPhone,
                            Packagingrequire = e.VarPackagingrequire,
                            PriceAsk = e.VarPriceAsk,
                            UnitPrice = e.DecUnitPrice,
                            UnitName = e.VarUnitName,
                            TypeID = e.IntInfoType,
                            TotalAvailability = e.IntTotalAvailability,
                            Title = e.VaInfoTitle,
                            Specifications = e.VarSpecifications
                        }).ToList();
                    //查询企业列表数据。
                    var entIDs = entities.Select(e => e.EnterpriseID).ToList();

                    var entList = enterpriseService.Many(context.Enterprises, null)
                        .Where(e => entIDs.Contains(e.IntEnterpriseID))
                        .Select(e => new
                        {
                            e.IntEnterpriseID,
                            e.VarEnterpriseName
                        }).ToList();

                    var infoIDs = entities.Select(e => e.InfoID);
                    var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 6)
                        , infoIDs)
                        .Select(e => new
                        {
                            e.IntBelongTablePrikeyID,
                            e.VarFilePath
                        }).ToList();

                    //查找地区列表数据 
                    var areaIDs = entities.Select(e => e.AreaName).ToList();

                    var areaList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaIDs).Select(a => new
                    {
                        a.AreaID,
                        a.Name
                    }).ToList();
                    var entities2 = entities.Join(entList, i => i.EnterpriseID, e => e.IntEnterpriseID,
                        (i, e) => new
                        {
                            EnterpriseName = e.VarEnterpriseName,
                            AreaName = i.AreaName,
                            BrowserCount = i.BrowserCount,
                            CategoryName = i.CategoryName,
                            Content = i.Content,
                            DateCreate = i.DateCreate,
                            DateRefresh = i.DateRefresh,
                            DateValid = i.DateValid,
                            Email = i.Email,
                            InfoContact = i.InfoContact,
                            InfoID = i.InfoID,
                            MinSecurityDeposit = i.MinSecurityDeposit,
                            MobilePhone = i.MobilePhone,
                            Model = i.Model,
                            MOQ = i.MOQ,
                            Phone = i.Phone,
                            Packagingrequire = i.Packagingrequire,
                            PriceAsk = i.PriceAsk,
                            UnitPrice = i.UnitPrice,
                            UnitName = i.UnitName,
                            TypeID = i.TypeID,
                            TotalAvailability = i.TotalAvailability,
                            Title = i.Title,
                            i.Specifications
                        }).ToList();
                    var entities3 = entities2.Join(attList, i => i.InfoID, a => a.IntBelongTablePrikeyID,
                    (i, a) => new
                    {
                        MainImgUrl = a.VarFilePath,
                        i.EnterpriseName,
                        i.AreaName,
                        i.BrowserCount,
                        i.CategoryName,
                        i.Content,
                        i.DateCreate,
                        i.DateRefresh,
                        i.DateValid,
                        i.Email,
                        i.InfoContact,
                        i.InfoID,
                        i.MinSecurityDeposit,
                        i.MobilePhone,
                        i.Model,
                        i.MOQ,
                        i.Phone,
                        i.Packagingrequire,
                        i.PriceAsk,
                        i.UnitPrice,
                        i.UnitName,
                        i.TypeID,
                        i.TotalAvailability,
                        i.Title,
                        i.Specifications
                    }).ToList();
                    var entities4 = entities3.Join(areaList, i => i.AreaName, a => a.AreaID,
                        (i, a) => new
                        {
                            i.EnterpriseName,
                            AreaName = a.Name,
                            i.BrowserCount,
                            i.CategoryName,
                            i.Content,
                            i.DateCreate,
                            i.DateRefresh,
                            i.DateValid,
                            i.Email,
                            i.InfoContact,
                            i.InfoID,
                            i.MinSecurityDeposit,
                            i.MobilePhone,
                            i.Model,
                            i.MOQ,
                            i.Phone,
                            i.Packagingrequire,
                            i.PriceAsk,
                            i.UnitPrice,
                            i.UnitName,
                            i.TypeID,
                            i.TotalAvailability,
                            i.Title,
                            i.MainImgUrl,
                            i.Specifications
                        }).ToList();
                    var entities5 = entities4.Select(i => new VmB2BInfo
                        {
                            EnterpriseName = i.EnterpriseName,
                            AreaName = i.AreaName,
                            BrowserCount = i.BrowserCount,
                            CategoryName = i.CategoryName,
                            Content = i.Content,
                            DateCreate = Utils.GetDateFormate(i.DateCreate),
                            DateRefresh = Utils.GetDateFormate(i.DateRefresh),
                            DateValid = Utils.GetDateFormate(i.DateValid),
                            Email = i.Email,
                            InfoContact = i.InfoContact,
                            InfoID = Security.Encrypt(i.InfoID),
                            MinSecurityDeposit = i.MinSecurityDeposit,
                            MobilePhone = i.MobilePhone,
                            Model = i.Model,
                            MOQ = i.MOQ,
                            Phone = i.Phone,
                            Packagingrequire = i.Packagingrequire,
                            PriceAsk = i.PriceAsk,
                            UnitPrice = i.UnitPrice,
                            UnitName = i.UnitName,
                            TypeID = i.TypeID,
                            TypeName = i.TypeID == 1 ? "供应信息" : i.TypeID == 2 ? "求购信息" : i.TypeID == 3 ? "合作信息" : i.TypeID == 4 ? "招商信息" : "代理信息",
                            TotalAvailability = i.TotalAvailability,
                            Title = i.Title,
                            MainImgUrl = i.MainImgUrl,
                            Specifications = i.Specifications

                        });

                    infos = entities5.ToList();
                }

            }
            return infos;
        }

        /// <summary>
        /// datatable to list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static List<T> List<T>(DataTable dt)
        {
            var list = new List<T>();
            Type t = typeof(T);
            var plist = new List<PropertyInfo>(typeof(T).GetProperties());

            foreach (DataRow item in dt.Rows)
            {
                T s = System.Activator.CreateInstance<T>();
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    PropertyInfo info = plist.Find(p => p.Name == dt.Columns[i].ColumnName);
                    if (info != null)
                    {
                        if (!Convert.IsDBNull(item[i]))
                        {
                            info.SetValue(s, item[i], null);
                        }
                    }
                }
                list.Add(s);
            }
            return list;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(B2BInfo entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(B2BInfo entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(B2BInfo entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public B2BInfo One(IQueryable<B2BInfo> query, B2BInfo entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<B2BInfo> Many(IQueryable<B2BInfo> query, B2BInfo entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntInfoType != 0)
                {
                    entities = entities.Where(p => p.IntInfoType == entity.IntInfoType);
                }
                if (!string.IsNullOrWhiteSpace(entity.VaInfoTitle))
                {
                    entities = entities.Where(p => p.VaInfoTitle.Contains(entity.VaInfoTitle));
                }
                if (entity.IntFlag != 0)
                {
                    entities = entities.Where(p => p.IntFlag == entity.IntFlag);
                }
                if (entity.IntCreateUserID != 0)
                {
                    entities = entities.Where(p => p.IntCreateUserID == entity.IntCreateUserID);
                }
            }
            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
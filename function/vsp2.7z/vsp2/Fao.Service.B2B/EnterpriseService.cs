﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;

namespace Fao.Service.B2B
{

    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Enterprise服务实现-Power by CodeGG
    /// </summary>
    public class EnterpriseService : Entity<Enterprise>, IEnterpriseService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();
        IBaseAreaService baseAreaService = new BaseAreaService();
        IBaseIndustryService baseIndustryService = new BaseIndustryService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmEnterprise查询模型，返回VmEnterprise视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmEnterprise> GetEnterprises(SmEnterprise searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmEnterprise视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmEnterprise GetEnterpriseByID(string id)
        {
            VmEnterprise vm = new VmEnterprise();
            using (var context = new FaoB2BEntities())
            {
                vm= GetEnterpriseByID(context, id);
            }
            return vm;
        }
        /// <summary>
        /// 根据id，返回VmEnterprise视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmEnterprise GetEnterpriseByID(FaoB2BEntities context, string id)
        {
            int intEnterpriseID = Utils.ToInt(Security.Decrypt(id));

            var User = baseUserService.Many(context.BaseUsers, null);
            var Area = baseAreaService.Many(context.BaseAreas, null);

            var entity = (from e in context.Enterprises
                          join u in User on e.IntCreateUserID equals u.IntUserID
                          join a in Area on e.IntAreaID equals a.IntAreaID
                          where e.IntEnterpriseID == intEnterpriseID
                          select new
                          {
                              Address = e.VarAddress,
                              ContactUser = u.VarRealName,
                              AreaName = a.VarAreaName,
                              ContactUserPhone = u.VarPhone,
                              CreateDate = e.DteCreate,
                              Detail = e.VarEnterpriseDescrip,
                              EntName = e.VarEnterpriseName,
                              EntPhone = e.VarContactPhone,
                              UserID = e.IntCreateUserID
                          }).ToList();

            VmEnterprise vm = new VmEnterprise();
            if (entity.Count > 0)
            {
                vm = entity.Select(e => new VmEnterprise
                {
                    EntID = id,
                    EntName = e.EntName,
                    Address = e.Address,
                    EntPhone = e.EntPhone,
                    Detail = e.Detail,
                    AreaName = e.AreaName,
                    ContactUser = e.ContactUser,
                    ContactUserPhone = e.ContactUserPhone,
                    UserID = Security.Encrypt(e.UserID)
                }).First();
            }

            return vm;
        }
        /// <summary>
        /// 获取企业用户管理列表分页数据
        /// </summary>
        /// <param name="user">查询条件</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页条数</param>
        /// <returns></returns>
        public VmEnterprisePaging GetAdminEnterprises(SmEnterprise ent, int page, int rows)
        {
            VmEnterprisePaging paging = new VmEnterprisePaging();
            using (var context = new FaoB2BEntities())
            {
                var comments = Many(context.Enterprises, new Enterprise
                {
                    VarEnterpriseName = ent.EntName,
                    IntFlag = -1
                }).Select(e => new
                {
                    EntID = e.IntEnterpriseID,
                    ContactUser = e.IntCreateUserID,
                    CreateDate = e.DteCreate,
                    EntName = e.VarEnterpriseName,
                    EntPhone = e.VarContactPhone,
                    Flag = e.IntFlag,
                    UserID = e.IntCreateUserID
                });

                paging.total = comments.Count().ToString();

                var useridList = comments.OrderByDescending(c => c.CreateDate)
                    .Skip((page - 1) * rows).Take(rows).Select(c => c.ContactUser).ToList();

                var users = baseUserService.Many(context.BaseUsers, null)
                    .Where(u => useridList.Contains(u.IntUserID))
                    .Select(u => new
                    {
                        u.IntUserID,
                        u.VarRealName,
                        u.VarPhone,
                        u.VarEmail,
                        u.IntFlag
                    }).ToList();

                paging.rows = comments.OrderByDescending(c => c.CreateDate)
                    .Skip((page - 1) * rows).Take(rows).ToList()
                    .Join(users, c => c.ContactUser, u => u.IntUserID,
                    (c, u) => new VmEnterprise
                    {
                        EntID = Security.Encrypt(c.EntID),
                        EntName = c.EntName,
                        ContactEmail = u.VarEmail,
                        EntPhone = c.EntPhone,
                        ContactUser = u.VarRealName,
                        ContactUserPhone = u.VarPhone,
                        CreateDate = Utils.GetDateWithHMFormate(c.CreateDate),
                        Flag = c.Flag.ToString(),
                        UserID = Security.Encrypt(c.UserID),
                        uFlag = u.IntFlag.ToString()
                    }).ToList();
            }
            return paging;
        }

        /// <summary>
        /// 根据用户的企业信息
        /// </summary>
        /// <returns></returns>
        public VmEnterprise GetCurrentEnterprise(FaoB2BEntities context)
        {
            var user = baseUserService.CurrentUser(context.BaseUsers);
            if (user == null)
            {
                return null;
            }
            var curEnter = context.Enterprises.Where(p => p.IntCreateUserID == user.IntUserID).FirstOrDefault();
            if (curEnter == null)
            {
                return null;
            }
            return new VmEnterprise
            {
                EntID = curEnter.IntEnterpriseID.ToString(),
                EntName = curEnter.VarEnterpriseName,
                EntPhone = curEnter.VarCustomerPhone,
                ContactUserPhone = curEnter.VarContactPhone
            };
        }


        /// <summary>
        /// 获取当前企业信息
        /// </summary>
        /// <returns></returns>
        public VMEntInfo GetCurrentEntInfo()
        {
            VMEntInfo vm = new VMEntInfo();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var Area = baseAreaService.Many(context.BaseAreas, null);
                    var Industry = baseIndustryService.Many(context.BaseIndustries, null);

                    var entity = (from e in context.Enterprises
                                  join a in Area on e.IntAreaID equals a.IntAreaID
                                  join i in Industry on e.IntIndustryID equals i.IntIndustryID
                                  where e.IntCreateUserID == user.IntUserID
                                  select new VMEntInfo
                                  {
                                      Address = e.VarAddress,
                                      AreaID = e.IntAreaID,
                                      AreaName = a.VarAreaName,
                                      ContactPhone = e.VarContactPhone,
                                      CustomerPhone = e.VarCustomerPhone,
                                      EnterpriseBrief = e.VarEnterpriseBrief,
                                      EnterpriseDescrip = e.VarEnterpriseDescrip,
                                      EnterpriseID = e.IntEnterpriseID,
                                      EnterpriseName = e.VarEnterpriseName,
                                      EnterpriseScale = e.VarEnterpriseScale,
                                      EnterpriseTypeID = e.IntEnterpriseTypeID,
                                      FixNum = e.VarFixNum,
                                      IndustryID = e.IntIndustryID,
                                      IndustryName = i.VarIndustryName,
                                      WebSiteURL = e.VarWebSiteURL,
                                      Zipcode = e.VarZipcode,
                                      Flag=e.IntFlag
                                  }).ToList();

                    if (entity.Count > 0)
                    {
                        vm = entity.FirstOrDefault();
                    }
                }
            }
            return vm;
        }


        /// <summary>
        /// 修改企业资料
        /// </summary>
        /// <param name="vmModel"></param>
        /// <returns></returns>
        public string UpdateEntInfo(VMEntInfo vm)
        {
            string msg=string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);

                if (user == null)
                {
                    msg = "用户未登陆";
                }
                else
                {
                    Enterprise model = new Enterprise();

                    if (vm.EnterpriseID == 0)
                    {
                        model.IntFlag = 0;
                        model.IntGroupID = 1;
                        model.DteCreate = System.DateTime.Now;
                        model.VarEnterprisedCodeNum = "";

                        model.IntAreaID = vm.AreaID;
                        model.IntIndustryID = vm.IndustryID;
                        model.IntEnterpriseTypeID = vm.EnterpriseTypeID;
                        model.IntCreateUserID = user.IntUserID;
                        model.VarZipcode = vm.Zipcode;
                        model.VarWebSiteURL = vm.WebSiteURL;
                        model.VarFixNum = vm.FixNum;
                        model.VarAddress = vm.Address;
                        model.VarContactPhone = vm.ContactPhone;
                        model.VarCustomerPhone = vm.CustomerPhone;
                        model.VarEnterpriseBrief = vm.EnterpriseBrief;
                        model.VarEnterpriseDescrip = vm.EnterpriseDescrip;
                        model.VarEnterpriseName = vm.EnterpriseName;
                        model.VarEnterpriseScale = vm.EnterpriseScale;

                        context.Enterprises.Add(model);
                    }
                    else
                    {
                        model = context.Enterprises.Find(vm.EnterpriseID);

                        model.IntAreaID = vm.AreaID;
                        model.IntIndustryID = vm.IndustryID;
                        model.IntEnterpriseID = vm.EnterpriseID;
                        model.IntEnterpriseTypeID = vm.EnterpriseTypeID;
                        model.IntCreateUserID = user.IntUserID;
                        model.VarZipcode = vm.Zipcode;
                        model.VarWebSiteURL = vm.WebSiteURL;
                        model.VarFixNum = vm.FixNum;
                        model.VarAddress = vm.Address;
                        model.VarContactPhone = vm.ContactPhone;
                        model.VarCustomerPhone = vm.CustomerPhone;
                        model.VarEnterpriseBrief = vm.EnterpriseBrief;
                        model.VarEnterpriseDescrip = vm.EnterpriseDescrip;
                        model.VarEnterpriseName = vm.EnterpriseName;
                        model.VarEnterpriseScale = vm.EnterpriseScale;
                    };

                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "保存失败";
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 冻结企业
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        public string FreezeEnt(int eid)
        {
            int flag = -1;
            using (var context = new FaoB2BEntities())
            {
                Enterprise ent = context.Enterprises.Find(eid);

                if (ent != null)
                {
                    BaseUser user = baseUserService.One(context.BaseUsers, new BaseUser() { IntUserID = ent.IntCreateUserID });
                    if (user != null)
                    {
                        bool isFreeze = ent.IntFlag ==0;

                        user.IntFlag = isFreeze ? 2 : 3;
                        ent.IntFlag = isFreeze ? 1 : 0;
                    }
                }

                flag = context.SaveChanges();
            }

            if (flag >= 0)
            {
                return "1";
            }
            return "0";
        }


        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(Enterprise entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(Enterprise entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(Enterprise entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public Enterprise One(IQueryable<Enterprise> query, Enterprise entity)
        {
            var ent = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntEnterpriseID != 0)
                {
                    ent = ent.Where(e => e.IntEnterpriseID == entity.IntEnterpriseID);
                }
            }

            return ent.FirstOrDefault();
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<Enterprise> Many(IQueryable<Enterprise> query, Enterprise entity)
        {
            var entitys = query.Select(e => e);

            if (entity != null)
            {
                if (!string.IsNullOrEmpty(entity.VarEnterpriseName))
                {
                    entitys = entitys.Where(e => e.VarEnterpriseName.Contains(entity.VarEnterpriseName));
                }

                if (entity.IntFlag != -1)
                {
                    entitys = entitys.Where(e => e.IntFlag != 0);
                }
            }
            else
            {
                entitys = entitys.Where(e => e.IntFlag != 0);
            }


            return entitys;
        }

        #endregion




    }
}
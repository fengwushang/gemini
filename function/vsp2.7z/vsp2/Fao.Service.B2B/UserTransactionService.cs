﻿using Fao.Data;
using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;
using System.Configuration;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// UserTransaction服务实现-Power by CodeGG
    /// </summary>
    public class UserTransactionService : Entity<UserTransaction>, IUserTransactionService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmUserTransaction查询模型，返回VmUserTransaction视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmUserTransaction> GetUserTransactions(SmUserTransaction searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmUserTransaction视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmUserTransaction GetUserTransactionByID(string id)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 获取当前用户交易账户信息
        /// </summary>
        /// <returns></returns>
        public VmUserTransaction GetCurrentUserTransaction()
        {
            VmUserTransaction vm = new VmUserTransaction();
            using (FaoB2BEntities context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user == null)
                {
                }
                else
                {
                    var list = context.UserTransactions.Select(t => t).Where(t => t.IntUserID == user.IntUserID).ToList();
                    if (list.Count > 0)
                    {
                        UserTransaction ut = list.FirstOrDefault();
                        vm = new VmUserTransaction()
                        {
                            AccountBalance = ut.DecAccountBalance,
                            PPCBalance = ut.DecPPCBalance,
                            PhoneMsgSum = ut.IntPhoneMsgSum,
                            UserID = ut.IntUserID,
                            UserTransaction = ut.IntUserTransaction,
                            IntSMSSrcID = ut.IntSMSSrcID,
                            PaymentPwd = ut.VarPaymentPwd
                        };
                    }
                }
            }
            return vm;
        }

        /// <summary>
        /// 获取当前用户交易账户信息
        /// </summary>
        /// <returns></returns>
        public VmUserTransaction GetCurrentUserTransaction(FaoB2BEntities context)
        {
            VmUserTransaction vm = new VmUserTransaction();
            var user = baseUserService.CurrentUser(context.BaseUsers);
            if (user != null)
            {
                var list = context.UserTransactions.Select(t => t).Where(t => t.IntUserID == user.IntUserID).ToList();

                if (list.Count > 0)
                {
                    UserTransaction ut = list.FirstOrDefault();
                    vm = new VmUserTransaction()
                    {
                        AccountBalance = ut.DecAccountBalance,
                        PPCBalance = ut.DecPPCBalance,
                        PhoneMsgSum = ut.IntPhoneMsgSum,
                        UserID = ut.IntUserID,
                        UserTransaction = ut.IntUserTransaction,
                        IntSMSSrcID = ut.IntSMSSrcID,
                        PaymentPwd = ut.VarPaymentPwd
                    };
                }
            }
            return vm;
        }

        /// <summary>
        /// 更改用户发短信条数
        /// </summary>
        /// <param name="sendCount"></param>
        /// <returns></returns>
        public string updateMsgCount(int sendCount)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user == null)
                {
                    msg = "用户未登录";
                }
                else
                {
                    var list = Many(context.UserTransactions, new UserTransaction() { IntUserID = user.IntUserID }).Select(t => t).ToList();

                    UserTransaction ut = new UserTransaction();
                    if (list.Count > 0)
                    {
                        ut = list.FirstOrDefault();
                        ut.IntPhoneMsgSum -= sendCount;
                    }

                    int flag = context.SaveChanges();
                    if (flag > 0)
                        msg = "1";
                    else
                        msg = "短信数量修改失败";
                }
            }
            return msg;
        }

        /// <summary>
        /// 购买短信 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="buyCount"></param>
        /// <param name="smsValue"></param>
        /// <returns></returns>
        public string BuyMsg(FaoB2BEntities context, int buyCount, decimal smsValue, int SMSInterval)
        {
            var user = baseUserService.CurrentUser();
            if (user == null)
                return "用户未登录";

            var list = Many(context.UserTransactions, new UserTransaction() { IntUserID = user.IntUserID }).Select(t => t).ToList();
            UserTransaction ut = new UserTransaction();
            if (list.Count > 0)
            {
                ut = list.FirstOrDefault();
                ut.DecAccountBalance -= smsValue;
                ut.IntPhoneMsgSum += buyCount;
                if (ut.IntSMSSrcID <= 0)   //第一次购买短信时，给短信号段、短信子号
                {
                    //在 SMSInterval 下分配短信子号 
                    int srcID = 10; //1到9 保留
                    var alist = Many(context.UserTransactions, new UserTransaction() { IntSMSInterval = SMSInterval }).Select(t => t).OrderByDescending(t => t.IntSMSSrcID).ToList();
                    if (alist.Count > 0)
                    {
                        UserTransaction uc = new UserTransaction();
                        uc = alist.FirstOrDefault();

                        if (uc.IntSMSInterval>SMSInterval &&  uc.IntSMSSrcID.ToString().Substring(0, SMSInterval.ToString().Length) == SMSInterval.ToString())
                        {
                            uc.IntSMSSrcID = Utils.ToInt(uc.IntSMSSrcID.ToString().Substring(SMSInterval.ToString().Length));
                        }

                        if (uc.IntSMSSrcID + 1 > 999999)
                        {
                            return "该短信大号段已经分配完毕，请联系客服！";
                        }
                        else
                            srcID = uc.IntSMSSrcID + 1;
                    }

                    ut.IntSMSInterval = SMSInterval;
                    ut.IntSMSSrcID = Utils.ToInt(SMSInterval.ToString() + srcID.ToString());
                }
            }
            else
                return "购买短信失败";

            int flag = context.SaveChanges();
            if (flag > 0)
                return "1";
            else
                return "购买短信失败";
        }


        /// <summary>
        /// 账户充值
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="money"></param>
        /// <returns></returns>
        public string ReCharge(int userID, decimal money)
        {
            string msg = null;
            using (var context = new FaoB2BEntities())
            {
                var list = Many(context.UserTransactions, new UserTransaction() { IntUserID = userID }).Select(t => t).ToList();
                UserTransaction ut = new UserTransaction();
                if (list.Count > 0)
                {
                    ut = list.FirstOrDefault();
                    ut.DecAccountBalance += money;
                }
                else
                {
                    var user = context.BaseUsers.Find(userID);
                    ut = new UserTransaction()
                    {
                        IntUserID = userID,
                        IntFlag = 1,
                        IntPhoneMsgSum = 0,
                        DecAccountBalance = money,
                        DecPPCBalance = 0,
                        VarPaymentPwd = user.VarPWD
                    };
                    if (ut != null)
                    {
                        if (ut.IntSMSInterval == null)
                        {
                            ut.IntSMSInterval = Utils.ToInt(ConfigurationManager.AppSettings["SMSInterval"]);
                        }
                        context.UserTransactions.Add(ut);
                    }
                }
                int flag = context.SaveChanges();

                if (flag > 0)
                {
                    msg = "充值成功";
                }
                else
                {
                    msg = "充值失败";
                }
            }
            return msg;
        }



        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="email"></param>
        /// <param name="NewPassword"></param>
        /// <param name=""></param>
        /// <returns></returns>
        public int ChangPayPWD(string Email, string NewPassword, string OldPassword)
        {
            int flag = -2;
            using (var context = new FaoB2BEntities())
            {
                BaseUser user = null;
                string encryptpassword = Security.MD5(NewPassword);

                user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    UserTransaction ut = new UserTransaction();
                    var list = context.UserTransactions.Where(u => u.IntUserID == user.IntUserID).ToList();
                    if (list.Count == 0)
                    {
                        ut = new UserTransaction()
                        {
                            IntUserID = user.IntUserID,
                            IntFlag = 1,
                            IntPhoneMsgSum = 0,
                            DecAccountBalance = 0,
                            DecPPCBalance = 0,
                            VarPaymentPwd = encryptpassword
                        };

                        ut.IntSMSInterval = Utils.ToInt(ConfigurationManager.AppSettings["SMSInterval"]);

                        context.UserTransactions.Add(ut);

                    }
                    else
                    {
                        ut = list[0];
                        ut.VarPaymentPwd = encryptpassword;

                    }
                    flag = context.SaveChanges();


                }
            }
            return flag;
        }

        /// <summary>
        /// 充值PPC账号
        /// </summary>
        /// <param name="PWD"></param>
        /// <param name="Rechange"></param>
        /// <returns></returns>
        public string PPCRechange(string PWD, decimal Rechange)
        {
            string msg = "";
            using (var context = new FaoB2BEntities())
            {

                var ut = GetCurrentUserTransaction(context);
                var md5 = Security.MD5(PWD);
                if (ut.PaymentPwd != md5)
                {
                    msg = "支付密码错误";
                }
                else
                {
                    var user = baseUserService.CurrentUser(context.BaseUsers);
                    var list = Many(context.UserTransactions, new UserTransaction() { IntUserID = user.IntUserID }).Select(t => t).ToList();
                    UserTransaction uc = new UserTransaction();
                    uc = list.FirstOrDefault();
                    uc.DecAccountBalance -= Rechange;
                    uc.DecPPCBalance += Rechange;
                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        msg = "1";
                    }
                    else
                    {
                        msg = "充值失败";
                    }
                }
            }
            return msg;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(UserTransaction entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(UserTransaction entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(UserTransaction entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public UserTransaction One(IQueryable<UserTransaction> query, UserTransaction entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<UserTransaction> Many(IQueryable<UserTransaction> query, UserTransaction entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntUserID > 0)
                {
                    entities = entities.Where(e => e.IntUserID == entity.IntUserID);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
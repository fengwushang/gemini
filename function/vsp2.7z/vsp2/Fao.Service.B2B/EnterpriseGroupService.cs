﻿using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Fao.Service.B2B
{

    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// EnterpriseGroup服务实现-Power by CodeGG
    /// </summary>
    public class EnterpriseGroupService : Entity<EnterpriseGroup>, IEnterpriseGroupService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmEnterpriseGroup查询模型，返回VmEnterpriseGroup视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmEnterpriseGroup> GetEnterpriseGroups(SmEnterpriseGroup searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmEnterpriseGroup视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmEnterpriseGroup GetEnterpriseGroupByID(string id)
        {
            throw new Exception("没有实现");
        }

        #endregion    

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(EnterpriseGroup entity)
        {
            throw new Exception("没有实现");
        }
         
        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(EnterpriseGroup entity)
        {
            throw new Exception("没有实现");
        }
          
        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(EnterpriseGroup entity)
        {
            throw new Exception("没有实现");
        }
        
        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public EnterpriseGroup One(IQueryable<EnterpriseGroup> query, EnterpriseGroup entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<EnterpriseGroup> Many(IQueryable<EnterpriseGroup> query, EnterpriseGroup entity)
        {
            throw new Exception("没有实现");
        }

        #endregion    

    }
}
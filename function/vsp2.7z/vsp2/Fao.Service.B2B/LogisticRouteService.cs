﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;

namespace Fao.Service.B2B
{

    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticRoute服务实现-Power by CodeGG
    /// </summary>
    public class LogisticRouteService : Entity<LogisticRoute>, ILogisticRouteService
    {

        #region 业务接口引用

        IEnterpriseService enterpriseService = new EnterpriseService();
        IBaseUserService baseUserService = new BaseUserService();
        IBaseAreaService baseAreaService = new BaseAreaService();
        IBaseDictionaryService baseDictionaryService = new BaseDictionaryService();
        IAttachmentService attachmentService = new AttachmentService();
        ILogisticVehicleService logisticVehicleService = new LogisticVehicleService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmLogisticRoute查询模型，返回VmLogisticRoute视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmLogisticRoute> GetLogisticRoutes(SmLogisticRoute searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmLogisticRoute视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmLogisticRoute GetLogisticRouteByID(string id)
        {
            VmLogisticRoute Cargo = new VmLogisticRoute();
            int rid = Utils.ToInt(Security.Decrypt(id));
            var list = GetLogisticRouteWithPage(new SmLogisticRoute() { ID = rid }, 1, 1);
            if (list.rows.Count > 0)
            {
                Cargo = list.rows[0];
            }
            Cargo.Vehicle = logisticVehicleService.GetLogisticVehicleByID(Security.Encrypt(Cargo.VehicleID));
            return Cargo;
        }

        /// <summary>
        /// 获取分页数据 物流专线
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        public LogisticRoutePaging GetLogisticRouteWithPage(SmLogisticRoute searchModel, int pageIndex, int pageCount)
        {
            LogisticRoutePaging page = new LogisticRoutePaging();

            #region 原代码  出不了数据，无用
            //using (var context = new FaoB2BEntities())
            //{
            //    var Route = Many(context.LogisticRoutes, null).Where(c => c.IntFlag == 3);
            //    if (searchModel != null)
            //    {
            //        if (searchModel.ID > 0)
            //        {
            //            Route = Route.Where(c => c.IntRouteID == searchModel.ID);
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.KeyWord))
            //        {
            //            Route = Route.Where(c => c.VarDetails.Contains(searchModel.KeyWord));
            //        }
            //        if (searchModel.AreaIDStart > 0)
            //        {
            //            var area = baseAreaService.Many(context.BaseAreas, null).Where(a => a.IntAreaID == searchModel.AreaIDStart
            //                        || a.IntAreaParentID == searchModel.AreaIDStart).Select(a => a.IntAreaID).ToArray();
            //            Route = Route.Where(c => area.Contains(c.IntAreaIDStart));
            //        }
            //        if (searchModel.AreaIDEnd > 0)
            //        {
            //            var area = baseAreaService.Many(context.BaseAreas, null).Where(a => a.IntAreaID == searchModel.AreaIDEnd
            //                       || a.IntAreaParentID == searchModel.AreaIDEnd).Select(a => a.IntAreaID).ToArray();
            //            Route = Route.Where(c => area.Contains(c.IntAreaIDEnd));
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.DteRefreshStart))
            //        {
            //            DateTime dteRefreshStart = new DateTime();
            //            if (DateTime.TryParse(searchModel.DteRefreshStart, out dteRefreshStart))
            //            {
            //                Route = Route.Where(c => c.DteRefresh >= dteRefreshStart);
            //            }
            //        }
            //        if (!string.IsNullOrEmpty(searchModel.DteRefreshEnd))
            //        {
            //            DateTime dteRefreshEnd = new DateTime();
            //            if (DateTime.TryParse(searchModel.DteRefreshEnd, out dteRefreshEnd))
            //            {
            //                Route = Route.Where(c => c.DteRefresh <= dteRefreshEnd);
            //            }
            //        }
            //    }

            //    var user = baseUserService.Many(context.BaseUsers, null);
            //    var ent = enterpriseService.Many(context.Enterprises, null);
            //    var dict = baseDictionaryService.Many(context.BaseDictionaries, null);
            //    var vehicle = logisticVehicleService.Many(context.LogisticVehicles, null);

            //    var entity = from c in Route
            //                 join e in ent on c.IntEnterpriseID equals e.IntEnterpriseID
            //                 join u in user on c.InCreatetUserID equals u.IntUserID
            //                 join v in vehicle on c.IntVehicleID equals v.IntVehicleID
            //                 join vType in dict on v.IntVehicleType equals vType.IntItemID
            //                 join ask in dict on c.IntLoadAsk equals ask.IntItemID
            //                 join unit in dict on c.IntCargoFreightUnit equals unit.IntItemID
            //                 select new
            //                 {
            //                     AreaIDEnd = c.IntAreaIDEnd,
            //                     AreaIDStart = c.IntAreaIDStart,
            //                     Ask = ask.VarItemName,
            //                     ContactStart = c.VarContactStart,
            //                     ContactEnd = c.VarContactEnd,
            //                     ContactPhoneEnd = c.VarContactPhoneEnd,
            //                     ContactPhoneStart = c.VarContactPhoneStart,
            //                     CargoFreight = c.DecCargoFreight,
            //                     FreightUnit = c.IntCargoFreightUnit,
            //                     Unit = unit.VarItemName,
            //                     Flag = c.IntFlag,
            //                     IsBF = c.IntIsBF,
            //                     LoadAsk = c.IntLoadAsk,
            //                     RouteID = c.IntRouteID,
            //                     vType = vType.VarItemName,
            //                     WayStop = c.VarWayStop,
            //                     Details = c.VarDetails,
            //                     BrowserCount = c.IntBrowserCount,
            //                     DteCreate = c.DteCreate,
            //                     DteRefresh = c.DteRefresh,
            //                     DteValid = c.DteValid,
            //                     EntID = c.IntEnterpriseID,
            //                     EntName = e.VarEnterpriseName,
            //                     UserID = c.InCreatetUserID,
            //                     UserName = u.VarRealName,
            //                     VehicleID = c.IntVehicleID,
            //                     Vehicle = v
            //                 };
            //    page.total = entity.Count();
            //    var list = entity.OrderByDescending(c => c.DteRefresh).Skip((pageIndex - 1) * pageCount).Take(pageCount).ToList();

            //    var VehicleSourceIDs = list.Select(e => e.RouteID).ToList();

            //    var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 5)
            //            , VehicleSourceIDs)
            //            .Select(e => new
            //            {
            //                e.IntBelongTablePrikeyID,
            //                e.VarFilePath
            //            }).ToList();

            //    var areaStartIDs = list.Select(e => e.AreaIDStart).ToList();
            //    var areaEndIDs = list.Select(e => e.AreaIDEnd).ToList();
            //    var areaStartList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaStartIDs);
            //    var areaEndList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaEndIDs);


            //    var rows = (
            //        from c in list
            //        join a1 in areaStartList on c.AreaIDStart equals a1.AreaID
            //        join a2 in areaEndList on c.AreaIDEnd equals a2.AreaID
            //        join a in attList on c.RouteID equals a.IntBelongTablePrikeyID
            //        select new VmLogisticRoute
            //        {
            //            AreaIDEnd = c.AreaIDEnd,
            //            AreaIDStart = c.AreaIDStart,
            //            Ask = c.Ask,
            //            ContactStart = c.ContactStart,
            //            ContactEnd = c.ContactEnd,
            //            ContactPhoneEnd = c.ContactPhoneEnd,
            //            ContactPhoneStart = c.ContactPhoneStart,
            //            CargoFreight = c.CargoFreight,
            //            FreightUnit = c.FreightUnit,
            //            Type = c.vType,
            //            Unit = c.Unit,
            //            Flag = c.Flag,
            //            IsBF = c.IsBF,
            //            LoadAsk = c.LoadAsk,
            //            RouteID = Security.Encrypt(c.RouteID),
            //            WayStop = c.WayStop,
            //            Details = c.Details,
            //            BrowserCount = c.BrowserCount,
            //            DteCreate = c.DteCreate.ToString("yyyy-MM-dd"),
            //            DteRefresh = c.DteRefresh.ToString("yyyy-MM-dd"),
            //            DteValid = c.DteValid.Year == DateTime.MaxValue.Year ? "永久有效" : Common.Utils.GetDateFormate(c.DteValid),
            //            EndArea = a1.Name,
            //            EntID = Security.Encrypt(c.EntID),
            //            EntName = c.EntName,
            //            StartArea = a2.Name,
            //            UserID = c.UserID,
            //            UserName = c.UserName,
            //            VehicleID = c.VehicleID,

            //            ImgUrl = a.VarFilePath,
            //            Vehicle = new VmLogisticVehicle()
            //            {
            //                LicenseNum = c.Vehicle.VarLicenseNum,
            //                VehicleNumber = c.Vehicle.VarVehicleNum,
            //                Type = c.vType,
            //                VehicleSize = c.Vehicle.VaVehicleSize,
            //                MaxLoad = c.Vehicle.VarMaxLoad,
            //                MaxVolume = c.Vehicle.VarMaxVolume,
            //                IsGPS = c.Vehicle.IntIsGPS,
            //                IsInsurance = c.Vehicle.IntIsInsurance,
            //                IsTemp = c.Vehicle.IntIsTemp
            //            }
            //        }).ToList();

            //    page.rows = rows;

            //}
            #endregion

            #region 新代码
            using (var context = new FaoB2BEntities())
            {
                IEnumerable<VmLogisticRoute> entities = null;
                //根据ID获取该条记录
                if (searchModel.ID > 0)
                {
                    entities = context.Database.SqlQuery<VmLogisticRoute>("ProcGetSearchRouteByID @p0", searchModel.ID);
                    page.total = entities.Count();
                }
                else
                {
                    //分页数据
                    entities = context.Database.SqlQuery<VmLogisticRoute>(
                       "ProcGetSearchRoute @p0,@p1,@p2,@p3,@p4,@p5,@p6,@p7"
                       , searchModel.AreaIDStart
                       , searchModel.AreaIDEnd
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshStart) ? string.Empty : searchModel.DteRefreshStart
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshEnd) ? string.Empty : searchModel.DteRefreshEnd
                       , 9
                       , string.IsNullOrWhiteSpace(searchModel.KeyWord) ? string.Empty : searchModel.KeyWord
                       , pageIndex
                       , pageCount
                       );

                    page.total = context.Database.SqlQuery<int>(
                       "ProcGetSearchRouteCount @p0,@p1,@p2,@p3,@p4,@p5"
                       , searchModel.AreaIDStart
                       , searchModel.AreaIDEnd
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshStart) ? string.Empty : searchModel.DteRefreshStart
                       , string.IsNullOrWhiteSpace(searchModel.DteRefreshEnd) ? string.Empty : searchModel.DteRefreshEnd
                       , 9
                       , string.IsNullOrWhiteSpace(searchModel.KeyWord) ? string.Empty : searchModel.KeyWord
                       ).FirstOrDefault();
                }

                var list = entities.ToList().Select(e => new
                {
                    AreaIDEnd = Utils.ToInt(e.AreaIDEnd.ToString()),
                    AreaIDStart = Utils.ToInt(e.AreaIDStart.ToString()),
                    Ask = e.Ask,

                    ContactStart = e.ContactStart,
                    ContactEnd = e.ContactEnd,
                    ContactPhoneEnd = e.ContactPhoneEnd,
                    ContactPhoneStart = e.ContactPhoneStart,

                    CargoFreight = e.CargoFreight,
                    FreightUnit = e.FreightUnit,
                    Unit = e.Unit,
                    gType = e.GoodsType,
                    Flag = e.Flag,
                    IsBF = e.IsBF,
                    LoadAsk = e.LoadAsk,

                    RouteID = Utils.ToInt(e.RouteID),
                    vType = e.Type,
                    WayStop = e.WayStop,
                    Details = e.Details,
                    BrowserCount = e.BrowserCount,
                    DteCreate = e.DteCreate,
                    DteRefresh = e.DteRefresh,
                    DteValid = e.DteValid,

                    EntID = e.EntID,
                    EntName = e.EntName,
                    UserID = e.UserID,
                    UserName = e.UserName,
                    VehicleID = e.VehicleID,
                    Vehicle = e.Vehicle,

                    PPCID = e.PPCID,
                    EncriptID = Security.Encrypt(e.EncriptID),

                    EndArea = e.EndArea,
                    StartArea = e.StartArea,
                    ValidDate = e.ValidDate,
                    Sms = e.Sms,
                    VehicleType = e.VehicleType,
                    MaxLoad = e.MaxLoad,

                }).ToList();

                //获取分页数据主键集合
                var RouteIDs = list.Select(e => e.RouteID);

                //获取附件集合
                var attList = attachmentService.GetMainAttachments(context.Attachments.Where(a => a.IntBelongTable == 5)
                      , RouteIDs)
                      .Select(e => new
                      {
                          e.IntBelongTablePrikeyID,
                          e.VarFilePath
                      }).ToList();


                var areaStartIDs = list.Select(e => e.AreaIDStart).ToList();
                var areaEndIDs = list.Select(e => e.AreaIDEnd).ToList();

                var areaStartList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaStartIDs);
                var areaEndList = baseAreaService.GetAreasWithParentName(context.BaseAreas, areaEndIDs);

                var rows = (from c in list
                            join a1 in areaStartList on c.AreaIDStart equals a1.AreaID
                            join a2 in areaEndList on c.AreaIDEnd equals a2.AreaID
                            join a in attList on c.RouteID equals a.IntBelongTablePrikeyID
                            select new VmLogisticRoute
                            {
                                AreaIDEnd = c.AreaIDEnd,
                                AreaIDStart = c.AreaIDStart,
                                Ask = c.Ask,
                                ContactStart = c.ContactStart,
                                ContactEnd = c.ContactEnd,
                                ContactPhoneEnd = c.ContactPhoneEnd,
                                ContactPhoneStart = c.ContactPhoneStart,
                                CargoFreight = c.CargoFreight,
                                FreightUnit = c.FreightUnit,
                                Type = "",
                                Unit = c.Unit,
                                Flag = c.Flag,
                                IsBF = c.IsBF,
                                LoadAsk = c.LoadAsk,
                                RouteID = Security.Encrypt(c.RouteID),
                                WayStop = c.WayStop,
                                Details = c.Details,
                                BrowserCount = c.BrowserCount,
                                DteCreate = c.DteCreate,
                                DteRefresh = c.DteRefresh,
                                DteValid = Convert.ToDateTime(c.DteValid).Year == DateTime.MaxValue.Year ? "永久有效" : c.DteValid,
                                EndArea = a2.Name,
                                EntID = Security.Encrypt(c.EntID),
                                EncriptID = c.EncriptID,
                                EntName = c.EntName,
                                StartArea = a1.Name,
                                UserID = c.UserID,
                                UserName = c.UserName,
                                VehicleID = c.VehicleID,
                                ImgUrl = a.VarFilePath,
                                PPCID = c.PPCID,
                                Sms = Security.Encrypt(c.Sms),
                                VehicleType = c.VehicleType,
                                MaxLoad = c.MaxLoad,

                            }).ToList();
                page.rows = rows;
            }
            #endregion

            return page;
        }

        /// <summary>
        /// 添加物流专线信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddLogisticRouteInfo(VmLogisticRoute model, VmB2BInfoPicture picture)
        {
            string str = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                LogisticRoute entity = new LogisticRoute();
                var enterprise = enterpriseService.GetCurrentEnterprise(context);
                if (user == null)
                {
                    str = "用户未登陆";
                }
                else
                {
                    string strID = string.Empty;
                    int id = 0;
                    if (enterprise != null)
                    {
                        strID = Security.Decrypt(enterprise.EntID);
                        strID = strID == "" ? enterprise.EntID : strID;
                        int.TryParse(strID, out id);
                    }
                    entity.InCreatetUserID = user.IntUserID;
                    entity.IntEnterpriseID = id;
                    entity.DteCreate = DateTime.Now;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.DteRefresh = DateTime.Now;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    entity.IntBrowserCount = 0;
                    entity.VarDetails = model.Details == null ? "" : model.Details;
                    entity.IntAreaIDStart = model.AreaIDStart ?? 0;
                    entity.IntAreaIDEnd = model.AreaIDEnd ?? 0;
                    entity.DecCargoFreight = model.CargoFreight ?? 0;
                    entity.IntCargoFreightUnit = model.FreightUnit ?? 0;
                    entity.VarContactStart = model.ContactStart;
                    entity.VarContactPhoneStart = model.ContactPhoneStart;
                    entity.VarContactEnd = model.ContactEnd != null ? model.ContactEnd : "";
                    entity.VarContactPhoneEnd = model.ContactPhoneEnd != null ? model.ContactPhoneEnd : "";
                    entity.IntIsBF = model.IsBF;
                    entity.VarWayStop = model.WayStop != null ? model.WayStop : "";
                    entity.IntLoadAsk = model.LoadAsk ?? 0;
                    //entity.VarGoodsType = model.Type != null ? model.Type : "";
                    entity.IntVehicleID = model.VehicleID;
                    entity.VarGoodsType = model.GoodsType.ToString();
                    context.LogisticRoutes.Add(entity);
                    int flag = context.SaveChanges();
                    SaveImage(context, entity.IntRouteID, picture);
                    if (flag >= 0)
                    {
                        str = "1";
                    }
                    else
                    {
                        str = "保存失败";
                    }

                }
            }
            return str;
        }

        /// <summary>
        /// 修改物流专线信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateLogisticRouteInfo(VmLogisticRoute model, VmB2BInfoPicture picture = null)
        {
            string str = null;
            using (var context = new FaoB2BEntities())
            {
                string strID = Common.Security.Decrypt(model.EncriptID);
                int id;
                if (!int.TryParse(strID, out id))
                {
                    str = "未提到该记录";
                }
                else
                {
                    var entity = context.LogisticRoutes.Find(id);
                    if (entity != null)
                    {
                        entity.IntFlag = model.Flag ?? 1;
                        entity.DteRefresh = model.RefreshDate ?? DateTime.Now;
                        entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                        entity.VarDetails = model.Details == null ? "" : model.Details;
                        entity.IntAreaIDStart = model.AreaIDStart ?? 0;
                        entity.IntAreaIDEnd = model.AreaIDEnd ?? 0;
                        entity.DecCargoFreight = model.CargoFreight ?? 0M;
                        entity.IntCargoFreightUnit = model.FreightUnit ?? 0;
                        entity.VarContactStart = model.ContactStart;
                        entity.VarContactPhoneStart = model.ContactPhoneStart;
                        entity.VarContactEnd = model.ContactEnd != null ? model.ContactEnd : "";
                        entity.VarContactPhoneEnd = model.ContactPhoneEnd != null ? model.ContactPhoneEnd : "";
                        entity.IntIsBF = model.IsBF;
                        entity.VarWayStop = model.WayStop != null ? model.WayStop : "";
                        entity.IntLoadAsk = model.LoadAsk ?? 0;
                        //entity.VarGoodsType = model.Type != null ? model.Type : "";
                        entity.VarGoodsType = model.GoodsType.ToString() != null ? model.GoodsType.ToString() : "";
                        entity.IntVehicleID = model.VehicleID;
                    }
                    //删除所有推广记录
                    IQueryable<PPC> ppcs = context.PPCs.Where(e => e.IntTablePrimkeyID == entity.IntRouteID && e.IntFlag == 1);
                    foreach (PPC ppc in ppcs)
                    {
                        ppc.IntFlag = 0;
                    }
                    int flag = context.SaveChanges();
                    if (picture != null)
                    {
                        SaveImage(context, entity.IntRouteID, picture);

                        //删除 热词推广 信息
                        //--标识位，热词类型；1供应，2求购，3招商，5代理，4合作，6货源，7库源，8,车源，9物流专线
                        //PPCService pPCService = new PPCService();
                        //pPCService.DeletePPC(9, entity.IntRouteID);
                    }
                    if (flag >= 0)
                    {
                        str = "1";
                    }
                    else
                    {
                        str = "保存失败";
                    }
                }
            }
            return str;
        }

        /// <summary>
        /// 根据ID得到物流专线信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmLogisticRoute GetLogisticRouteInfoBy(string encriptID)
        {
            VmLogisticRoute vm = null;
            using (var context = new FaoB2BEntities())
            {
                string strID = Security.Decrypt(encriptID);
                int id = 0;
                int.TryParse(strID, out id);
                var entity = context.LogisticRoutes.Find(id);
                var attList = attachmentService.GetAttachmentsByTablePK(context, id, 1);
                if (entity != null)
                {
                    var startArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDStart }).FirstOrDefault();
                    var endArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDEnd }).FirstOrDefault();
                    if (string.IsNullOrEmpty(entity.VarGoodsType))
                        entity.VarGoodsType = "0";
                    var goodsType = baseDictionaryService.GetBaseDictionaryByID(context,int.Parse(entity.VarGoodsType));
                    var unit = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoFreightUnit);
                    var loadAsk = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntLoadAsk);
                    var vehicle = logisticVehicleService.GetLogisticVehicleByID(context, Security.Encrypt(entity.IntVehicleID));
                    vm = new VmLogisticRoute()
                    {
                        Unit = unit != null ? unit.ItemName : "",
                        Ask = loadAsk.ItemName,
                        LoadAsk = entity.IntLoadAsk,
                        Type = goodsType != null ? goodsType.ItemName : "",
                        //Type = entity.VarGoodsType,
                        EncriptID = Security.Encrypt(id),
                        AreaIDStart = entity.IntAreaIDStart,
                        StartArea = startArea != null ? startArea.Name : "",
                        AreaIDEnd = entity.IntAreaIDEnd,
                        EndArea = endArea != null ? endArea.Name : "",
                        ContactPhoneStart = entity.VarContactPhoneStart,
                        ContactStart = entity.VarContactStart,
                        ContactEnd = entity.VarContactEnd,
                        ContactPhoneEnd = entity.VarContactPhoneEnd,
                        Details = entity.VarDetails,
                        ValidDate = entity.DteValid,
                        ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                        ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                        Flag = entity.IntFlag,
                        FreightUnit = entity.IntCargoFreightUnit,
                        VehicleID = entity.IntVehicleID,
                        LicenseNum = vehicle != null ? vehicle.LicenseNum : "",
                        IsBF = entity.IntIsBF,
                        CargoFreight = decimal.Round(entity.DecCargoFreight, 2),
                        WayStop = entity.VarWayStop,
                        DteValid = Utils.GetDateTimeFormate(entity.DteValid)
                    };
                    vm.GoodsType = goodsType != null ?goodsType.ItemID:0;
                }
            }
            return vm;
        }

        /// <summary>
        /// 根据ID得到物流专线信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public VmLogisticRoute GetLogisticRouteInfoBy(FaoB2BEntities context, string encriptID)
        {
            VmLogisticRoute vm = null;

            string strID = Security.Decrypt(encriptID);
            int id = 0;
            int.TryParse(strID, out id);
            var entity = context.LogisticRoutes.Find(id);
            var attList = attachmentService.GetAttachmentsByTablePK(context, id, 1);
            var startArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDStart }).FirstOrDefault();
            var endArea = baseAreaService.GetAreasWithParentName(context.BaseAreas, new List<int>() { entity.IntAreaIDEnd }).FirstOrDefault();
            var unit = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntCargoFreightUnit);
            var loadAsk = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntLoadAsk);
            var vehicle = logisticVehicleService.GetLogisticVehicleByID(context, Security.Encrypt(entity.IntVehicleID));
            vm = new VmLogisticRoute()
            {
                Unit = unit != null ? unit.ItemName : "",
                Ask = loadAsk.ItemName,
                LoadAsk = entity.IntLoadAsk,
                Type = entity.VarGoodsType,
                EncriptID = Security.Encrypt(id),
                AreaIDStart = entity.IntAreaIDStart,
                StartArea = startArea != null ? startArea.Name : "",
                AreaIDEnd = entity.IntAreaIDEnd,
                EndArea = endArea != null ? endArea.Name : "",
                ContactPhoneStart = entity.VarContactPhoneStart,
                ContactStart = entity.VarContactStart,
                ContactEnd = entity.VarContactEnd,
                ContactPhoneEnd = entity.VarContactPhoneEnd,
                Details = entity.VarDetails,
                ValidDate = entity.DteValid,
                ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                Flag = entity.IntFlag,
                FreightUnit = entity.IntCargoFreightUnit,
                VehicleID = entity.IntVehicleID,
                LicenseNum = vehicle != null ? vehicle.LicenseNum : "",
                IsBF = entity.IntIsBF,
                CargoFreight = decimal.Round(entity.DecCargoFreight, 2),
                WayStop = entity.VarWayStop,
                DteValid = Utils.GetDateTimeFormate(entity.DteValid)
            };
            return vm;
        }


        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public LogisticRoutePaging GetLogisticRoutePager(SmLogisticRoute search, int page, int rows)
        {
            LogisticRoutePaging pager = new LogisticRoutePaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmLogisticRoute>("ProcGetRouteList @p0,@p1,@p2,@p3,@p4,@p5"
                        , string.IsNullOrWhiteSpace(search.LicenseNum) ? "" : search.LicenseNum
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        , page, rows);

                    pager.total = context.Database.SqlQuery<int>("ProcGetRouteListCount @p0,@p1,@p2,@p3"
                        , string.IsNullOrWhiteSpace(search.LicenseNum) ? "" : search.LicenseNum
                        , search.state
                        , search.ISTG ?? string.Empty
                        , user.IntUserID
                        ).FirstOrDefault();

                    pager.rows = list.OrderByDescending(l => l.DteRefresh).Skip((page - 1) * rows)
                        .Take(rows).Select(p => new VmLogisticRoute
                        {
                            EncriptID = Security.Encrypt(p.EncriptID),
                            LicenseNum = p.LicenseNum,
                            StartArea = p.StartArea,
                            EndArea = p.EndArea,
                            BrowserCount = p.BrowserCount,
                            DteRefresh = p.DteRefresh,
                            ISTG = p.ISTG
                        }).ToList();

                }
            }
            return pager;
        }

        /// <summary>
        /// 得到物流专线统计信息
        /// </summary>
        /// <returns></returns>
        public VmCountInfo GetLogisticRouteInfoCount()
        {
            VmCountInfo count = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCountInfo>("ProcGetRouteCountInfo @p0", user.IntUserID);
                    count = list.FirstOrDefault();
                }
            }
            return count;
        }


        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,2刷新,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        public string RouteBatch(int type, string chooses)
        {
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                string[] IDs = chooses.Split(',');
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.LogisticRoutes.Find(id);
                        if (entity != null)
                        {
                            if (type == 1)
                            {
                                entity.IntFlag = 0;
                            }
                            else if (type == 2 && entity.IntFlag == 3)
                            {
                                entity.DteRefresh = DateTime.Now;
                            }
                            else if (type == 3 && entity.IntFlag == 1)
                            {
                                entity.IntFlag = 2;
                            }
                        }
                    }
                }
                flag = context.SaveChanges();
            }
            if (flag >= 0)
            {
                return "1";
            }
            return "0";
        }

        /// <summary>
        /// 审批分页信息
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public LogisticRoutePaging GetAuditingPager(SmLogisticRoute sm, int page, int rows)
        {
            LogisticRoutePaging pager = new LogisticRoutePaging();
            using (var context = new FaoB2BEntities())
            {
                var list = context.Database.SqlQuery<VmLogisticRoute>("ProcGetRouteList @p0,@p1,@p2,@p3,@p4,@p5"
                    , string.IsNullOrWhiteSpace(sm.LicenseNum) ? "" : sm.LicenseNum, 2, 0,0, page, rows);

                pager.total = context.Database.SqlQuery<int>("ProcGetRouteListCount @p0,@p1,@p2,@p3",
                    string.IsNullOrWhiteSpace(sm.LicenseNum) ? "" : sm.LicenseNum, 2, 0,0).FirstOrDefault();
                pager.rows = list.OrderByDescending(l => l.DteRefresh).Skip((page - 1) * rows)
                    .Take(rows).Select(p => new VmLogisticRoute
                    {
                        EncriptID = Security.Encrypt(p.EncriptID),
                        LicenseNum = p.LicenseNum,
                        StartArea = p.StartArea,
                        EndArea = p.EndArea,
                        BrowserCount = p.BrowserCount,
                        DteRefresh = p.DteRefresh,
                        DteValid = p.DteValid,
                        ValidDate = p.ValidDate,
                        ContactStart = p.ContactStart
                    }).ToList();
            }
            return pager;
        }

        /// <summary>
        /// 审批操作
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        public string Auditing(string ID, int Result)
        {
            int flag = 0;
            string str = "未找到该信息";
            using (var context = new FaoB2BEntities())
            {
                string strID = Security.Decrypt(ID);
                int id = 0;
                if (int.TryParse(strID, out id))
                {
                    var entity = context.LogisticRoutes.Find(id);
                    if (entity != null)
                    {
                        if (entity.IntFlag != 2)
                        {
                            str = "该信息不审批";
                        }
                        else
                        {
                            entity.IntFlag = Result;
                            flag = context.SaveChanges();
                            if (flag >= 0)
                            {
                                str = "1";
                            }
                        }
                    }
                }
            }
            return str;
        }

        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="model"></param>
        public void UpdateBrowserCount(VmLogisticRoute model)
        {
            using (var context = new FaoB2BEntities())
            {
                int id = Utils.ToInt(Security.Decrypt(model.EncriptID));
                var entity = context.LogisticRoutes.Find(id);
                entity.IntBrowserCount++;
                context.SaveChanges();
            }
        }
        #endregion

        #region 辅助方法

        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="infoID">对应的信息ID</param>
        /// <returns></returns>
        private void SaveImage(FaoB2BEntities context, int infoID, VmB2BInfoPicture picture)
        {
            int i = 0;
            int j = 1;
            while (true)
            {
                if (picture.PictureUrls[i] != "" || picture.PictureIDs[i] != "")
                {
                    int id = 0;
                    string strID = Security.Decrypt(picture.PictureIDs[i]);
                    int.TryParse(strID, out id);
                    if (SaveImage(context, picture.PictureUrls[i], picture.OriginalName[i], infoID, j, id))
                    {
                        j++;
                    }
                }
                i++;
                if (i > 2)
                {
                    break;
                }
            }

        }
        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="originalName"></param>
        /// <param name="infoID"></param>
        /// <param name="orderID"></param>
        /// <param name="imageID"></param>
        private bool SaveImage(FaoB2BEntities context, string fileName, string originalName, int infoID, int orderID, int imageID = 0)
        {
            bool flag = false;
            VmAttachment oldAtt = null;
            if (imageID != 0)
            {
                oldAtt = attachmentService.GetAttachmentByID(context, imageID.ToString());
            }
            if (fileName != "" && originalName != "")
            {
                VmAttachment attachment = new VmAttachment();
                attachment.BelongTable = 5;
                attachment.PK = infoID;
                attachment.FileName = originalName;
                attachment.Path = fileName;
                attachment.Descrip = "";
                attachment.Order = orderID;
                if (imageID == 0)
                {
                    attachmentService.AddAttachment(context, attachment);

                }
                else
                {
                    attachment.ID = imageID;
                    attachmentService.UpdateAttachment(context, attachment);
                }
                flag = true;
            }
            else if (fileName == "" && imageID != 0)
            {
                attachmentService.DeleteAttachment(context, imageID);
                flag = false;
            }
            else if (oldAtt != null && oldAtt.Order != orderID)
            {
                oldAtt.Order = orderID;
                attachmentService.UpdateAttachment(context, oldAtt);
                flag = true;
            }
            else if (fileName != "" && imageID != 0)
            {
                flag = true;
            }
            return flag;
        }

        #endregion


        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(LogisticRoute entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(LogisticRoute entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(LogisticRoute entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public LogisticRoute One(IQueryable<LogisticRoute> query, LogisticRoute entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<LogisticRoute> Many(IQueryable<LogisticRoute> query, LogisticRoute entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.InCreatetUserID != 0)
                {
                    entities = entities.Where(p => p.InCreatetUserID == entity.InCreatetUserID);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
﻿using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Data.Sms;
using Fao.Data.Sms.DAL;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using Fao.Common;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-03-13 17:03:47
    /// Sms_MT_Detail服务实现-Power by CodeGG
    /// </summary>
    public class Sms_MT_DetailService : Entity<Sms_MT_Detail>, ISms_MT_DetailService
    {

        #region 业务接口引用

        IBaseUserService baseUserService = new BaseUserService();
        IUserTransactionService userTransactionService = new UserTransactionService();
        ISMSBuyLogService smsBuyLogService = new SMSBuyLogService();
        #endregion

        #region 实现业务接口


        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="MsgContent">短信内容</param>
        /// <param name="NumList">接收用户的UserID+"A"接收用户的手机号码(该号码必须经过验证)</param>
        /// 如 NumList：1365A13691433299,1366A15899998888
        /// <returns></returns> 
        public string SendSms(string MsgContent, string NumList)
        {
            string msg = null;
            var e = baseUserService.CurrentUser();
            if (e == null)
            {
                msg = "请登录!";

            }
            else
            {
                var user = userTransactionService.GetCurrentUserTransaction();

                // MsgContent = HtmlHelper.SqlFilter(MsgContent);

                int msgLen = MsgContent.Trim().Length;
                if (msgLen == 0)
                {
                    msg = "填写短信内容!";
                }
                else
                {
                    string reList = Fao.Data.Sms.SendSms.FormationPhoneFirst(NumList);
                    int reCount = reList.Split(',').Length;
                    if (reList.Length == 0 || reCount == 0)
                    {
                        msg = "添加正确的短信接收者!";
                    }
                    else
                    {
                        int itemCount = 0;  //短信被拆分多少条
                        if (msgLen % 64 == 0)
                            itemCount = msgLen % 64;
                        else
                            itemCount = msgLen / 64 + 1;

                        int sumCount = itemCount * reCount;//总共要发的条数 

                        if (sumCount <= user.PhoneMsgSum)
                        {
                            //数据库更改短信剩余条数，更改成功后，才可发送
                            string editDB = smsBuyLogService.updateMsgCount(sumCount);
                            if (editDB.Equals("1"))
                            {
                                SendSms.SmsSend SS = new SendSms.SmsSend();
                                SS.smsContetnt = MsgContent;
                                SS.smsSendUserID = user.UserID;
                                SS.smsReceiveNumList = NumList;

                                Thread tsPhone = new Thread(new ParameterizedThreadStart(SendVerMsg));
                                tsPhone.Start(SS);
                                msg = "1";
                            }
                            else
                            {
                                msg = editDB;
                            }
                        }
                        else
                        {
                            msg = "此次要发" + sumCount + "条数，多余您剩余的条数！";
                        }
                    }
                }
            }
            return msg;
        }

        /// <summary>
        /// 发送验证短信。注册时做手机号码唯一性判断
        /// </summary>
        /// <param name="user"></param>
        private void SendVerMsg(object SPMsg)
        {
            SendSms.SmsSend SS = SPMsg as SendSms.SmsSend;
            Fao.Data.Sms.SendSms.Insert(SS);
        }

        /// <summary>
        /// 根据条件得到 收件箱 的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VmSmsInboxPaging GetSmsInboxPager(smSmsInbox search, int page, int rows)
        {
            VmSmsInboxPaging pager = new VmSmsInboxPaging();
            pager.rows = new List<VmSmsInbox>();

            var user = userTransactionService.GetCurrentUserTransaction();
            if (user == null)
                return pager;
            int srcID = user.IntSMSSrcID;
            if (srcID == 0)
                return pager;

            StringBuilder sqlCout = new StringBuilder();  //查询总数的语句
            StringBuilder sb = new StringBuilder();//查询分页数据
            sb.Append(string.Format("select msgid,sms_content,up_time,mobile_no from sms_mo where  SUBSTRING(long_serv_no,13)='{0}' ", srcID));
            sqlCout.Append(string.Format("select count(*) from sms_mo where  SUBSTRING(long_serv_no,13)='{0}' ", srcID));

            if (search.SendStartDate != null)
            {
                sb.Append(string.Format(" and up_time>='{0}'", search.SendStartDate));
                sqlCout.Append(string.Format(" and up_time>='{0}'", search.SendStartDate));

            }
            if (search.SendEndDate != null)
            {
                //检索日期加一天
                DateTime rv = System.DateTime.Now;
                DateTime.TryParse(search.SendEndDate, out rv);
                search.SendEndDate = rv.AddDays(1).ToString("yyyy-MM-dd");

                sb.Append(string.Format(" and up_time<'{0}'", search.SendEndDate));
                sqlCout.Append(string.Format(" and up_time<'{0}'", search.SendEndDate));
            }
            if (search.MobileNum != null)
            {
                sb.Append(string.Format(" and  mobile_no like '{0}%'", search.MobileNum));
                sqlCout.Append(string.Format(" and  mobile_no like '{0}%'", search.MobileNum));
            }
            sb.Append(" order by msgid asc");

            sb.AppendFormat(" limit {0},{1}", (page - 1) * rows, page * rows);

            DataSet ds = MySqlHelper.ExecuteDataSet(CommandType.Text, sb.ToString() + ";" + sqlCout.ToString());
            if (ds == null || ds.Tables.Count != 2)
                return pager;

            DataTable dtTable = ds.Tables[0];
            pager.total = Utils.ToInt(ds.Tables[1].Rows[0][0].ToString());

            //DataSet ds = MySqlHelper.ExecuteDataSet(CommandType.Text, sb.ToString());

            DataColumn dcVarRowNum = new DataColumn("RowNum");
            DataColumn dcVarRealName = new DataColumn("VarRealName");
            DataColumn dcVarCompanyName = new DataColumn("VarEnterpriseName");

            dtTable.Columns.Add(dcVarRowNum);
            dtTable.Columns.Add(dcVarRealName);
            dtTable.Columns.Add(dcVarCompanyName);

            int i = 1;
            foreach (DataRow dr in dtTable.Rows)
            {
                DataTable dt = Fao.Data.Sms.BLL.Sms_MT_Detail.getContactInfo(dr["mobile_no"].ToString());
                if (dt.Rows.Count > 0)
                {
                    dr["RowNum"] = i++;
                    dr["VarRealName"] = dt.Rows[0]["VarRealName"];
                    dr["VarEnterpriseName"] = dt.Rows[0]["VarEnterpriseName"];
                }
            }

            var list = Utils.List<VmSmsInbox>(dtTable);

            //pager.total = list.Count(); // mysql
            pager.total = Utils.ToInt(MySqlHelper.ExecuteDataTable(CommandType.Text, sqlCout.ToString()).Rows[0][0].ToString());

            pager.rows = list.OrderByDescending(l => l.RowNum).Select(p => new VmSmsInbox
                {
                    RowNum = p.RowNum,
                    sms_content = p.sms_content,
                    up_time = p.up_time,
                    VarEnterpriseName = p.VarEnterpriseName,
                    VarRealName = p.VarRealName.TrimEnd('，')
                }).ToList();

            return pager;
        }


        /// <summary>
        /// 根据条件得到短信详细内容 的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VmSms_MT_DetailPaing GetSmSDetailPager(SmSms_MT_Detail search, int page, int rows)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Format("select * from (select row_number() over(order by sd.BigDetailID desc) as RowNum,sd.BigDetailID ,isnull(bu.VarRealName,'匿名用户') VarRealName,isnull(ep.VarEnterpriseName,'') VarEnterpriseName ,CONVERT(nvarchar(30), sd.SendTime, 120) as SendTime,sd.ReportState from dbo.Sms_MT_Detail sd  left join dbo.BaseUser bu  on bu.IntUserID=sd.BigContactAUID left join dbo.Enterprise ep on bu.IntUserID=ep.IntCreateUserID where  ep.IntFlag=1  and sd.Flag<>0  and sd.BatchID={0}", search.BatchID));
            if (search.SendStartDate != null)
                sb.Append(string.Format(" and sd.SendTime>='{0}'", search.SendStartDate));
            if (search.SendEndDate != null)
                sb.Append(string.Format(" and sd.SendTime<='{0}'", search.SendEndDate));
            if (search.ReciverUserName != null)
                sb.Append(string.Format(" and bu.VarRealName='{0}'", search.ReciverUserName));
            if (search.SmsState != "1")
            {
                if (search.SmsState == "2")
                    sb.Append(" and sd.ReportState='DELIVRD'");
                else
                    if (search.SmsState == "3")
                        sb.Append(" and sd.ReportState<>'DELIVRD'");
            }

            sb.Append(string.Format(" ) as t where  t.RowNum>({0} -1)*{1} and t.RowNum<=({0} * {1})", page, rows));

            VmSms_MT_DetailPaing pager = new VmSms_MT_DetailPaing();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user == null)
                    return null;
                var list = context.Database.SqlQuery<VmSms_MT_Detail>(sb.ToString()).ToList();
                pager.total = list.Count();//此处有错 未修改
                pager.rows = list.OrderByDescending(l => l.RowNum).Select(p => new VmSms_MT_Detail
                    {
                        RowNum = p.RowNum,
                        BigDetailID = p.BigDetailID,
                        ReportState = p.ReportState,
                        SendTime = p.SendTime,
                        VarEnterpriseName = p.VarEnterpriseName,
                        VarRealName = string.IsNullOrEmpty(p.VarRealName) ? "匿名用户" : p.VarRealName
                    }).ToList();
            }
            return pager;
        }



        /// <summary>
        /// 根据SmSms_MT_Detail查询模型，返回VmSms_MT_Detail视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmSms_MT_Detail> GetSms_MT_Details(SmSms_MT_Detail searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmSms_MT_Detail视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmSms_MT_Detail GetSms_MT_DetailByID(string id)
        {
            throw new Exception("没有实现");
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(Sms_MT_Detail entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(Sms_MT_Detail entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(Sms_MT_Detail entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public Sms_MT_Detail One(IQueryable<Sms_MT_Detail> query, Sms_MT_Detail entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<Sms_MT_Detail> Many(IQueryable<Sms_MT_Detail> query, Sms_MT_Detail entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {

            }



            return entities;
        }

        #endregion

    }
}
﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;

namespace Fao.Service.B2B
{

    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Evaluate服务实现-Power by CodeGG
    /// </summary>
    public class EvaluateService : Entity<Evaluate>, IEvaluateService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmEvaluate查询模型，返回VmEvaluate视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmEvaluate> GetEvaluates(SmEvaluate searchModel)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据id，返回VmEvaluate视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmEvaluate GetEvaluateByID(string id)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 根据信息id，类型。返回该信息的评论列表分页数据
        /// </summary>
        /// <param name="id">页面实体的id</param>
        /// <param name="type">实体属于哪类表</param>
        /// <returns></returns>
        public VmEvaluatePaging GetMessageEvaluates(int id, int type)
        {
            VmEvaluatePaging paging = new VmEvaluatePaging();
            using (var context = new FaoB2BEntities())
            {
                var comments = Many(context.Evaluates, new Evaluate
                {
                    IntBelongTablePrikeyID = id,
                    IntBelongTable = type
                }).Select(e => new
                {
                    ID = e.IntEvaluateID,
                    Text = e.VarContent,
                    UserName = e.IntCreateUserID,
                    CreateDate = e.DteCreate,
                    Cost = e.IntScores,
                    IsAnonymous = e.IntIsAnonymous
                }).ToList();

                paging.total = comments.Count.ToString();

                var useridList = comments.Select(c => c.UserName).ToList();

                var users = baseUserService.Many(context.BaseUsers, null)
                    .Where(u => useridList.Contains(u.IntUserID))
                    .Select(u => new
                    {
                        u.IntUserID,
                        u.VarNickName
                    }).ToList();

                paging.rows = comments.OrderByDescending(c => c.CreateDate)
                    .Join(users, c => c.UserName, u => u.IntUserID,
                    (c, u) => new VmEvaluate
                    {
                        ID = Security.Encrypt(c.ID),
                        UserName = c.IsAnonymous == 1 ? "匿名用户" : "用户："+u.VarNickName,
                        Cost = c.Cost.ToString(),
                        CreateDate = Utils.GetDateWithHMFormate(c.CreateDate),
                        Text = c.Text
                    }).ToList();
            }
            return paging;
        }


        /// <summary>
        /// 添加指定类型，指定表主键的评论。返回成功标识
        /// </summary>
        /// <param name="comment"></param>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <returns>1成功，2当前用户未登录</returns>
        public string AddMessageEvaluate(VmEvaluate comment, int id, int type)
        {
            string msg = "0";
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user == null)
                {
                    //当前用户未登录
                    msg = "2";
                }
                else
                {
                    var evaluate = new Evaluate
                    {
                        DteCreate = DateTime.Now,
                        IntScores = Utils.ToInt(comment.Cost),
                        VarContent = comment.Text,
                        IntCreateUserID = user.IntUserID,
                        IntFlag = 1,
                        IntBelongTablePrikeyID = id,
                        IntBelongTable = type,
                        IntIsAnonymous = Utils.ToInt(comment.IsAnonymous)
                    };
                    //添加到实体集合，不提交
                    context.Evaluates.Add(evaluate);

                    msg = context.SaveChanges().ToString();
                }
            }
            return msg;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(Evaluate entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(Evaluate entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(Evaluate entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public Evaluate One(IQueryable<Evaluate> query, Evaluate entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<Evaluate> Many(IQueryable<Evaluate> query, Evaluate entity)
        {
            var entitys = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntBelongTablePrikeyID != 0)
                {
                    entitys = entitys.Where(e => e.IntBelongTablePrikeyID == entity.IntBelongTablePrikeyID);
                }

                if (entity.IntBelongTable != 0)
                {
                    entitys = entitys.Where(e => e.IntBelongTable == entity.IntBelongTable);
                }
            }

            entitys = entitys.Where(e => e.IntFlag != 0);

            return entitys;
        }

        #endregion

    }
}
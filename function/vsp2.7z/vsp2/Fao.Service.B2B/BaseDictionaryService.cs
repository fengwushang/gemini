﻿using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Data.B2B;
using Fao.Common;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-20 10:18:31
    /// BaseDictionary服务实现-Power by CodeGG
    /// </summary>
    public class BaseDictionaryService : Entity<BaseDictionary>, IBaseDictionaryService
    {

        #region 业务接口引用

        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmBaseDictionary查询模型，返回VmBaseDictionary视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmBaseDictionary> GetBaseDictionarys(SmBaseDictionary searchModel)
        {
            var vmDictList = new List<VmBaseDictionary>();
            using (var context = new FaoB2BEntities())
            {
                var list = Many(context.BaseDictionaries, new BaseDictionary
                {
                    IntParentID = searchModel.ParentID,
                    VarAbbreviation = searchModel.AbbName
                }).OrderBy(p => p.IntOrderID).ToList();

                foreach (var item in list)
                {
                    vmDictList.Add(GetVMFrom(item));
                }

            }
            return vmDictList;
        }

        /// <summary>
        /// 根据id，返回VmBaseDictionary视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmBaseDictionary GetBaseDictionaryByID(FaoB2BEntities context, int id)
        {
            var entity = context.BaseDictionaries.Find(id);
            return GetVMFrom(entity);
        }

        /// <summary>
        /// 添加字典项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddDictionItem(VmBaseDictionary model)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var adminID = HtmlHelper.GetCookieValue("AdminID");
                string name = model.ItemName;
                int parentID = model.ParentID;
                int id = model.ItemID;
                var e = Many(context.BaseDictionaries, null).Where(p => p.VarItemName == name && p.IntParentID == parentID).Count();
                if (e > 0)
                {
                    rv = "该字典项名称已存在";
                }
                else
                {
                    int orderID = Many(context.BaseDictionaries, null).Where(p => p.IntParentID == model.ParentID).Count();
                    BaseDictionary entity = GetEntityFrom(model);
                    entity.IntOrderID = orderID + 1;
                    entity.IntCreateUserID = Utils.ToInt(adminID);
                    context.BaseDictionaries.Add(entity);
                    int flag = context.SaveChanges();
                    if (flag >= 0)
                    {
                        rv = "1";
                    }
                    else
                    {
                        rv = "保存失败";
                    }
                }
            }

            return rv;
        }

        /// <summary>
        /// 修改字典项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateDictionItem(VmBaseDictionary model)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                if (model == null)
                {
                    rv = "保存失败";
                }
                else
                {
                    string name = model.ItemName;
                    int parentID = model.ParentID;
                    int id = model.ItemID;
                    var e = Many(context.BaseDictionaries, null).Where(p => p.VarItemName == name && p.IntParentID == parentID && p.IntItemID != id).Count();
                    if (e > 0)
                    {
                        rv = "该字典项名称已存在";
                    }
                    else
                    {
                        var entity = context.BaseDictionaries.Find(model.ItemID);
                        if (entity != null)
                        {
                            entity.VarItemName = model.ItemName;
                            entity.VarDescription = model.ItemDescription;
                            entity.VarAbbreviation = model.Abbreviation;
                            int flag = context.SaveChanges();
                            if (flag >= 0)
                            {
                                rv = "1";
                            }
                            else
                            {
                                rv = "保存失败";
                            }
                        }
                        else
                        {
                            rv = "保存失败";
                        }
                    }
                }
            }

            return rv;
        }

        /// <summary>
        /// 删除字典项
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int DeleteDictionItem(int id)
        {
            int rv = 0;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseDictionaries.Find(id);
                if (entity == null)
                {
                    rv = 1;
                }
                else
                {
                    entity.IntFlag = 0;
                    rv = context.SaveChanges();
                }
            }

            return rv;
        }

        /// <summary>
        /// 字典项上移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        public string ItemUP(int ItemID)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseDictionaries.Find(ItemID);
                if (entity != null)
                {
                    if (entity.IntOrderID > 1)
                    {
                        entity.IntOrderID--;
                        var pre = Many(context.BaseDictionaries, null).Where(p => p.IntParentID == entity.IntParentID && p.IntOrderID == entity.IntOrderID).FirstOrDefault();
                        if (pre != null)
                        {
                            pre.IntOrderID++;
                        }
                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            rv = "1";
                        }
                        else
                        {
                            rv = "-1";
                        }
                    }
                    else
                    {
                        rv = "该项已经是第一位，不能再移了";
                    }

                }
                else
                {
                    rv = "";
                }
            }

            return rv;
        }

        /// <summary>
        /// 字典项下移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        public string ItemDown(int ItemID)
        {
            string rv = string.Empty;
            using (var context = new FaoB2BEntities())
            {
                var entity = context.BaseDictionaries.Find(ItemID);
                if (entity != null)
                {
                    var max = Many(context.BaseDictionaries, null).Where(p => p.IntParentID == entity.IntParentID).Max(p => p.IntOrderID);
                    if (entity.IntOrderID < max)
                    {
                        entity.IntOrderID++;
                        var pre = Many(context.BaseDictionaries, null).Where(p => p.IntParentID == entity.IntParentID && p.IntOrderID == entity.IntOrderID).FirstOrDefault();
                        if (pre != null)
                        {
                            pre.IntOrderID--;
                        }
                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            rv = "1";
                        }
                        else
                        {
                            rv = "-1";
                        }
                    }
                    else
                    {
                        rv = "该项已经是最后一位，不能再移了";
                    }

                }
                else
                {
                    rv = "";
                }
            }

            return rv;
        }
        #endregion

        #region 辅助方法

        /// <summary>
        /// 把数据库实例转换成VM实例
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private VmBaseDictionary GetVMFrom(BaseDictionary entity)
        {

            if (entity == null)
            {
                return null;
            }
            var vm = new VmBaseDictionary()
            {
                ItemID = entity.IntItemID,
                ParentID = entity.IntParentID,
                ItemName = entity.VarItemName,
                ItemDescription = entity.VarDescription,
                state = "closed",
                _parentId = entity.IntParentID,
                Abbreviation = entity.VarAbbreviation
            };

            return vm;

        }

        /// <summary>
        /// 把VM实例转化成数据库实例
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private BaseDictionary GetEntityFrom(VmBaseDictionary model)
        {
            if (model == null)
            {
                return null;
            }
            var entity = new BaseDictionary()
            {
                IntItemID = model.ItemID,
                IntParentID = model.ParentID,
                VarItemName = model.ItemName,
                VarDescription = model.ItemDescription == null ? "" : model.ItemDescription,
                VarAbbreviation = model.Abbreviation,
                IntLayerID = 0,
                VarSearch = "",
                IntFlag = 1,
                IntOrderID = 0,
                IntCreateUserID = 0,
                DteCreate = DateTime.Now
            };
            return entity;
        }
        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(BaseDictionary entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(BaseDictionary entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(BaseDictionary entity)
        {

            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public BaseDictionary One(IQueryable<BaseDictionary> query, BaseDictionary entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<BaseDictionary> Many(IQueryable<BaseDictionary> query, BaseDictionary entity)
        {
            var entities = query.Select(e => e);
            if (entity != null)
            {

                //根据别名，查询子集字典数据用
                if (!string.IsNullOrEmpty(entity.VarAbbreviation))
                {
                    var pid = entities.Where(e => e.VarAbbreviation == entity.VarAbbreviation)
                            .Select(e => e.IntItemID).FirstOrDefault();

                    entities = entities.Where(p => pid == p.IntParentID);


                }
                else
                {
                    //树状列表，默认根据父id过滤。
                    entities = entities.Where(p => p.IntParentID == entity.IntParentID);

                }
            }
            entities = entities.Where(p => p.IntFlag == 1);
            return entities;
        }

        #endregion

    }
}
﻿using Fao.Common;
using Fao.Data.B2B;
using Fao.Data.B2B.MV;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Threading;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: sjp , 2013-02-21 10:32:34
    /// BaseUser服务实现-Power by sjp
    /// </summary>
    public class BasePlatUserService:IBasePlatUserService
    {
        #region 引用业务接口
    
        IBaseUserService baseUserService = new BaseUserService();
        #endregion

        #region 实现业务类
        /// <summary>
        ///   跳转到B2B时进行检验 
        /// </summary>
        /// <param name="IntTypeID">平台标识：1 B2B，2 HR，3PS</param>
        /// <param name="userID"></param>
        /// <param name="VarTokenID"></param>
        /// <returns></returns>
        public int GetCheckToken(int IntTypeID, int userID, string VarTokenID)
        {
            int result = 0;
            try
            {
                if (IntTypeID == 3)
                {
                    AuthenCheck.AuthenPassportClient AC = new AuthenCheck.AuthenPassportClient();
                    result = AC.CheckToken(1, userID, VarTokenID);
                }
                else
                    if (IntTypeID == 2)
                    {
                        HRWcf.HrRegisterUserWcfClient HR = new HRWcf.HrRegisterUserWcfClient();
                        result = HR.CheckToken(1, userID, VarTokenID);
                    }
            }
            catch
            { }
            return result;
        }

        /// <summary>
        /// 添加注册用户
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int AddRegisterUser(VmBasePlatUser model)
        {
            int rv = -1;
            using (var context = new FaoB2BEntities())
            {
                BaseUser baseuser = GetBaseUserFrom(model);
                int count = context.BaseUsers.Where(p => p.VarPhone == model.VarPhone).Count();
                if (count > 0)
                    rv = -1;
                else
                {

                   // baseuser.VarEmailVerifyCode = ValidateCode.CreateRandNum(5);
                    int hours = Utils.ToInt(ConfigurationManager.AppSettings["DteEmailValid"]);
                    baseuser.DteEmailVerifyValid = System.DateTime.Now.AddHours(hours);
                    baseuser.IntEmailVerify = 2;
                    baseuser.IntFlag = 1;

                    context.BaseUsers.Add(baseuser);

                    int flag = context.SaveChanges();

                    if (flag > 0)
                    {
                       // Thread tsEmail = new Thread(new ParameterizedThreadStart(SendVerMail));
                       // tsEmail.Start(baseuser);
                        //BaseUser entity = context.BaseUsers.Where(p => p.VarPhone == model.VarPhone).SingleOrDefault();
                        //int userID = Utils.ToInt(model.IntUserID);
                        //BasePlatform basePlatform = new BasePlatform();
                        //basePlatform.IntUserID = userID;
                        //basePlatform.IntTypeID = 1;
                        //basePlatform.IntCreateUserID = entity.IntUserID;
                        //basePlatform.IntFlag = 1;
                        //context.BasePlatforms.Add(basePlatform);
                        //context.SaveChanges();
                    }

                    rv = baseuser.IntUserID;
                }
            }
            //注册成功 返回用户id
            return rv;
        }

        /// <summary>
        /// 从VM中获得数据库实体
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private BaseUser GetBaseUserFrom(VmBasePlatUser model)
        {
            string encryptpassword = Security.MD5(model.VarPWD);

            BaseUser user = new BaseUser()
            {
                IntPhoneVerify= Utils.ToInt( model.IntPhoneVerify),
                IntEmailVerify =Utils.ToInt(model.IntEmailVerify),
                VarEmailVerifyCode =model.VarEmailVerifyCode,
                IntCurrentLogin= Utils.ToInt(model.IntCurrentLogin),
                IntUserGroup = Utils.ToInt(model.IntUserGroup),
                VarNickName = model.VarNickName,
                VarEmail = model.VarEmail,
                VarPWD = encryptpassword,
                IntFlag = 2,
                VarPhone =model.VarPhone
            };
            return user;
        }


        #region 添加注册用户,ForWCF
        /// <summary>
        /// 添加注册用户
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int AddRegisterUserWcf(VmBasePlatUser model)
        {
            int rv = -1;
            using (var context = new FaoB2BEntities())
            {
                BaseUser baseuser = GetBaseUserFromWcf(model);
                int count = context.BaseUsers.Where(p => p.VarPhone == model.VarPhone).Count();
                if (count > 0)
                    rv = -1;
                else
                {

                    // baseuser.VarEmailVerifyCode = ValidateCode.CreateRandNum(5);
                    int hours = Utils.ToInt(ConfigurationManager.AppSettings["DteEmailValid"]);
                    baseuser.DteEmailVerifyValid = System.DateTime.Now.AddHours(hours);
                    baseuser.IntEmailVerify = 2;
                    baseuser.IntFlag = 2;

                    context.BaseUsers.Add(baseuser);

                    int flag = context.SaveChanges();

                    if (flag > 0)
                    {
                        // Thread tsEmail = new Thread(new ParameterizedThreadStart(SendVerMail));
                        // tsEmail.Start(baseuser); 
                    }

                    rv = baseuser.IntUserID;
                }
            }
            //注册成功 返回用户id
            return rv;
        }

        /// <summary>
        /// 插入到平台表中其他平台用户 2个 平台标识：1 B2B，2 HR，3PS 
        /// </summary>
        /// <param name="str">'114,1.2,123.321'</param>
        public int InsertOtherPlatform(string str)
        {
            int re = 0;
            using (var context = new FaoB2BEntities())
            {
                string uid = str.Split(',')[0];
                string[] ty = str.Split(',')[1].Split('.');
                string[] tuid = str.Split(',')[2].Split('.');

                for (int i = 0; i < 2; i++)
                {
                    if (ty[i].ToString().Equals("2")) //HR的数据不插入，屏蔽
                    {
                        continue;
                    }
                    BasePlatform basePlatform = new BasePlatform();
                    basePlatform.IntUserID = int.Parse(tuid[i]);
                    basePlatform.IntTypeID = int.Parse(ty[i]);
                    basePlatform.IntCreateUserID = int.Parse(uid); ;
                    basePlatform.IntFlag = 1;
                    context.BasePlatforms.Add(basePlatform);
                    context.SaveChanges();
                }
                re = 1;
            }
            return re;
        }

        /// <summary>
        /// 从VM中获得数据库实体
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private BaseUser GetBaseUserFromWcf(VmBasePlatUser model)
        { 
            BaseUser user = new BaseUser()
            {
                IntPhoneVerify = Utils.ToInt(model.IntPhoneVerify),
                IntEmailVerify = Utils.ToInt(model.IntEmailVerify),
                VarEmailVerifyCode = model.VarEmailVerifyCode,
                IntCurrentLogin = Utils.ToInt(model.IntCurrentLogin),
                IntUserGroup = Utils.ToInt(model.IntUserGroup),
                VarNickName = model.VarNickName,
                VarEmail = model.VarEmail,
                VarPWD = model.VarPWD,
                IntFlag = 2,
                VarPhone = model.VarPhone
            };
            return user;
        }
        #endregion


        /// <summary>
        /// 从ps跳转登录
        /// </summary>
        /// <param name="userid"></param>
        public void Login_ps(string userid)
        {
            int intUserID = Utils.ToInt(userid);
            using (var context = new FaoB2BEntities())
            {
                // var user = context.BaseUsers.Where(p => p.IntUserID == intUserID).SingleOrDefault();
                BaseUser user = context.BaseUsers.Where(p => p.IntUserID == intUserID).SingleOrDefault(); 
                if (user != null)
                {
                    baseUserService.SetLoginCookies(user, false);
                    //Fao.Common.HtmlHelper.SetCookie("B2B_UserID", Security.Encrypt(userid));
                    //Fao.Common.HtmlHelper.SetCookie("B2B_UserName", user.VarRealName);
                    //Fao.Common.HtmlHelper.SetCookie("B2B_UserEmail", user.VarEmail);
                }
            }
        }
        /// <summary>
        /// 向联合登录表中插入一条数据
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddEntity(PlatUser model)
        {
            //根据登录用户id查出平台用户表中的相对应的平台的用户id
            int intType = Utils.ToInt(model.IntTypeID);
            int intUserID = Utils.ToInt(baseUserService.CurrentUserID());
            using (var context = new FaoB2BEntities())
            {
                BasePlatform user = context.BasePlatforms.Where(p => p.IntTypeID == intType && p.IntCreateUserID == intUserID).SingleOrDefault();
                string uuid = Guid.NewGuid().ToString("D"); //令牌id 
                BaseJointLogin baseJointLogin = null;
                if (user != null)
                {
                    baseJointLogin = new BaseJointLogin();
                    baseJointLogin.IntTypeID = user.IntTypeID;
                    baseJointLogin.IntUserID = user.IntUserID;
                    baseJointLogin.IntCreateUserID = user.IntCreateUserID;
                    baseJointLogin.VarTokenID = uuid;
                    baseJointLogin.IntFlag = 1;

                    context.BaseJointLogins.Add(baseJointLogin);
                }
                //保存到数据库
                int flag = context.SaveChanges();
                if (flag > 0)
                {
                    PlatUser smPlatUser = new PlatUser();
                    smPlatUser.VarTokenID = Security.Encrypt(uuid);
                    smPlatUser.IntTypeID = model.IntTypeID;
                    smPlatUser.IntUserID = Security.Encrypt(user.IntUserID); 
                    string plat = Utils.ToJsonStr(smPlatUser);
                    return plat; 
                }
            }
            return "";
        }

         /// <summary>
        /// 检测用户是否存在
        /// </summary>
        /// <param name="IntTypeID"></param>
        /// <param name="userID"></param>
        /// <param name="VarTokenID"></param>
        /// <returns></returns>
        public int GetPlatUser(int IntTypeID, int userID, string VarTokenID)
        {
            using (var context = new FaoB2BEntities())
            {
                BaseJointLogin baseJointLogin = context.BaseJointLogins.Where(p => p.IntTypeID == IntTypeID && p.IntUserID == userID && p.VarTokenID == VarTokenID && p.IntFlag ==1).SingleOrDefault();
                if (baseJointLogin != null)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }

        /// <summary>
        /// 删除这条数据
        /// </summary>
        /// <param name="IntTypeID"></param>
        /// <param name="userID"></param>
        /// <param name="VarTokenID"></param>
        /// <returns></returns>
        public string DelPlatUser(int IntTypeID, int userID, string VarTokenID)
        {
            using (var context = new FaoB2BEntities())
            {
                //BaseJointLogin baseJointLogin = context.BaseJointLogins.Find(IntTypeID,userID,VarTokenID);

                BaseJointLogin baseJointLogin = context.BaseJointLogins.Where(p => p.IntTypeID == IntTypeID && p.IntUserID == userID && p.VarTokenID == VarTokenID).SingleOrDefault();
                if (baseJointLogin != null)
                {
                    baseJointLogin.IntFlag = 0;
                    context.SaveChanges();
                }
                return "";
            }
        }
        #endregion
    }
}

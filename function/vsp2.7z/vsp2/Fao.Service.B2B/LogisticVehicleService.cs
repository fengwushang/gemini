﻿using Fao.Data.B2B;
using Fao.Data;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using Fao.Interface.B2B;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Common;

namespace Fao.Service.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticVehicle服务实现-Power by CodeGG
    /// </summary>
    public class LogisticVehicleService : Entity<LogisticVehicle>, ILogisticVehicleService
    {

        #region 业务接口引用

        //将需要的服务接口引用，添加到这里
        IBaseUserService baseUserService = new BaseUserService();
        IAttachmentService attachmentService = new AttachmentService();
        IBaseDictionaryService baseDictionaryService = new BaseDictionaryService();
        #endregion

        #region 实现业务接口

        /// <summary>
        /// 根据SmLogisticVehicle查询模型，返回VmLogisticVehicle视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        public List<VmLogisticVehicle> GetLogisticVehicles(SmLogisticVehicle searchModel)
        {
            throw new Exception("没有实现");
        }
        public VmLogisticVehicle GetLogisticVehicleByID(string encriptID)
        {
            VmLogisticVehicle vmLogisticVehicle = null;
            using (var context = new FaoB2BEntities())
            {
                vmLogisticVehicle = GetLogisticVehicleByID(context, encriptID);
                vmLogisticVehicle.Manufacture = Convert.ToDateTime(Convert.ToDateTime(vmLogisticVehicle.Manufacture).ToString("yyyy-MM-dd"));
            }
            return vmLogisticVehicle;
        }
        /// <summary>
        /// 根据id，返回VmLogisticVehicle视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        public VmLogisticVehicle GetLogisticVehicleByID(FaoB2BEntities context, string encriptID)
        {
            string strID = Security.Decrypt(encriptID);
            int id = 0;
            int.TryParse(strID, out id);
            var entity = context.LogisticVehicles.Find(id);
            if (entity == null)
            {
                return null;
            }
            var attList = attachmentService.GetAttachmentsByTablePK(context, id, 3);
            var type = baseDictionaryService.GetBaseDictionaryByID(context, entity.IntVehicleType);
            var model = new VmLogisticVehicle
            {
                EncriptID = Common.Security.Encrypt(entity.IntVehicleID),
                CreatDate = entity.DteCreate,
                Flag = entity.IntFlag,
                LicenseNum = entity.VarLicenseNum,
                VehicleNumber = entity.VarVehicleNum,
                VehicleSize = entity.VaVehicleSize,
                VehicleType = entity.IntVehicleType,
                IsGPS = entity.IntIsGPS,
                IsInsurance = entity.IntIsInsurance,
                IsTemp = entity.IntIsTemp,
                MaxLoad = decimal.Parse(entity.VarMaxLoad.ToString("0.00")),
                MaxVolume = decimal.Parse(entity.VarMaxVolume.ToString("0.00")),
                Manufacture = entity.DteManufacture,
                StrCreateDate = Utils.GetDateWithHMFormate(entity.DteCreate),
                StrManufacture = Utils.GetDateWithHMFormate(entity.DteManufacture),
                ImageID = attList.OrderBy(p => p.Order).Select(p => Security.Encrypt(p.ID)).ToList<string>(),
                ImageUrl = attList.OrderBy(p => p.Order).Select(p => p.Path.Replace(".", "_small.")).ToList<string>(),
                ValidDate = entity.DteValid,
                StrValidDate = Utils.GetDateWithHMFormate(entity.DteValid),
                Type = type != null ? type.ItemName : ""
            };
            decimal l, w, h;
            decimal.TryParse(model.VehicleSize.Split('*')[0], out l);
            decimal.TryParse(model.VehicleSize.Split('*')[1], out w);
            decimal.TryParse(model.VehicleSize.Split('*')[2], out h);
            model.Long = l;
            model.Wide = w;
            model.High = h;
            return model;
        }

        /// <summary>
        /// 添加车辆信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string AddVehicleInfo(VmLogisticVehicle model, VmB2BInfoPicture picture)
        {
            string str = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                LogisticVehicle entity = new LogisticVehicle();
                //var enterprise = enterpriseService.GetCurrentEnterprise();
                if (user == null)
                {
                    str = "用户未登陆";
                }
                else
                {
                    entity.IntCreateUserID = user.IntUserID;
                    entity.DteCreate = DateTime.Now;
                    entity.IntFlag = model.Flag ?? 1;
                    entity.VarLicenseNum = model.LicenseNum;
                    entity.VarVehicleNum = model.VehicleNumber;
                    entity.VaVehicleSize = model.Long.ToString() + "*" + model.Wide.ToString() + "*" + model.High.ToString();
                    entity.IntVehicleType = model.VehicleType ?? 0;
                    entity.IntIsGPS = model.IsGPS;
                    entity.IntIsInsurance = model.IsInsurance;
                    entity.IntIsTemp = model.IsTemp;
                    entity.VarMaxLoad = model.MaxLoad??0M;
                    entity.VarMaxVolume = model.MaxVolume ?? 0;
                    entity.DteManufacture = model.Manufacture;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                    context.LogisticVehicles.Add(entity);
                    int flag = context.SaveChanges();
                    SaveImage(context, entity.IntVehicleID, picture);
                    if (flag >= 0)
                    {
                        str = "1";
                    }
                    else
                    {
                        str = "保存失败";
                    }
                }
            }
            return str;
        }

        /// <summary>
        /// 修改车辆信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public string UpdateVehicleInfo(VmLogisticVehicle model, VmB2BInfoPicture picture = null)
        {
            string str = null;
            string strID = Common.Security.Decrypt(model.EncriptID);
            int id;
            if (!int.TryParse(strID, out id))
            {
                return "未提到该记录";
            }
            using (var context = new FaoB2BEntities())
            {
                var entity = context.LogisticVehicles.Find(id);
                if (entity != null)
                {
                    entity.IntFlag = model.Flag ?? 1;
                    entity.VarLicenseNum = model.LicenseNum;
                    entity.VarVehicleNum = model.VehicleNumber;
                    entity.VaVehicleSize = model.Long + "*" + model.Wide + "*" + model.High;
                    entity.IntVehicleType = model.VehicleType ?? 0;
                    entity.IntIsGPS = model.IsGPS;
                    entity.IntIsInsurance = model.IsInsurance;
                    entity.IntIsTemp = model.IsTemp;
                    entity.VarMaxLoad = model.MaxLoad??0M;
                    entity.VarMaxVolume = model.MaxVolume ?? 0;
                    entity.DteManufacture = model.Manufacture;
                    entity.DteValid = model.ValidDate ?? DateTime.MaxValue;
                }

                int flag = context.SaveChanges();
                if (picture != null)
                {
                    SaveImage(context, entity.IntVehicleID, picture);
                }
                if (flag >= 0)
                {
                    str = "1";
                }
                else
                {
                    str = "保存失败";
                }
            }
            return str;
        }


        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        public VMVehiclePaging GetVehiclePager(SmLogisticVehicle search, int page, int rows)
        {
            VMVehiclePaging pager = new VMVehiclePaging();
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmLogisticVehicle>("ProcGetVehicleList @p0,@p1,@p2,@p3,@p4",
                        string.IsNullOrWhiteSpace(search.LicenseNum) ? "" : search.LicenseNum, search.state, user.IntUserID, page, rows);

                    pager.total = context.Database.SqlQuery<int>("ProcGetVehicleListCount @p0,@p1,@p2",
                        string.IsNullOrWhiteSpace(search.LicenseNum) ? "" : search.LicenseNum, search.state, user.IntUserID).FirstOrDefault();

                    pager.rows = list.Select(p => new VmLogisticVehicle
                        {
                            EncriptID = Security.Encrypt(p.EncriptID),
                            LicenseNum = p.LicenseNum,
                            StrVehicleType = p.StrVehicleType,
                            VehicleSize = p.VehicleSize,
                            MaxLoad = p.MaxLoad,
                            StrValidDate = Utils.GetDateTimeFormate(p.ValidDate ?? DateTime.Now)
                        }).ToList();
                }
            }
            return pager;
        }

        /// <summary>
        /// 得到统计车辆信息
        /// </summary>
        /// <param name="type"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public VmCountInfo GetVehicleInfoCount()
        {
            VmCountInfo count = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.CurrentUser(context.BaseUsers);
                if (user != null)
                {
                    var list = context.Database.SqlQuery<VmCountInfo>("ProcGetVehicleCountInfo @p0", user.IntUserID);
                    count = list.FirstOrDefault();
                }
            }
            return count;
        }

        /// <summary>
        /// 得到当前用户的所有车辆信息
        /// </summary>
        /// <returns></returns>
        public List<VmLogisticVehicle> GetCurrentUserVehicle()
        {
            List<VmLogisticVehicle> items = null;
            using (var context = new FaoB2BEntities())
            {
                var user = baseUserService.GetCurrentUserInfo(context);
                var entity = new LogisticVehicle();
                entity.IntCreateUserID = user.UserID;
                var entities = Many(context.LogisticVehicles, entity);
                items = entities.Where(p => p.IntFlag == 3&&p.DteValid>=DateTime.Now).ToList().Select(p => new VmLogisticVehicle
                {
                    EncriptID = p.IntVehicleID.ToString(),
                    LicenseNum = p.VarLicenseNum
                }).ToList<VmLogisticVehicle>();
            }
            return items;
        }

        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        public string VehicleBatch(int type, string chooses)
        {
            int flag = 0;
            using (var context = new FaoB2BEntities())
            {
                string[] IDs = chooses.Split(',');
                foreach (var i in IDs)
                {
                    int id = 0;
                    string strID = Security.Decrypt(i);
                    if (int.TryParse(strID, out id))
                    {
                        var entity = context.LogisticVehicles.Find(id);
                        if (entity != null)
                        {
                            if (type == 1)
                            {
                                entity.IntFlag = 0;
                            }
                            else if (type == 3 && entity.IntFlag == 1)
                            {
                                entity.IntFlag = 2;
                            }
                        }
                    }
                }
                flag = context.SaveChanges();
            }
            if (flag >= 0)
            {
                return "1";
            }
            return "0";
        }

        /// <summary>
        /// 得到审批信息
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        public VMVehiclePaging GetAuditingPager(SmLogisticVehicle sm, int page, int rows)
        {
            VMVehiclePaging pager = new VMVehiclePaging();
            using (var context = new FaoB2BEntities())
            {
                var list = context.Database.SqlQuery<VmLogisticVehicle>("ProcGetVehicleList @p0,@p1,@p2,@p3,@p4"
                    , string.IsNullOrWhiteSpace(sm.LicenseNum) ? "" : sm.LicenseNum, 2, 0,page, rows);

                pager.total = context.Database.SqlQuery<int>("ProcGetVehicleListCount @p0,@p1,@p2",
                    string.IsNullOrWhiteSpace(sm.LicenseNum) ? "" : sm.LicenseNum, 2, 0).FirstOrDefault();

                pager.rows = list.Select(p => new VmLogisticVehicle
                    {
                        EncriptID = Security.Encrypt(p.EncriptID),
                        LicenseNum = p.LicenseNum,
                        StrVehicleType = p.StrVehicleType,
                        VehicleSize = p.VehicleSize,
                        MaxLoad = p.MaxLoad,
                        StrValidDate = p.StrValidDate,
                        ValidDate = p.ValidDate,
                    }).ToList();
            }
            return pager;
        }

        /// <summary>
        /// 审批
        /// </summary>
        /// <param name="Encriptid"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        public string Auditing(string Encriptid, int Result)
        {
            string str = "未找到该信息";
            string strID = Security.Decrypt(Encriptid);
            int id = 0;
            if (!int.TryParse(strID, out id))
            {
                return str;
            }
            using (var context = new FaoB2BEntities())
            {
                var entity = context.LogisticVehicles.Find(id);
                if (entity != null)
                {
                    if (entity.IntFlag != 2)
                    {
                        str = "该信息不审批";
                    }
                    else
                    {
                        entity.IntFlag = Result;
                        int flag = context.SaveChanges();
                        if (flag >= 0)
                        {
                            str = "1";
                        }
                    }
                }
            }
            return str;
        }

        /// <summary>
        /// 检查车牌号是否存在
        /// </summary>
        /// <param name="LicenseNum"></param>
        /// <returns></returns>
        public bool CheckVehicle(string LicenseNum,string id)
        {
            int count = 0;
            using (var context = new FaoB2BEntities())
            {
                int IntVehicleID= Utils.ToInt(Security.Decrypt(id));
                
                if (IntVehicleID > 0)
                {
                    count = context.LogisticVehicles.Where(e => e.VarLicenseNum == LicenseNum && e.IntVehicleID != IntVehicleID && e.IntFlag > 0).Count();
                }
                else
                {
                    count = context.LogisticVehicles.Where(e => e.VarLicenseNum == LicenseNum && e.IntFlag > 0).Count();
                }
            
            }
            return count > 0;
        }

        #endregion

        #region 辅助方法

        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="infoID">对应的信息ID</param>
        /// <returns></returns>
        private void SaveImage(FaoB2BEntities context, int infoID, VmB2BInfoPicture picture)
        {
            int i = 0;
            int j = 1;
            while (true)
            {
                if (picture.PictureUrls[i] != "" || picture.PictureIDs[i] != "")
                {
                    int id = 0;
                    string strID = Security.Decrypt(picture.PictureIDs[i]);
                    int.TryParse(strID, out id);
                    if (SaveImage(context, picture.PictureUrls[i], picture.OriginalName[i], infoID, j, id))
                    {
                        j++;
                    }
                }
                i++;
                if (i > 2)
                {
                    break;
                }
            }

        }
        /// <summary>
        /// 保存图片信息
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="originalName"></param>
        /// <param name="infoID"></param>
        /// <param name="orderID"></param>
        /// <param name="imageID"></param>
        private bool SaveImage(FaoB2BEntities context, string fileName, string originalName, int infoID, int orderID, int imageID = 0)
        {
            bool flag = false;
            VmAttachment oldAtt = null;
            if (imageID != 0)
            {
                oldAtt = attachmentService.GetAttachmentByID(context, imageID.ToString());
            }
            if (fileName != "" && originalName != "")
            {
                VmAttachment attachment = new VmAttachment();
                attachment.BelongTable = 3;
                attachment.PK = infoID;
                attachment.FileName = originalName;
                attachment.Path = fileName;
                attachment.Descrip = "";
                attachment.Order = orderID;
                if (imageID == 0)
                {
                    attachmentService.AddAttachment(context, attachment);

                }
                else
                {
                    attachment.ID = imageID;
                    attachmentService.UpdateAttachment(context, attachment);
                }
                flag = true;
            }
            else if (fileName == "" && imageID != 0)
            {
                attachmentService.DeleteAttachment(context, imageID);
                flag = false;
            }
            else if (oldAtt != null && oldAtt.Order != orderID)
            {
                oldAtt.Order = orderID;
                attachmentService.UpdateAttachment(context, oldAtt);
                flag = true;
            }
            else if (fileName != "" && imageID != 0)
            {
                flag = true;
            }
            return flag;
        }

        #endregion

        #region 实现基础接口

        /// <summary>
        /// 添加一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string AddToEntity(LogisticVehicle entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 更新一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string ResetToEntity(LogisticVehicle entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 删除一个实体到EF中，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public string RemoveToEntitys(LogisticVehicle entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回一个视图实体，执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public LogisticVehicle One(IQueryable<LogisticVehicle> query, LogisticVehicle entity)
        {
            throw new Exception("没有实现");
        }

        /// <summary>
        /// 返回多个视图实体，不执行sql操作
        /// </summary>
        /// <param name="entity">将查询条件组织成实体传入</param>
        /// <returns></returns>
        public IQueryable<LogisticVehicle> Many(IQueryable<LogisticVehicle> query, LogisticVehicle entity)
        {
            var entities = query.Select(e => e);

            if (entity != null)
            {
                if (entity.IntCreateUserID != 0)
                {
                    entities = entities.Where(p => p.IntCreateUserID == entity.IntCreateUserID);
                }
            }

            entities = entities.Where(e => e.IntFlag != 0);

            return entities;
        }

        #endregion

    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Xml;
using System.Configuration;
using System.Data.SqlClient;

namespace Fao.Common
{
    public class SQLServerHelper
    {
        /// <summary>
        /// 创建分页SQL
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="primaryKey"></param>
        /// <param name="filter"></param>
        /// <param name="order"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public static string BuildPageSQL(string tableName, string primaryKey,
            string filter, int pageIndex, int pageSize)
        {
            int total = pageIndex * pageSize;
            string preString = "";
            if (pageIndex == 0)
            {
                preString = @"SELECT TOP {4} * FROM {0} WHERE 1=1 {2} ORDER BY {1} DESC";
            }
            else
            {
                preString = @"SELECT TOP {4} * FROM {0}                                  
                              WHERE ({1} <                                 
                              (SELECT MIN({1}) 
                               FROM (SELECT TOP {5} * FROM {0} 
                               WHERE 1=1 {2} ORDER BY {1} DESC) a)) {2}                                                           
                              ORDER BY {1} DESC";
            }
            string selectString = string.Format(preString, tableName, primaryKey,
                filter, pageIndex, pageSize, total);
            return selectString;
        }
    }
}

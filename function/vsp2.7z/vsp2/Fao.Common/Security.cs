﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Fao.Common
{
    /// <summary>
    /// created by：yzq 2013-01-24
    /// 提供加密解密通用类库
    /// </summary>
    public sealed class Security
    {

        #region aes加密，解密
        /// <summary>
        /// 获取密钥
        /// </summary>
        private static string Key
        {
            get { return @"1O2NB364YF56efca789oESb9d80Zae9M"; }
        }
        /// <summary>
        /// 获取向量
        /// </summary>
        private static string IV
        {
            get { return @"L123f45Ir6b78pkf"; }
        }

        /// <summary>
        /// 字符串加密 
        /// 失败返回string.empty
        /// </summary>
        /// <param name="str">待加密数据</param>
        /// <returns>加密后的数据</returns>
        public static string Encrypt(object str)
        {
            if (str == null)
            {
                return string.Empty;
            }
            string plainStr = str.ToString();
            byte[] bKey = Encoding.UTF8.GetBytes(Key);
            byte[] bIV = Encoding.UTF8.GetBytes(IV);
            byte[] byteArray = Encoding.UTF8.GetBytes(plainStr);
            string encrypt = string.Empty;
            Rijndael aes = Rijndael.Create();
            try
            {
                using (MemoryStream mStream = new MemoryStream())
                {
                    using (CryptoStream cStream = new CryptoStream(mStream, aes.CreateEncryptor(bKey, bIV), CryptoStreamMode.Write))
                    {
                        cStream.Write(byteArray, 0, byteArray.Length);
                        cStream.FlushFinalBlock();
                        encrypt = Convert.ToBase64String(mStream.ToArray());
                    }
                }
            }
            catch { }
            aes.Clear();

            return ReplaceUrlString(encrypt);
        }

        /// <summary>
        /// 字符串解密
        /// 失败返回string.empty
        /// </summary>
        /// <param name="str">待解密数据</param>
        /// <returns>解密成功后的数据</returns>
        public static string Decrypt(object str)
        {
            if (str == null)
            {
                return string.Empty;
            }
            string encryptStr = ReplaceNumberString(str.ToString());
            byte[] bKey = Encoding.UTF8.GetBytes(Key);
            byte[] bIV = Encoding.UTF8.GetBytes(IV);

            string decrypt = string.Empty;
            Rijndael aes = Rijndael.Create();
            try
            {
                byte[] byteArray = Convert.FromBase64String(encryptStr);
                using (MemoryStream mStream = new MemoryStream())
                {
                    using (CryptoStream cStream = new CryptoStream(mStream, aes.CreateDecryptor(bKey, bIV), CryptoStreamMode.Write))
                    {
                        cStream.Write(byteArray, 0, byteArray.Length);
                        cStream.FlushFinalBlock();
                        decrypt = Encoding.UTF8.GetString(mStream.ToArray());
                    }
                }
            }
            catch { }
            aes.Clear();
            return decrypt;
        }

        private static string ReplaceUrlString(string str)
        {
            var tempStr = str;

            tempStr = tempStr.Replace("/", "0123");
            tempStr = tempStr.Replace("+", "4567");

            return tempStr;
        }
        private static string ReplaceNumberString(string str)
        {
            var tempStr = str;

            tempStr = tempStr.Replace("0123", "/");
            tempStr = tempStr.Replace("4567", "+");

            return tempStr;
        }

        #endregion

        #region md5加密

        public static string MD5(string str)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                
            byte[] str1 = Encoding.UTF8.GetBytes(str);
            byte[] str2 = md5.ComputeHash(str1, 0, str1.Length);
            md5.Clear();
            (md5 as IDisposable).Dispose();
            return Convert.ToBase64String(str2);
        }

        #endregion

    }
}

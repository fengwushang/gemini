﻿using Fao.Log;
using System.Configuration;
using System.Net;
using System.Net.Mail;

namespace Fao.Common
{
    /// <summary>
    /// created by：chf 2013-01-29
    ///   邮件发送类
    /// </summary>
    public sealed class SendMail
    { 
        private static string REStmp = ConfigurationManager.AppSettings["Register_SmtpClient"];
        private static string REAddre = ConfigurationManager.AppSettings["Register_MailAddress"];
        private static string REpwd = ConfigurationManager.AppSettings["Register_MailPwd"];

        /// <summary>
        /// 发邮件方法
        /// 注意：公司屏蔽了相关端口、协议，将来使用时还需测试
        /// </summary>
        /// <param name="mContent"></param>
        public static void SEmail(MailContent mContent)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress(REAddre);
                mail.To.Add(mContent.emailAdd);
                mail.Subject = mContent.emailSub;
                mail.Body = mContent.EmailBody;
                mail.SubjectEncoding = System.Text.Encoding.UTF8;
                mail.BodyEncoding = System.Text.Encoding.UTF8;
                mail.Priority = System.Net.Mail.MailPriority.High;
                mail.IsBodyHtml = true;

                SmtpClient smtp = new SmtpClient(REStmp);
                //smtp.UseDefaultCredentials = true;
                //smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                //smtp.EnableSsl = true;
                smtp.Credentials = new NetworkCredential(REAddre, REpwd);
                smtp.Send(mail);
            }
            catch (System.Exception ex)
            {
                LogHelper.LogExceRun("发送邮件出错！", ex);
            }
        }

        public class MailContent
        {
            public string emailAdd { get; set; }
            public string emailSub { get; set; }
            public string EmailBody { get; set; }
        }

    }
}

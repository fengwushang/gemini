﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Web;
using System.Data;
using System.Reflection;

namespace Fao.Common
{
    /// <summary>
    /// created by：yzq 2013-01-17
    /// 通用类库，提供最基础的通用函数处理。
    /// 包括：转换类型，读取配置节点appSettings
    /// </summary>
    public sealed class Utils
    {
        /// <summary>
        /// 获取web.config文件appsetting中的值
        /// </summary>
        /// <param name="name">key</param>
        /// <returns>value</returns>
        public static string GetAppValueByName(string name)
        {
            if (string.IsNullOrEmpty(ConfigurationManager.AppSettings[name]))
            {
                throw new Exception("@读取web.config异常：请检查名称(" + name + ")是否正确！");
            }

            return ConfigurationManager.AppSettings[name];
        }

        /// <summary>
        /// 将字符串转化为int，转化失败，返回int最小值
        /// </summary>
        /// <param name="intStr"></param>
        /// <returns></returns>
        public static int ToInt(string intStr)
        {
            int rv = int.MinValue;

            int.TryParse(intStr, out rv);

            return rv;
        }

        /// <summary>
        /// 返回对象的json字符串格式。
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string ToJsonStr(object obj)
        {
            return JsonConvert.SerializeObject(obj);
        }


        /// <summary>
        /// 返回日期类型
        /// 如果转化失败，返回默认值
        /// </summary>
        /// <param name="datetimeStr">待检查数据</param>
        /// <param name="defaultDate">默认值</param>
        /// <returns></returns>
        public static DateTime ToDate(string datetimeStr, DateTime defaultDate)
        {
            DateTime rv = defaultDate;

            DateTime.TryParse(datetimeStr, out rv);

            return rv;

        }

        /// <summary>
        /// 返回字符串类型，格式：“yyyy-MM-dd”
        /// 如果转化失败，返回当前年月日
        /// </summary>
        /// <param name="datetimeStr">待检查数据</param> 
        /// <returns></returns>
        public static string ToDateFormate(string datetimeStr)
        {
            DateTime rv = System.DateTime.Now;
            DateTime.TryParse(datetimeStr, out rv); 
            return rv.ToString("yyyy-MM-dd"); 
        }

        /// <summary>
        /// 返回日期类型的简短格式化字符串“yyyy-MM-dd”
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static string GetDateFormate(DateTime dt)
        {
            if (dt == null || dt == DateTime.MinValue)
            {
                return string.Empty;
            }
            if (dt.Year == 9999)
            {
                return "永久有效";
            }
            return dt.ToString("yyyy-MM-dd");

        }

        /// <summary>
        /// 返回日期类型格式化字符串“yyyy-MM-dd HH:mm:ss”
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static string GetDateTimeFormate(DateTime dt)
        {
            if (dt.Year == 9999 || dt.Year == 1)
            {
                return "永久有效";
            }
            if (dt == null || dt== DateTime.MinValue)
            {
                return string.Empty;
            }

            return dt.ToString("yyyy-MM-dd HH:mm:ss");

        }

        /// <summary>
        /// 返回日期类型格式化字符串“yyyy-MM-dd HH:mm”
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static string GetDateWithHMFormate(DateTime dt)
        {
            if (dt.Year == 9999)
            {
                return "永久有效";
            }
            if (dt == null || dt == DateTime.MinValue)
            {
                return string.Empty;
            }

            return dt.ToString("yyyy-MM-dd HH:mm");

        }

        /// <summary>
        /// 返回日期是上午，下午，还是晚上
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static string GetDateMAN(DateTime dt)
        {
            if (dt == null || dt == DateTime.MinValue)
            {
                return string.Empty;
            }

            var hh = dt.Hour;

            if(hh >= 6 && hh <=12)
            {
                return "上午";
            }
            if (hh >= 13 && hh <= 18)
            {
                return "下午";
            }
            if (hh >= 19 && hh <= 24)
            {
                return "晚间";
            }

            return "午夜";
        }

        /// <summary>
        /// 截取字符串函数
        /// </summary>
        /// <param name="str">所要截取的字符串</param>
        /// <param name="num">截取字符串的长度</param>
        /// <returns></returns>
        public static string SubString(string str, int num)
        {
            if (string.IsNullOrEmpty(str))
            {
                return string.Empty;
            }

            string outstr = string.Empty;
            int n = 0;
            foreach (char ch in str)
            {
                n += Encoding.Default.GetByteCount(ch.ToString());
                if (n > num)
                {
                    break;
                }
                else
                {
                    outstr += ch;
                }
            }
            return outstr;
        }
        /// <summary>
        /// 截取字符串函数
        /// </summary>
        /// <param name="str">所要截取的字符串</param>
        /// <param name="num">截取字符串的长度</param>
        /// <param name="lastStr">截取字符串后省略部分的字符串</param>
        /// <returns></returns>
        public static string SubString(string str, int num, string lastStr)
        {
            return (str.Length > num) ? str.Substring(0, num) + lastStr : str;
        }

         
        /// <summary>
        /// 用“,”号，分割字符串，并返回字符串数组。
        /// </summary>
        /// <param name="values"></param>
        /// <returns>参数为空，则返回长度为0的数组</returns>
        public static string[] Split(string values)
        {
            if (string.IsNullOrEmpty(values))
            {
                return new string[0];
            }

            var strArray = values.Split(',');

            return strArray;
        }

        /// <summary>
        /// 获取当前请求IP地址
        /// </summary>
        /// <returns></returns>
        public static string CurrentRequestIP()
        {
            string result = String.Empty;
            result = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (null == result || result == String.Empty)
            {
                result = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
            if (null == result || result == String.Empty)
            {
                result = HttpContext.Current.Request.UserHostAddress;
            }
            if (null == result || result == String.Empty)
            {
                return "0.0.0.0";
            }
            if ("::1" == result)
            {
                return "127.0.0.1";
            }
            return result;
        }

        /// <summary>将IP地址格式化为整数型</summary>
        /// <param name="ip"></param>
        /// <returns></returns>
        public static long IpToInt(string ip)
        {
            char[] dot = new char[] { '.' };
            string[] ipArr = ip.Split(dot);
            if (ipArr.Length == 3) ip = ip + ".0";
            ipArr = ip.Split(dot); 
            long ip_Int = 0;
            long p1 = long.Parse(ipArr[0]) * 256 * 256 * 256;
            long p2 = long.Parse(ipArr[1]) * 256 * 256;
            long p3 = long.Parse(ipArr[2]) * 256; 
            long p4 = long.Parse(ipArr[3]);
            ip_Int = p1 + p2 + p3 + p4; 
            return ip_Int;
        }

        /// <summary>
        /// datatable to list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static List<T> List<T>(DataTable dt)
        {
            var list = new List<T>();
            Type t = typeof(T);
            var plist = new List<PropertyInfo>(typeof(T).GetProperties());

            foreach (DataRow item in dt.Rows)
            {
                T s = System.Activator.CreateInstance<T>();
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    PropertyInfo info = plist.Find(p => p.Name == dt.Columns[i].ColumnName);
                    if (info != null)
                    {
                        if (!Convert.IsDBNull(item[i]))
                        {
                            info.SetValue(s, item[i], null);
                        }
                    }
                }
                list.Add(s);
            }
            return list;
        }

        /// <summary>
        /// 处理小数字符串末尾0的部分,有逗号格式化。
        /// 非小数字符串，返回原字符串
        /// </summary>
        /// <param name="decString">小数字符串</param>
        /// <returns></returns>
        public static string DecimalFormat(string decString)
        {
            decimal temp = decimal.Zero;
            if (decimal.TryParse(decString, out temp))
            {
                string value = decimal.Parse(decString).ToString("#,###.#######");
                if (string.IsNullOrEmpty(value))
                {
                    value = "0";
                }
                if (value.IndexOf('.') == 0)
                {
                    value = "0" + value;
                }
                return value;
            }
            else
            {
                return decString;
            }
        }

        /// <summary>
        /// 处理小数字符串末尾0的部分。
        /// 非小数字符串，返回原字符串
        /// </summary>
        /// <param name="decString">小数字符串</param>
        /// <returns></returns>
        public static string DecimalFormat2(string decString)
        {
            decimal temp = decimal.Zero;
            if (decimal.TryParse(decString, out temp))
            {
                string value = decimal.Parse(decString).ToString("####.#######");
                if (string.IsNullOrEmpty(value))
                {
                    value = "0";
                }
                if (value.IndexOf('.') == 0)
                {
                    value = "0" + value;
                }
                return value;
            }
            else
            {
                return decString;
            }
        }
    }
}

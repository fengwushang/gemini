﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System;
using Microsoft.ApplicationBlocks.Data;



namespace Fao.Common
{
    public sealed class SQLPlus
    {
        /// <summary>
        /// 链接字符串
        /// </summary>
        public static string DefaultConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["FaoSMSDB"].ToString();
            }
        }
        /// <summary>
        /// BulkCopy
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="table"></param>
        /// <param name="tbName"></param>
        public static void BulkCopy(DataTable table, string destinationtablename)
        {
            using (SqlConnection connection = new SqlConnection(DefaultConnectionString))
            {
                connection.Open();
                SqlBulkCopy copy = new SqlBulkCopy(connection);
                try
                {
                    copy.DestinationTableName = destinationtablename;
                    copy.WriteToServer(table);
                }
                catch (SqlException e)
                {
                    throw e;
                }
                finally
                {
                    copy.Close();
                    connection.Close();
                }
            }
        }
        /// <summary>
        /// 执行返回一个DataSet但不带参数的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <returns>SQL语句执行返回的一个DataTable</returns>
        public static DataSet ExecuteDataSet(CommandType commandType, StringBuilder commandText, params SqlParameter[] commandParameters)
        {
            DataSet ds = new DataSet();
            try
            {
                ds = SqlHelper.ExecuteDataset(DefaultConnectionString, commandType, commandText.ToString(), commandParameters);
            }
            catch (Exception e)
            {
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteDataTable(2个参数)]" + e.StackTrace, "", "", "", "");
            }
            return ds;
        }
        
        /// <summary>
        /// 执行返回一个DataSet但不带参数的SQL语句
        /// </summary>
        ///<param name="ConnectionString">链接字符串</param>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <returns>SQL语句执行返回的一个DataTable</returns>
        public static DataSet ExecuteDataSet(string ConnectionString,CommandType commandType, StringBuilder commandText, params SqlParameter[] commandParameters)
        {
            DataSet ds = new DataSet();
            try
            {
                ds = SqlHelper.ExecuteDataset(ConnectionString, commandType, commandText.ToString(), commandParameters);
            }
            catch (Exception e)
            {
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteDataTable(2个参数)]" + e.StackTrace, "", "", "", "");
            }
            return ds;
        }
        /// <summary>
        /// 执行存储过程
        /// </summary>
        /// <param name="storedProcName">存储过程名</param>
        /// <param name="parameters">存储过程参数</param>
        /// <param name="tableName">DataSet结果中的表名</param>
        /// <returns>DataSet</returns>
        public static DataSet RunProcedure(string storedProcName, IDataParameter[] parameters, string tableName)
        {
            using (SqlConnection connection = new SqlConnection(DefaultConnectionString))
            {
                DataSet dataSet = new DataSet();
                connection.Open();
                SqlDataAdapter sqlDA = new SqlDataAdapter();
                sqlDA.SelectCommand = BuildQueryCommand(connection, storedProcName, parameters);
                sqlDA.Fill(dataSet, tableName);
                connection.Close();
                return dataSet;
            }
        }

        /// <summary>
        /// 构建 SqlCommand 对象(用来返回一个结果集，而不是一个整数值)
        /// </summary>
        /// <param name="connection">数据库连接</param>
        /// <param name="storedProcName">存储过程名</param>
        /// <param name="parameters">存储过程参数</param>
        /// <returns>SqlCommand</returns>
        private static SqlCommand BuildQueryCommand(SqlConnection connection, string storedProcName, IDataParameter[] parameters)
        {
            SqlCommand command = new SqlCommand(storedProcName, connection);
            command.CommandType = CommandType.StoredProcedure;
            foreach (SqlParameter parameter in parameters)
            {
                if (parameter != null)
                {
                    // 检查未分配值的输出参数,将其分配以DBNull.Value.
                    if ((parameter.Direction == ParameterDirection.InputOutput || parameter.Direction == ParameterDirection.Input) &&
                        (parameter.Value == null))
                    {
                        parameter.Value = DBNull.Value;
                    }
                    command.Parameters.Add(parameter);
                }
            }

            return command;
        }


    }
}

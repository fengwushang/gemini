﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Common
{
    public static class ImageHelper
    {
        /// <summary> 
        /// 根据路径读取文件，支持远程文件，本地文件 
        /// </summary> 
        /// <param name="path"></param> 
        /// <returns></returns> 
        private static  System.Drawing.Image GetImage(string path)
        {
            if (path.StartsWith("http"))
            {
                System.Net.WebRequest request = System.Net.WebRequest.Create(path);
                request.Timeout = 10000;
                System.Net.HttpWebResponse httpresponse = (System.Net.HttpWebResponse)request.GetResponse();
                Stream s = httpresponse.GetResponseStream();

                return System.Drawing.Image.FromStream(s);
            }
            else
            {
                return System.Drawing.Image.FromFile(path);
            }
        }
        /// <summary>创建规定大小的图像 
        /// </summary> 
        /// <param name="width">生成图像的宽度</param> 
        /// <param name="height">生成图像的高度</param> 
        /// <param name="oPath">源图像绝对路径</param> 
        /// <param name="tPath">生成缩略图的路径</param>
        public static  void CreateImage(int width, int height, string oPath,string tPath)
        {
            Bitmap originalBmp = null;// new Bitmap(oPath); 
            originalBmp = new Bitmap(GetImage(oPath));
            // 源图像在新图像中的位置 
            int left, top;


            if (originalBmp.Width <= width && originalBmp.Height <= height)
            {
                // 原图像的宽度和高度都小于生成的图片大小 
                left = (int)Math.Round((decimal)(width - originalBmp.Width) / 2);
                top = (int)Math.Round((decimal)(height - originalBmp.Height) / 2);

                
                // 最终生成的图像 
                Bitmap bmpOut = new Bitmap(width, height);
                using (Graphics graphics = Graphics.FromImage(bmpOut))
                {
                    // 设置高质量插值法 
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    // 清空画布并以白色背景色填充 
                    graphics.Clear(Color.White);
                    //加上边框 
                    //Pen pen = new Pen(ColorTranslator.FromHtml("#cccccc")); 
                    // graphics.DrawRectangle(pen, 0, 0, width - 1, height - 1); 
                    // 把源图画到新的画布上 
                    graphics.DrawImage(originalBmp, left, top);
                }
                // bmpOut.Save(tPath);//保存为文件，tpath 为要保存的路径 
                bmpOut.Save(tPath);
                return;
            }


            // 新图片的宽度和高度，如400*200的图像，想要生成160*120的图且不变形， 
            // 那么生成的图像应该是160*80，然后再把160*80的图像画到160*120的画布上 
            int newWidth, newHeight;
            if (width * originalBmp.Height < height * originalBmp.Width)
            {
                newWidth = width;
                newHeight = (int)Math.Round((decimal)originalBmp.Height * width / originalBmp.Width);
                // 缩放成宽度跟预定义的宽度相同的，即left=0，计算top 
                left = 0;
                top = (int)Math.Round((decimal)(height - newHeight) / 2);
            }
            else
            {
                newWidth = (int)Math.Round((decimal)originalBmp.Width * height / originalBmp.Height);
                newHeight = height;
                // 缩放成高度跟预定义的高度相同的，即top=0，计算left 
                left = (int)Math.Round((decimal)(width - newWidth) / 2);
                top = 0;
            }


            // 生成按比例缩放的图，如：160*80的图 
            Bitmap bmpOut2 = new Bitmap(newWidth, newHeight);
            using (Graphics graphics = Graphics.FromImage(bmpOut2))
            {
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.FillRectangle(Brushes.White, 0, 0, newWidth, newHeight);
                graphics.DrawImage(originalBmp, 0, 0, newWidth, newHeight);
            }
            // 再把该图画到预先定义的宽高的画布上，如160*120 
            Bitmap lastbmp = new Bitmap(width, height);
            using (Graphics graphics = Graphics.FromImage(lastbmp))
            {
                // 设置高质量插值法 
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                // 清空画布并以白色背景色填充 
                graphics.Clear(Color.White);
                //加上边框 
                //Pen pen = new Pen(ColorTranslator.FromHtml("#cccccc")); 
                //graphics.DrawRectangle(pen, 0, 0, width - 1, height - 1); 
                // 把源图画到新的画布上 
                graphics.DrawImage(bmpOut2, left, top);
            }
            // lastbmp.Save(tPath);//保存为文件，tpath 为要保存的路径 
            lastbmp.Save(tPath);
            lastbmp.Dispose();
        }


        /// <summary>
        /// 在图片上添加水印文字
        /// </summary>
        /// <param name="sourcePicture">源图片文件(文件名，不包括路径)</param>
        /// <param name="waterWords">需要添加到图片上的文字</param>
        /// <param name="alpha">透明度</param>
        /// <param name="position">位置</param>
        /// <param name="PicturePath">文件路径</param>
        /// <returns></returns>
        public static string DrawWords(string sourcePicture,string waterWords,float alpha,ImagePosition position,string PicturePath,string targetName)
        {
            //
            // 判断参数是否有效
            //
            if (sourcePicture == string.Empty || waterWords == string.Empty || alpha == 0.0 || PicturePath == string.Empty)
            {
                return sourcePicture;
            }
            //
            // 源图片全路径
            //
            if (PicturePath.Substring(PicturePath.Length - 1, 1) != "\\")
                PicturePath += "\\";
            string sourcePictureName = PicturePath + sourcePicture;
            string fileExtension = System.IO.Path.GetExtension(sourcePictureName).ToLower();

            //
            // 判断文件是否存在,以及文件名是否正确
            //
            if (System.IO.File.Exists(sourcePictureName) == false || (
                fileExtension != ".gif" &&
                fileExtension != ".jpg" &&
                fileExtension != ".png"&&
                fileExtension!=".bmp"&&
                fileExtension!=".jpeg"))
            {
                return sourcePicture;
            }

            //
            // 目标图片名称及全路径
            //
            string targetImage = sourcePictureName.Replace(sourcePicture,targetName)+".jpg";

            //创建一个图片对象用来装载要被添加水印的图片
            Image imgPhoto = Image.FromFile(sourcePictureName);

            //获取图片的宽和高
            int phWidth = imgPhoto.Width;
            int phHeight = imgPhoto.Height;

            //
            //建立一个bitmap，和我们需要加水印的图片一样大小
            Bitmap bmPhoto = new Bitmap(phWidth, phHeight, PixelFormat.Format24bppRgb);

            //SetResolution：设置此 Bitmap 的分辨率
            //这里直接将我们需要添加水印的图片的分辨率赋给了bitmap
            bmPhoto.SetResolution(imgPhoto.HorizontalResolution, imgPhoto.VerticalResolution);

            //Graphics：封装一个 GDI+ 绘图图面。
            Graphics grPhoto = Graphics.FromImage(bmPhoto);

            //设置图形的品质
            grPhoto.SmoothingMode = SmoothingMode.AntiAlias;

            //将我们要添加水印的图片按照原始大小描绘（复制）到图形中
            grPhoto.DrawImage(
             imgPhoto,                                           //   要添加水印的图片
             new Rectangle(0, 0, phWidth, phHeight), // 根据要添加的水印图片的宽和高
             0,                                                     // X方向从0点开始描绘
             0,                                                     // Y方向 
             phWidth,                                            // X方向描绘长度
             phHeight,                                           // Y方向描绘长度
             GraphicsUnit.Pixel);                              // 描绘的单位，这里用的是像素

            //根据图片的大小我们来确定添加上去的文字的大小
            //在这里我们定义一个数组来确定
            int[] sizes = new int[] { 16, 14, 12, 10, 8, 6, 4 };

            //字体
            Font crFont = null;
            //矩形的宽度和高度，SizeF有三个属性，分别为Height高，width宽，IsEmpty是否为空
            SizeF crSize = new SizeF();

            //利用一个循环语句来选择我们要添加文字的型号
            //直到它的长度比图片的宽度小
            for (int i = 0; i < 7; i++)
            {
                crFont = new Font("arial", sizes[i], FontStyle.Bold);

                //测量用指定的 Font 对象绘制并用指定的 StringFormat 对象格式化的指定字符串。
                crSize = grPhoto.MeasureString(waterWords, crFont);

                // ushort 关键字表示一种整数数据类型
                if ((ushort)crSize.Width < (ushort)phWidth)
                    break;
            }

            //截边5%的距离，定义文字显示(由于不同的图片显示的高和宽不同，所以按百分比截取)
            int yPixlesFromBottom = (int)(phHeight * .05);

            //定义在图片上文字的位置
            float wmHeight = crSize.Height;
            float wmWidth = crSize.Width;

            float xPosOfWm;
            float yPosOfWm;

            switch (position)
            {
                case ImagePosition.BottomMiddle:
                    xPosOfWm = phWidth / 2;
                    yPosOfWm = phHeight - wmHeight - 10;
                    break;
                case ImagePosition.Center:
                    xPosOfWm = phWidth / 2;
                    yPosOfWm = phHeight / 2;
                    break;
                case ImagePosition.LeftBottom:
                    xPosOfWm = wmWidth;
                    yPosOfWm = phHeight - wmHeight - 10;
                    break;
                case ImagePosition.LeftTop:
                    xPosOfWm = wmWidth / 2;
                    yPosOfWm = wmHeight / 2;
                    break;
                case ImagePosition.RightTop:
                    xPosOfWm = phWidth - wmWidth - 10;
                    yPosOfWm = wmHeight;
                    break;
                case ImagePosition.RigthBottom:
                    xPosOfWm = phWidth - wmWidth - 10;
                    yPosOfWm = phHeight - wmHeight - 10;
                    break;
                case ImagePosition.TopMiddle:
                    xPosOfWm = phWidth / 2;
                    yPosOfWm = wmWidth;
                    break;
                default:
                    xPosOfWm = wmWidth;
                    yPosOfWm = phHeight - wmHeight - 10;
                    break;
            }

            //封装文本布局信息（如对齐、文字方向和 Tab 停靠位），显示操作（如省略号插入和国家标准 (National) 数字替换）和 OpenType 功能。
            StringFormat StrFormat = new StringFormat();

            //定义需要印的文字居中对齐
            StrFormat.Alignment = StringAlignment.Center;

            //SolidBrush:定义单色画笔。画笔用于填充图形形状，如矩形、椭圆、扇形、多边形和封闭路径。
            //这个画笔为描绘阴影的画笔，呈灰色
            int m_alpha = Convert.ToInt32(256 * alpha);
            SolidBrush semiTransBrush2 = new SolidBrush(Color.FromArgb(m_alpha, 0, 0, 0));

            //描绘文字信息，这个图层向右和向下偏移一个像素，表示阴影效果
            //DrawString 在指定矩形并且用指定的 Brush 和 Font 对象绘制指定的文本字符串。
            grPhoto.DrawString(waterWords,                                    //string of text
                                       crFont,                                         //font
                                       semiTransBrush2,                            //Brush
                                       new PointF(xPosOfWm + 1, yPosOfWm + 1), //Position
                                       StrFormat);

            //从四个 ARGB 分量（alpha、红色、绿色和蓝色）值创建 Color 结构，这里设置透明度为153
            //这个画笔为描绘正式文字的笔刷，呈白色
            SolidBrush semiTransBrush = new SolidBrush(Color.FromArgb(153, 255, 255, 255));

            //第二次绘制这个图形，建立在第一次描绘的基础上
            grPhoto.DrawString(waterWords,                 //string of text
                                       crFont,                                   //font
                                       semiTransBrush,                           //Brush
                                       new PointF(xPosOfWm, yPosOfWm), //Position
                                       StrFormat);

            //imgPhoto是我们建立的用来装载最终图形的Image对象
            //bmPhoto是我们用来制作图形的容器，为Bitmap对象
            imgPhoto = bmPhoto;
            //释放资源，将定义的Graphics实例grPhoto释放，grPhoto功德圆满
            grPhoto.Dispose();

            //将grPhoto保存
            imgPhoto.Save(targetImage, ImageFormat.Jpeg);
            imgPhoto.Dispose();

            return targetImage.Replace(PicturePath, "");
        }

    }
    public enum ImagePosition
    {
        LeftTop,        //左上
        LeftBottom,    //左下
        RightTop,       //右上
        RigthBottom, //右下
        TopMiddle,     //顶部居中
        BottomMiddle, //底部居中
        Center           //中心
    }
}

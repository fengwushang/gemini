﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

namespace Fao.Common
{
    /// <summary>
    /// created by：yzq 2013-01-21
    /// 通用类库，提供Html级别的处理函数
    /// </summary>
    public class HtmlHelper
    {
        #region cookie操作
        /// <summary>
        /// 清除指定Cookie
        /// </summary>
        /// <param name="cookiename">cookiename</param>
        public static void ClearCookie(string cookiename)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[cookiename];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddYears(-3);
                cookie.Value = string.Empty;
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }
        /// <summary>
        /// 获取指定Cookie值
        /// </summary>
        /// <param name="cookiename">cookiename</param>
        /// <returns></returns>
        public static string GetCookieValue(string cookiename)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[cookiename];
            string str = string.Empty;
            if (cookie != null)
            {
                str = cookie.Value;

            }
            return str;
        }
        /// <summary>
        /// 添加一个Cookie（7*24小时过期）
        /// </summary>
        /// <param name="cookiename"></param>
        /// <param name="cookievalue"></param>
        public static void SetCookie(string cookiename, string cookievalue)
        {
            SetCookie(cookiename, cookievalue, DateTime.Now.AddDays(7));
        }
        /// <summary>
        /// 添加一个Cookie
        /// </summary>
        /// <param name="cookiename">cookie名</param>
        /// <param name="cookievalue">cookie值</param>
        /// <param name="expires">过期时间 DateTime</param>
        public static void SetCookie(string cookiename, string cookievalue, DateTime expires)
        {
            if (!string.IsNullOrEmpty(GetCookieValue(cookiename)))
            {
                HttpContext.Current.Response.Cookies.Remove(cookiename);
            }
            HttpCookie cookie = new HttpCookie(cookiename)
            {
                Value = cookievalue,
                Expires = expires
            };
            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        #endregion



        /// <summary>
        /// 过滤字符串中的html代码
        /// </summary>
        /// <param name="html"></param>
        /// <returns>返回过滤之后的字符串</returns>
        public static string LostHTML(string html)
        {
            string Re_Str = string.Empty;
            if (!string.IsNullOrEmpty(html))
            {

                string Pattern = "<\\/*[^<>]*>";
                Re_Str = Regex.Replace(html, Pattern, "");
            }
            return (Re_Str.Replace("\\r\\n", "")).Replace("\\r", "");
        }

        /// <summary>
        /// 为html代码去除Fao命名空间限制，
        /// 返回给用户一个干净的html代码
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string RemoveFaoNamespace(string html)
        {
            string tempStr = string.Empty;

            tempStr = Regex.Replace(html, " xmlns:fao=\"fao\"", string.Empty, RegexOptions.IgnoreCase);

            return tempStr;
        }

        /// <summary>
        /// 为html代码添加Fao命名空间限制，
        /// 利用xdocument解析模板标签的时候必须用到。
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string AppendFaoNamespace(string html)
        {
            string tempStr = string.Empty;

            if (!Regex.IsMatch(html, " xmlns:fao=\"fao\"", RegexOptions.IgnoreCase))
            {
                tempStr = Regex.Replace(html, "<html ", "<html xmlns:fao=\"fao\" ", RegexOptions.IgnoreCase);
            }

            return tempStr;
        }


        /// <summary>
        /// 过滤sql 字符串
        /// </summary>
        /// <param name="sInput"></param>
        /// <returns></returns>
        public static string SqlFilter(string sInput)
        {
            if (sInput == null || sInput == "")
                return null;
            string sInput1 = sInput.ToLower();
            string output = sInput;
            string pattern = @"*|and|exec|insert|select|delete|update|count|master|truncate|declare|char(|mid(|chr(|'";
            if (Regex.Match(sInput1, Regex.Escape(pattern), RegexOptions.Compiled | RegexOptions.IgnoreCase).Success)
            {
                throw new Exception("@字符串中含有非法字符!");
            }
            else
            {
                output = output.Replace("'", "''");
            }
            return output;
        }

        /// <summary>
        /// 把一段文字中的联系方式替换为********  替换的内容包括 电子邮箱 手机号码  座机号码
        /// </summary>
        /// <param name="sInput"></param>
        /// <returns></returns>
        public static string ContactWayFilter(string sInput)
        {
            string reg = @"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}|1[0-9]{10}|(([0-9]{3,4}-)?[0-9]{7,8})";
            Regex regex = new Regex(reg); // 定义表达式
            return regex.Replace(sInput, " ******** ");
        }

        /// <summary>
        /// 获取url中query参数，并转化为键值对返回。
        /// 如果字符串中不包含“=”则认为是不合适的query返回null
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public static NameValueCollection GetUrlQueryCollection(string param)
        {
            if (string.IsNullOrEmpty(param) || !param.Contains('='))
            {
                return null;

            }

            var nvc = new NameValueCollection();

            var tempNV = new string[2];
            var paramList = param.Split('&');
            foreach (var p in paramList)
            {
                tempNV = p.Split('=');
                nvc.Add(tempNV[0], tempNV[1]);
            }

            return nvc;

        }

        public static string GetImgName(int type)
        {
            var rv = string.Empty;
            switch (type)
            {
                case 1:
                    rv = "inquiry";
                    break;
                case 2:
                    rv = "Quote";
                    break;
                default:
                    rv = "Msg";
                    break;
            }

            return rv;
        }
    }



}

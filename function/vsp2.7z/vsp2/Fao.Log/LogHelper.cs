﻿using log4net;
using log4net.Config;
using System;
using System.IO;
using System.Web;

namespace Fao.Log
{
    /// <summary>
    /// created by：chf 2013-01-23
    /// 使用Log4Net将异常信息记录到文件中
    /// </summary>
    public sealed class LogHelper
    {

        # region log4Net 的配置
        ///// <summary>
        ///// LOGINFO 
        ///// </summary>
        private const string LOG_INFO = "logInfo";

        /// <summary>
        /// LOGERROR
        /// </summary>
        private const string LOG_ERROR = "logError";

        ///// <summary>
        ///// LOGVISIT
        ///// </summary>
        //public const string LOG_VISIT = "logVisit";

        /// <summary>
        /// LOGSQL
        /// </summary>
        private const string LOG_SQL = "logSQL";

        /// <summary>
        /// 日志配置
        /// </summary>
        private static readonly string LOG_CONFIG = HttpRuntime.AppDomainAppPath + "/Config/Log4net.config";

        #endregion

        #region Properties属性

        /// <summary>
        /// 错误日志
        /// </summary>
        private static ILog logError = LogManager.GetLogger(LOG_ERROR);

        /// <summary>
        /// 数据库日志
        /// </summary>
        private static ILog logSQL = LogManager.GetLogger(LOG_SQL);

        /// <summary>
        /// 数据库日志
        /// </summary>
        private static ILog logInfo = LogManager.GetLogger(LOG_INFO);

        /// <summary>
        /// 是否配置
        /// </summary>
        private static bool isConfig = false;

        #endregion

        #region Methods方法

        /// <summary>
        /// 日志配置初始化
        /// </summary>
        private static void SetConfig()
        {
            SetConfig(LOG_CONFIG);
        }

        /// <summary>
        /// 根据文件配置日志
        /// </summary>
        /// <param name="configFile">配置文件路径</param>
        private static void SetConfig(string configFile)
        {
            FileInfo file = new FileInfo(configFile);
            XmlConfigurator.Configure(file);
            isConfig = true;
        }

        /// <summary>
        /// 写入运行日志
        /// </summary>
        /// <param name="info">信息</param> 
        public static void LogExceCommon(string info)
        {
            if (!isConfig)
            {
                SetConfig();
            }
            if (logInfo.IsErrorEnabled)
            {
                logInfo.Error(info);
            }
        }

        /// <summary>
        /// 写入错误日志
        /// </summary>
        /// <param name="info">错误信息</param>
        /// <param name="ex">错误</param>
        public static void LogExceRun(string info, Exception ex)
        {
            if (!isConfig)
            {
                SetConfig();
            }
            if (logError.IsErrorEnabled)
            {
                logError.Error(info, ex);
            }
        }

        /// <summary>
        /// 写入数据库日志
        /// </summary>
        /// <param name="info">错误信息</param>
        /// <param name="ex">错误</param>
        public static void LogExceDB(string info, Exception ex)
        {
            if (!isConfig)
            {
                SetConfig();
            }
            if (logSQL.IsInfoEnabled)
            {
                logSQL.Info(info, ex);
            }
        }

        #endregion
    }
}

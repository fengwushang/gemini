﻿using Fao.Common;
using Fao.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Service
{
    public class Entity<T> where T : class
    {
        ///// <summary>
        ///// created by：yzq 2013-01-17
        ///// 当前数据操作上下文，Current对象处理不了的情况下可以用。
        ///// </summary>
        //protected DbContext Context
        //{
        //    get
        //    {

        //        var dbClasses = typeof(T).Assembly.GetTypes();
        //        var dbName = dbClasses
        //            .Where(db => db.IsClass && db.BaseType.Equals(typeof(DbContext)))
        //            .Select(db => db.Name).FirstOrDefault();

        //        return EFFactory.GetEF(dbName);

        //    }
        //    set {
                
        //    }
        //}

        ///// <summary>
        ///// 当前操作表的集合，用来实现数据增、删、改、查的实际对象。
        ///// </summary>
        //protected DbSet<T> Current
        //{
        //    get
        //    {

        //        return Context.Set<T>();

        //    }
        //}

        ///// <summary>
        ///// 如果站点配置为，获取新实例Context，则需要用该函数释放Context。
        ///// web.config中"EFmode = New"
        ///// </summary>
        //protected void CloseContext()
        //{
        //    if (Context != null)
        //    {
        //        Context.Dispose();
        //    }
        //}

        ///// <summary>
        ///// 执行数据保存功能。
        ///// </summary>
        ///// <returns></returns>
        //protected int Save()
        //{
        //    return Context.SaveChanges();
        //}

        //protected void ResetContext()
        //{
        //    var dbClasses = typeof(T).Assembly.GetTypes();
        //    var dbName = dbClasses
        //        .Where(db => db.IsClass && db.BaseType.Equals(typeof(DbContext)))
        //        .Select(db => db.Name).FirstOrDefault();

        //    EFFactory.RestartEF(dbName);
            
        //}

    }
}

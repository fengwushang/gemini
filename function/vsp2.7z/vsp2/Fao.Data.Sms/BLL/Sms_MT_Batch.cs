﻿using Fao.Data.Sms.DAL;
using Fao.Data.Sms.Model;

namespace Fao.Data.Sms.BLL
{
    public class Sms_MT_Batch
    {
        /// <summary>
        /// 添加一条记录
        /// </summary>
        /// <param name="info">待添加的信息</param>
        /// <returns>返回自增ID</returns>
        public static int Add(Sms_MT_BatchInfo info)
        {
            int infoId = DB_Sms_MT_Batch.Insert<Sms_MT_BatchInfo>(info);
            return infoId;
        }
    }
}

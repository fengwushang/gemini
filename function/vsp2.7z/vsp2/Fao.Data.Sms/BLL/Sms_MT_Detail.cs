﻿using Fao.Data.Sms.DAL;
using Fao.Data.Sms.Model;
using System.Collections.Generic;
using System.Data;

namespace Fao.Data.Sms.BLL
{
    public class Sms_MT_Detail
    {
        /// <summary>
        /// 插入发送短信
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public static bool InsertAll(List<Sms_MT_DetailInfo> list)
        {
            return DB_Sms_MT_Detail.Inserts(list) != null;
        }

        /// <summary>
        /// 根据用户验证过的手机号，得到用户的姓名，公司名
        /// </summary>
        /// <param name="mobile"></param>
        /// <returns></returns>
        public static DataTable getContactInfo(string mobile)
        {
            return DB_Sms_MT_Detail.getContactInfo(mobile);
        }
    }
}
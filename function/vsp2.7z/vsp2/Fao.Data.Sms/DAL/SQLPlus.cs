﻿using Fao.Log;
using Microsoft.ApplicationBlocks.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;

 
namespace Fao.Data.Sms.DAL
{
    public sealed class SQLPlus
    {
        public static string DefaultConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["FaoSMSDB"].ToString();
            }
        }

        /// <summary>
        /// 防止sql注入替换单引号
        /// </summary>
        /// <param name="input">字符串</param>
        /// <returns>处理后的字符串</returns>
        static public string ToSqlValueString(string input)
        {
            if (input == null) return "";

            return input.Replace("'", "''");
        }

        /// <summary>
        /// BulkCopy
        /// </summary>
        /// <param name="table">Datatable</param>
        /// <param name="destinationtablename">destinationtablename</param>
        public static void BulkCopy(DataTable table, string destinationtablename, bool throwException = false)
        {
            BulkCopy(DefaultConnectionString, table, destinationtablename, throwException);
        }

        /// <summary>
        /// BulkCopy
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="table"></param>
        /// <param name="tbName"></param>
        public static void BulkCopy(string connectionString, DataTable table, string destinationtablename, bool throwException = false)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlBulkCopy copy = new SqlBulkCopy(connection);
                try
                {
                    copy.DestinationTableName = destinationtablename;
                    copy.WriteToServer(table);
                }
                catch (SqlException e)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", e);
                    //WebLogs.Add("SQLPlus_Error", "", e.Message, "[BulkCopy]" + e.StackTrace, "", "", "", "");
                    //if (throwException)
                    //    throw e;
                }
                finally
                {
                    copy.Close();
                    connection.Close();
                }
            }
        }

        /// <summary>
        /// BulkCopy 批量拷贝数据到数据库
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="table"></param>
        /// <param name="tbName"></param>
        public static bool BulkCopy(string tbName, int timeout,
            DataTable table, int notifyAfter, SqlRowsCopiedEventHandler rowCopiedHander)
        {
            bool result = true;

            //using (SqlConnection connection = new SqlConnection(DefaultConnectionString))
            //{
            //    connection.Open();

            using (SqlBulkCopy copy = new SqlBulkCopy(DefaultConnectionString, SqlBulkCopyOptions.UseInternalTransaction))
            {
                // 目标表名
                copy.DestinationTableName = tbName;

                // 每个批次100条
                //copy.BatchSize = 100;

                // 超时时间 秒
                copy.BulkCopyTimeout = 6000;

                // 每notifyAfter条 执行事件函数
                copy.NotifyAfter = notifyAfter;
                copy.SqlRowsCopied += rowCopiedHander;

                try
                {
                    copy.WriteToServer(table);
                }
                catch (SqlException e)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", e);
                    //WebLogs.Add("SQLPlus_Error", "", e.Message, "[BulkCopy]" + e.StackTrace, "", "", "", "");
                    result = false;
                }
                finally
                {
                    copy.Close();
                    //connection.Close();
                }
            }
            //}

            return result;
        }

        #region ExecuteNonQuery
        /// <summary>
        /// 执行不返回Table且不带参数的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <returns>执行SQL语句所影响的行数</returns>
        public static int ExecuteNonQuery(CommandType commandType, StringBuilder commandText)
        {
            int result = 0;
            try
            {
                result = SqlHelper.ExecuteNonQuery(DefaultConnectionString, commandType, commandText.ToString());
            }
            catch (SqlException e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                // WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteNonQuery(2个参数)]" + e.StackTrace, "", "", "", "");
            }
            return result;
        }

        /// <summary>
        /// 执行不返回Table但带参数的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <param name="commandParameters">执行SQL语句所需要的参数</param>
        /// <returns>执行SQL语句所影响的行数</returns>
        public static int ExecuteNonQuery(CommandType commandType, StringBuilder commandText, params SqlParameter[] commandParameters)
        {
            int rowEffect = 0;
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(commandText.ToString(), con);
                    cmd.CommandType = commandType;
                    if (commandParameters != null)
                        cmd.Parameters.AddRange(commandParameters);
                    rowEffect = cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", e);
                    //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteNonQuery(3个参数)]" + e.StackTrace, "", "", "", "");
                }
                finally
                {
                    con.Close();
                }
            }
            return rowEffect;
        }

        #endregion ExecuteNonQuery

        #region ExecuteScalar
        /// <summary>
        /// 执行返回一个数据但不带参数的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <returns>SQL语句执行返回的一个数据</returns>
        public static object ExecuteScalar(CommandType commandType, StringBuilder commandText)
        {
            object result = null;
            try
            {
                result = SqlHelper.ExecuteScalar(DefaultConnectionString, commandType, commandText.ToString());
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                // WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteScalar(2个参数)]" + e.StackTrace, "", "", "", "");
            }
            return result;
        }

        /// <summary>
        /// 执行返回一个数据的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <param name="commandParameters">执行SQL语句所需要的参数</param>
        /// <returns>SQL语句执行返回的一个数据</returns>
        public static object ExecuteScalar(CommandType commandType, StringBuilder commandText, params SqlParameter[] commandParameters)
        {
            object result = null;
            try
            {
                result = SqlHelper.ExecuteScalar(DefaultConnectionString, commandType, commandText.ToString(), commandParameters);
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error" + commandText.ToString(), e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteScalar(3个参数)]" + e.StackTrace, "", "", "", "");
                //throw new Exception(commandText.ToString() + Environment.NewLine + e.Message);
            }
            return result;
        }
        #endregion ExecuteScalar

        #region ExecuteReader
        /// <summary>
        /// 执行返回一个Reader但不带参数的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <returns>SQL语句执行返回的一个DataTable</returns>
        public static SqlDataReader ExecuteReader(CommandType commandType, StringBuilder commandText)
        {
            // = new SqlDataReader();
            SqlDataReader result = null;
            try
            {
                result = SqlHelper.ExecuteReader(DefaultConnectionString, commandType, commandText.ToString(), null);
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteReader(2个参数)]" + e.StackTrace, "", "", "", "");
            }
            return result;
        }

        /// <summary>
        /// 执行返回一个Reader的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <param name="commandParameters">执行SQL语句所需要的参数</param>
        /// <returns>SQL语句执行返回的一个DataTable</returns>
        public static SqlDataReader ExecuteReader(CommandType commandType, StringBuilder commandText, params SqlParameter[] commandParameters)
        {
            //SqlDataReader result = new SqlDataReader();
            SqlDataReader result = null;
            try
            {
                result = SqlHelper.ExecuteReader(DefaultConnectionString, commandType, commandText.ToString(), commandParameters);
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteReader(3个参数)]" + e.StackTrace, "", "", "", "");
            }
            return result;
        }

        #endregion ExecuteDataTable

        #region ExecuteDataTable
        /// <summary>
        /// 执行返回一个DataTable但不带参数的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <returns>SQL语句执行返回的一个DataTable</returns>
        public static DataTable ExecuteDataTable(CommandType commandType, StringBuilder commandText)
        {
            DataTable da = new DataTable();
            try
            {
                da = SqlHelper.ExecuteDataset(DefaultConnectionString, commandType, commandText.ToString()).Tables[0];
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteDataTable(2个参数)]" + e.StackTrace, "", "", "", "");
            }
            return da;
        }
        /// <summary>
        /// 执行返回一个DataSet但不带参数的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <returns>SQL语句执行返回的一个DataTable</returns>
        public static DataSet ExecuteDataSet(CommandType commandType, StringBuilder commandText, params SqlParameter[] commandParameters)
        {
            DataSet ds = new DataSet();
            try
            {
                ds = SqlHelper.ExecuteDataset(DefaultConnectionString, commandType, commandText.ToString(), commandParameters);
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteDataTable(2个参数)]" + e.StackTrace, "", "", "", "");
            }
            return ds;
        }
        /// <summary>
        /// 执行返回一个DataTable的SQL语句
        /// </summary>
        /// <param name="commandType">SQL类型</param>
        /// <param name="commandText">T-SQL语句</param>
        /// <param name="commandParameters">执行SQL语句所需要的参数</param>
        /// <returns>SQL语句执行返回的一个DataTable</returns>
        public static DataTable ExecuteDataTable(CommandType commandType, StringBuilder commandText, params SqlParameter[] commandParameters)
        {
            DataTable da = new DataTable();
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(DefaultConnectionString, commandType, commandText.ToString(), commandParameters);
                da = ds.Tables[0];
               
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteDataTable(3个参数)]" + e.StackTrace, "", "", "", "");
            }
            return da;
        }



        #endregion ExecuteDataTable

        #region ExecuteTranscation
        /// <summary>
        /// 执行多条SQL语句，实现数据库事务。两个Hashtable的键应该相同
        /// </summary>
        /// <param name="sqlHash">sql语句键值对</param>
        /// <param name="param">对应sql参数键值对，键同sqlHash</param>
        public void ExecuteSqlTran(Hashtable sqlHash, Hashtable param)
        {
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                try
                {
                    foreach (string k in sqlHash.Keys)
                    {
                        if (param.ContainsKey(k))
                            SqlHelper.ExecuteNonQuery(trans, CommandType.Text, sqlHash[k].ToString(), (SqlParameter[])param[k]);
                        else
                            SqlHelper.ExecuteNonQuery(trans, CommandType.Text, sqlHash[k].ToString(), null);
                    }
                    trans.Commit();
                }
                catch (System.Data.SqlClient.SqlException e)
                {
                    trans.Rollback();
                    LogHelper.LogExceDB("SQLPlus_Error", e);
                    //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteSqlTran(2个参数)]" + e.StackTrace, "", "", "", "");
                    //throw new Exception(e.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        /// <summary>
        /// 执行多条SQL语句，实现数据库事务。
        /// </summary>
        /// <param name="SQLStringList">多条SQL语句</param>		
        public static void ExecuteSqlTran(ArrayList SQLStringList)
        {
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                SqlTransaction trans = con.BeginTransaction();
                cmd.Transaction = trans;

                try
                {
                    for (int n = 0; n < SQLStringList.Count; n++)
                    {
                        string strsql = SQLStringList[n].ToString();
                        if (strsql.Trim().Length > 1)
                        {
                            cmd.CommandText = strsql;
                            cmd.ExecuteNonQuery();
                        }
                    }
                    trans.Commit();
                }
                catch (System.Data.SqlClient.SqlException e)
                {
                    trans.Rollback();
                    LogHelper.LogExceDB("SQLPlus_Error", e);
                    //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteSqlTran(1个参数)]" + e.StackTrace, "", "", "", "");
                    //throw new Exception(e.Message);
                }
                finally
                {
                    con.Close();
                }
            }

        }
        #endregion

        /// <summary>
        /// 分页所得到的DataSet
        /// </summary>
        /// <param name="commandText">SQL语句</param>
        /// <param name="TableName">表名</param>
        /// <param name="start">起始位置</param>
        /// <param name="PageSize">页面列表总条数</param>
        /// <param name="ds">返回分页的到的DataSet</param>
        public static void ExecuteSQL(StringBuilder commandText, string TableName, int start, int PageSize, out DataSet ds)
        {
            SqlConnection conn = new SqlConnection(DefaultConnectionString);
            try
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(commandText.ToString(), conn);
                SqlDataAdapter adapter = new SqlDataAdapter(comm);
                ds = new DataSet();
                adapter.Fill(ds, start, PageSize, TableName);
                conn.Close();
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteSQL]" + e.StackTrace, "", "", "", "");
                //throw e;
                ds = null;
            }
        }

        /// <summary>
        /// 通过事务执行多条SQL语句 返回整形
        /// </summary>
        /// <param name="sqls">sql语句数组</param>
        /// <returns>返回每一条的执行结果</returns>
        public static int[] RunSqlByTransation(string[] sqls)
        {
            int[] results = new int[sqls.Length];

            if (sqls.Length <= 0)
            {
                return results;
            }

            SqlConnection myConnection = new SqlConnection(DefaultConnectionString);
            myConnection.Open();

            SqlCommand myCommand = myConnection.CreateCommand();
            SqlTransaction myTrans = myConnection.BeginTransaction(); //使用New新生成一个事务

            myCommand.Connection = myConnection;
            myCommand.Transaction = myTrans;


            try
            {
                int i = 0;
                foreach (string sql in sqls)
                {
                    myCommand.CommandText = sql;
                    object result = myCommand.ExecuteScalar();
                    results[i++] = Convert.IsDBNull(result) ? 0 : Convert.ToInt32(result);
                }

                myTrans.Commit();

            }
            catch (Exception e)
            {
                myTrans.Rollback();
                results = null;
                LogHelper.LogExceDB("SQLPlus_Error", e);
                // WebLogs.Add("SQLPlus_Error", "", e.Message, "[RunSqlByTransation(1个参数)]" + e.StackTrace, "", "", "", "");
            }
            finally
            {
                myConnection.Close();
            }

            return results;
        }

        /// <summary>
        /// 通过事务执行多条SQL语句 返回整形 参数化
        /// </summary>
        /// <param name="sqls">sql语句数组</param>
        /// <param name="lstP">对应于多个SQL语句的参数集</param>
        /// <returns>返回每一条的执行结果</returns>
        public static int[] RunSqlByTransation(string[] sqls, List<SqlParameter[]> lstP)
        {
            int[] results = new int[sqls.Length];

            if (sqls.Length <= 0)
            {
                return results;
            }

            SqlConnection myConnection = new SqlConnection(DefaultConnectionString);
            myConnection.Open();

            SqlCommand myCommand = myConnection.CreateCommand();
            SqlTransaction myTrans = myConnection.BeginTransaction(); //使用New新生成一个事务

            myCommand.Connection = myConnection;
            myCommand.Transaction = myTrans;


            try
            {
                int i = 0;
                foreach (string sql in sqls)
                {
                    myCommand.CommandText = sql;
                    for (int p = 0; p < lstP[i].Length; p++)
                    {
                        myCommand.Parameters.Add(lstP[i][p]);
                    }
                    object result = myCommand.ExecuteScalar();
                    results[i++] = Convert.IsDBNull(result) ? 0 : Convert.ToInt32(result);
                }

                myTrans.Commit();

            }
            catch (Exception e)
            {
                myTrans.Rollback();
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[RunSqlByTransation(2个参数)]" + e.StackTrace, "", "", "", "");
                results = null;
                LogHelper.LogExceDB("SQLPlus_Error", e);
            }
            finally
            {
                myConnection.Close();
            }

            return results;

        }

        /// <summary>
        /// 通过事务执行多条SQL语句 返回布尔
        /// </summary>
        /// <param name="sqls">sql语句数组</param>
        /// <returns>返回执行结果</returns>
        public static bool RunSqlByTransation2(string[] sqls)
        {
            bool results = true;

            if (sqls.Length <= 0)
            {
                return false;
            }

            SqlConnection myConnection = new SqlConnection(DefaultConnectionString);
            myConnection.Open();

            SqlCommand myCommand = myConnection.CreateCommand();
            SqlTransaction myTrans = myConnection.BeginTransaction(); //使用New新生成一个事务

            myCommand.Connection = myConnection;
            myCommand.Transaction = myTrans;


            // 开启         
            try
            {
                foreach (string sql in sqls)
                {
                    myCommand.CommandText = sql;
                    object result = myCommand.ExecuteScalar();
                }

                // 提交
                myTrans.Commit();

            }
            catch (Exception e)
            {
                // 回退
                myTrans.Rollback();
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[RunSqlByTransation2(1个参数)]" + e.StackTrace, "", "", "", "");
                results = false;

            }
            finally
            {
                myConnection.Close();
            }

            return results;
        }

        /// <summary>
        /// 通过事务执行多条SQL语句 返回布尔 参数化
        /// </summary>
        /// <param name="sqls">sql语句数组</param>
        /// <param name="lstP">对应于多个SQL语句的参数集</param>
        /// <returns>返回执行结果</returns>
        public static bool RunSqlByTransation2(string[] sqls, List<SqlParameter[]> lstP)
        {
            bool results = true;

            if (sqls.Length <= 0)
            {
                return false;
            }

            SqlConnection myConnection = new SqlConnection(DefaultConnectionString);
            myConnection.Open();

            SqlCommand myCommand = myConnection.CreateCommand();
            SqlTransaction myTrans = myConnection.BeginTransaction(); //使用New新生成一个事务

            myCommand.Connection = myConnection;
            myCommand.Transaction = myTrans;


            // 开启         
            try
            {
                for (int i = 0; i < sqls.Length; i++)
                {
                    myCommand.CommandText = sqls[i];
                    for (int p = 0; p < lstP[i].Length; p++)
                    {
                        myCommand.Parameters.Add(lstP[i][p]);
                    }

                    object result = myCommand.ExecuteScalar();
                }

                // 提交
                myTrans.Commit();

            }
            catch (Exception e)
            {
                // 回退
                myTrans.Rollback();
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[RunSqlByTransation2(2个参数)]" + e.StackTrace, "", "", "", "");
                results = false;
            }
            finally
            {
                myConnection.Close();
            }

            return results;
        }

        /// <summary>
        /// 利用事务执行Sql语句
        /// </summary>
        public static void RunSqlTransaction(string[] sql_str)
        {

            SqlConnection myConnection = new SqlConnection(DefaultConnectionString);

            // 初始化

            myConnection.Open();
            SqlCommand myCommand = myConnection.CreateCommand();
            SqlTransaction myTrans;

            // 开启

            myTrans = myConnection.BeginTransaction();

            // Both Transaction object and transaction object
            myCommand.Connection = myConnection;
            myCommand.Transaction = myTrans;
            try
            {
                //myCommand.CommandText = "Insert into Region (RegionID, RegionDescription) VALUES (100, 'Description')";     
                //myCommand.ExecuteNonQuery();     
                //myCommand.CommandText = "Insert into Region (RegionID, RegionDescription) VALUES (101, 'Description')";    
                //myCommand.ExecuteNonQuery();
                for (int i = 0; i < sql_str.Length; i++)
                {
                    myCommand.CommandText = sql_str[i];
                    myCommand.ExecuteNonQuery();
                }

                myTrans.Commit();
                // 成功
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                // WebLogs.Add("SQLPlus_Error", "", e.Message, "[RunSqlTransaction]" + e.StackTrace, "", "", "", "");
                e.ToString();
                try
                {
                    myTrans.Rollback();
                }

                catch (SqlException exx)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", exx);
                    //WebLogs.Add("SQLPlus_Error", "", exx.Message, "[RunSqlTransaction(里面的catch)]" + exx.StackTrace, "", "", "", "");
                    exx.ToString();
                    //error
                }

            }
            finally
            {
                myConnection.Close();
            }

        }

        /// <summary>
        /// 执行一个sql语句，并返回一个整形数
        /// </summary>
        /// <param name="sql">sql语句字符串</param>
        /// <param name="parameters">数组</param>
        /// <returns></returns>
        static public int GetScaler(string sql, params SqlParameter[] parameters)
        {
            int result = 0;
            try
            {
                using (SqlConnection conn = new SqlConnection(DefaultConnectionString))
                {
                    conn.Open();
                    using (SqlCommand comm = new SqlCommand(sql, conn))
                    {
                        if (parameters != null && parameters.Length > 0)
                        {
                            foreach (SqlParameter para in parameters)
                            {
                                comm.Parameters.Add(para);
                            }
                        }
                        object obj = comm.ExecuteScalar();
                        result = Convert.ToInt32(obj);
                    }
                }
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[GetScaler]" + e.StackTrace, "", "", "", "");
            }

            return result;

        }

        /// <summary>
        /// 执行一个sql语句，并返回一个OBJECT
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        static public object GetObjScaler(string sql, params SqlParameter[] parameters)
        {
            object obj = null;
            using (SqlConnection conn = new SqlConnection(DefaultConnectionString))
            {
                try
                {

                    conn.Open();
                    using (SqlCommand comm = new SqlCommand(sql, conn))
                    {
                        if (parameters != null && parameters.Length > 0)
                        {
                            foreach (SqlParameter para in parameters)
                            {
                                comm.Parameters.Add(para);
                            }
                        }
                        obj = comm.ExecuteScalar();
                    }

                }
                catch (Exception e)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", e);
                    //WebLogs.Add("SQLPlus_Error", "", e.Message, "[GetObjScaler]" + e.StackTrace, "", "", "", "");
                }
                finally
                {
                    conn.Close();
                }
            }

            return obj;

        }


        /// <summary>
        /// 执行存储过程
        /// </summary>
        /// <param name="storeProName">存储过程名程</param>
        /// <param name="parameters">参数</param>
        static public void ExecuteStorePro(string storeProName, params SqlParameter[] parameters)
        {
            SqlConnection SqlConn = new SqlConnection(DefaultConnectionString);
            try
            {
                SqlConn.Open();
                SqlCommand comm = new SqlCommand(storeProName, SqlConn);
                comm.CommandType = System.Data.CommandType.StoredProcedure;
                comm.Parameters.AddRange(parameters);
                comm.ExecuteNonQuery();
                comm.Dispose();
            }
            catch (Exception e)
            {
                LogHelper.LogExceDB("SQLPlus_Error", e);
                //WebLogs.Add("SQLPlus_Error", "", e.Message, "[ExecuteStorePro]" + e.StackTrace, "", "", "", "");
            }
            finally
            {
                SqlConn.Close();
            }
        }

        /// <summary>
        /// 执行存储过程，返回参数值
        /// </summary>
        /// <param name="procName">存储过程名</param>
        /// <param name="paras">参数</param>
        /// <param name="pramname">返回参数名</param>
        /// <returns></returns>
        public static int ExecuteStorePro(string procName, SqlParameter[] prams, string pramname)
        {
            int flag = 0;
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(procName, con);
                    cmd.Parameters.AddRange(prams);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();

                    flag = (int)cmd.Parameters[pramname].Value;
                }
                catch (Exception ex)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", ex);
                    //WebLogs.Add("SQLPlus_Error", "", ex.Message, "[ExecuteStorePro]" + ex.StackTrace, "", "", "", "");
                }
                finally
                {
                    con.Close();
                }

            }
            return flag;

        }

        /// <summary>
        /// 执行存储过程 返回DataTable
        /// </summary>
        /// <param name="procName">存储过程名</param>
        /// <param name="paras">参数</param>
        /// <param name="returnPara">返回参数 整型</param>
        /// <returns></returns>
        public static DataTable ExecuteStorePro(string procName, SqlParameter[] paras, string returnPara, out int retValue)
        {
            retValue = 0;
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(procName, con);

                    cmd.Parameters.AddRange(paras);

                    cmd.CommandType = CommandType.StoredProcedure;

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }

                    retValue = (int)cmd.Parameters[returnPara].Value;
                }
                catch (Exception ex)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", ex);
                    //WebLogs.Add("SQLPlus_Error", "", ex.Message, "[ExecuteStorePro]" + ex.StackTrace, "", "", "", "");
                }
                finally
                {
                    con.Close();
                }
            }

            return dt;
        }

        /// <summary>
        /// 执行存储过程 返回DataSet
        /// </summary>
        /// <param name="procName">存储过程名</param>
        /// <param name="paras">参数</param>
        /// <param name="returnPara">返回参数 </param>
        /// <returns></returns>
        public static DataSet ExecuteStorePro(string procName, SqlParameter[] paras, string returnPara, out long retValue)
        {
            retValue = 0;
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(procName, con);
                    cmd.Parameters.AddRange(paras);

                    cmd.CommandType = CommandType.StoredProcedure;

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(ds);
                    }

                    retValue = (int)cmd.Parameters[returnPara].Value;
                }
                catch (Exception ex)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", ex);
                    //WebLogs.Add("SQLPlus_Error", "", ex.Message, "[ExecuteStorePro]" + ex.StackTrace, "", "", "", "");
                }
                finally
                {
                    con.Close();
                }
            }

            return ds;
        }

        /// <summary>
        /// 执行存储过程 返回DataTable
        /// </summary>
        /// <param name="procName">存储过程名</param>
        /// <param name="paras">参数</param>
        /// <returns></returns>
        public static DataTable GetDataTableFromSP(string procName, SqlParameter[] paras)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(procName, con);
                    if (paras != null)
                    {
                        cmd.Parameters.AddRange(paras);
                    }

                    cmd.CommandType = CommandType.StoredProcedure;

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", ex);
                    //WebLogs.Add("SQLPlus_Error", "", ex.Message, "[ExecuteStorePro]" + ex.StackTrace, "", "", "", "");
                }
                finally
                {
                    con.Close();
                }
            }

            return dt;
        }

        /// <summary>
        /// 执行存储过程 返回DataReader
        /// </summary>
        /// <param name="procName">存储过程名</param>
        /// <param name="paras">参数</param>
        /// <returns></returns>
        public static SqlDataReader GetDataReaderFromSP(string procName, SqlParameter[] paras)
        {
            SqlDataReader reader = null;
            SqlConnection con = new SqlConnection(DefaultConnectionString);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(procName, con);
                cmd.Parameters.AddRange(paras);
                cmd.CommandType = CommandType.StoredProcedure;

                reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                LogHelper.LogExceDB("SQLPlus_Error", ex);
                //WebLogs.Add("SQLPlus_Error", "", ex.Message, "[ExecuteStorePro]" + ex.StackTrace, "", "", "", "");
                con.Close();
            }
            finally
            {
            }

            return reader;
        }

        /// <summary>
        /// 执行存储过程 返回DataReader 输出一个参数
        /// </summary>
        /// <param name="procName">存储过程名</param>
        /// <param name="paras">参数</param>
        /// <param name="returnPara">要输出的参数名</param>
        /// <param name="retValue">要输出的参数值</param>
        /// <returns></returns>
        public static SqlDataReader GetDataReaderFromSP(string procName, SqlParameter[] paras, string returnPara, out int retValue)
        {
            retValue = 0;
            SqlDataReader reader = null;
            SqlConnection con = new SqlConnection(DefaultConnectionString);
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(procName, con);
                cmd.Parameters.AddRange(paras);
                cmd.CommandType = CommandType.StoredProcedure;

                reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                retValue = (int)cmd.Parameters[returnPara].Value;
            }
            catch (Exception ex)
            {
                LogHelper.LogExceDB("SQLPlus_Error", ex);
                // WebLogs.Add("SQLPlus_Error", "", ex.Message, "[ExecuteStorePro]" + ex.StackTrace, "", "", "", "");
            }
            finally
            {
                con.Close();
            }

            return reader;
        }

        /// <summary>
        /// 执行存储过程 返回首行首列
        /// </summary>
        /// <param name="procName">存储过程名</param>
        /// <param name="paras">参数</param>
        /// <returns></returns>
        public static object GetObjectFromSP(string procName, SqlParameter[] paras)
        {
            object obj = null;
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(procName, con);
                    cmd.Parameters.AddRange(paras);

                    cmd.CommandType = CommandType.StoredProcedure;

                    obj = cmd.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", ex);
                    //WebLogs.Add("SQLPlus_Error", "", ex.Message, "[ExecuteStorePro]" + ex.StackTrace, "", "", "", "");
                }
                finally
                {
                    con.Close();
                }
            }

            return obj;
        }

        /// <summary>
        /// 执行存储过程 返回首行首列
        /// </summary>
        /// <param name="procName">存储过程名</param>
        /// <param name="paras">参数</param>
        /// <param name="timeout">超时时间（秒） 为0则不限制</param>
        /// <returns></returns>
        public static object GetObjectFromSP(string procName, SqlParameter[] paras, int timeout)
        {
            object obj = null;
            using (SqlConnection con = new SqlConnection(DefaultConnectionString))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(procName, con);
                    cmd.Parameters.AddRange(paras);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = timeout;

                    obj = cmd.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    LogHelper.LogExceDB("SQLPlus_Error", ex);
                    //WebLogs.Add("SQLPlus_Error", "", ex.Message, "[ExecuteStorePro]" + ex.StackTrace, "", "", "", "");
                }
                finally
                {
                    con.Close();
                }
            }

            return obj;
        }
    }
}
﻿using Fao.Data.Sms.Common;
using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using System.Web;

namespace Fao.Data.Sms.DAL
{
    public class BaseDal
    {
        /// <summary>
        /// 通过泛型插入数据
        /// </summary>
        /// <typeparam name="T">泛型</typeparam>
        /// <param name="obj">类对象</param>
        /// <returns>插入的新记录ID</returns>
        public static int Insert<T>(T obj, bool workFlow = true)
        { 
            StringBuilder strSQL = new StringBuilder();
            SqlParameter[] p;

            strSQL = GetInsertSQL(obj, "", out p);

            object result = SQLPlus.ExecuteScalar(CommandType.Text, strSQL, p);
            int returnValue = Convert.IsDBNull(result) ? 0 : Convert.ToInt32(result);

            return returnValue;
        }

        /// <summary>
        /// 获取实体的插入语句
        /// </summary>
        /// <typeparam name="T">泛型</typeparam>
        /// <param name="obj">实体对象</param>
        /// <param name="objFlag">在一次事务中 对象的唯一标识</param>
        /// <param name="paras">输出SQL语句的参数集</param>
        /// <returns>返回插入语句</returns>
        public static StringBuilder GetInsertSQL<T>(T obj, string objFlag, out SqlParameter[] paras)
        {
            paras = new SqlParameter[] { };

            string tableKey = Tools.GetPropertyValue(obj, BaseSet.PrimaryKey) + "";
            string keyValue = Tools.GetPropertyValue(obj, tableKey) + "";
            string tableName = Tools.GetPropertyValue(obj, BaseSet.TableName) + "";

            Type t = obj.GetType();//获得该类的Type

            StringBuilder strSQL = new StringBuilder();

            strSQL.Append("insert into " + tableName + "(");

            string fields = "";
            string values = "";

            SqlParameter para = new SqlParameter();
            ArrayList arrP = new ArrayList();
            //再用Type.GetProperties获得PropertyInfo[]
            foreach (PropertyInfo pi in t.GetProperties())
            {
                object name = pi.Name;//用pi.GetValue获得值
                string viewStatus = name + BaseSet.ViewStatus;
                string value1 = pi.GetValue(obj, null) + "";
                string properName = name.ToString().ToLower();

                if (properName != tableKey.ToLower() &&
                    properName != BaseSet.PrimaryKey.ToLower() &&
                    properName != BaseSet.TableName.ToLower() &&
                    properName.IndexOf(BaseSet.ViewStatus.ToLower()) == -1)
                {
                    bool viewStatusValue = Convert.ToBoolean(t.GetProperty(viewStatus).GetValue(obj, null));

                    if (viewStatusValue)
                    {
                        object paraType = DataConvert.GetSqlDbTypeByDataType(pi.PropertyType.FullName);

                        if (paraType != null)
                        {
                            fields += name + ",";

                            string strPara = "@" + name + objFlag;

                            values += strPara + ",";

                            SqlDbType sqlParaType = (SqlDbType)paraType;
                            para = new SqlParameter(strPara, sqlParaType);

                            // 时间类型的特殊处理
                            if (pi.PropertyType.FullName.ToLower() == "system.datetime")
                            {
                                value1 = Convert.ToDateTime(value1).ToString("yyyy-MM-dd HH:mm:ss");
                            }

                            // 对于 NChar NText NVarChar Text VarChar 等类型 进行HTML编码 保证入库的数据 是编码后的
                            if (sqlParaType == SqlDbType.NChar ||
                                sqlParaType == SqlDbType.NText ||
                                sqlParaType == SqlDbType.NVarChar ||
                                sqlParaType == SqlDbType.VarChar ||
                                sqlParaType == SqlDbType.Text)
                            {
                                value1 = HttpUtility.HtmlEncode(value1);
                            }

                            para.Value = value1;

                            arrP.Add(para);
                        }
                    }
                }

            }

            // 去掉最后一个,
            fields = fields.TrimEnd(',');
            values = values.TrimEnd(',');

            paras = arrP.ToArray(para.GetType()) as SqlParameter[];

            // 拼接Sql串
            strSQL.Append(fields);
            strSQL.Append(") values (");
            strSQL.Append(values);
            strSQL.Append(")");

            strSQL.Append(";SELECT @@IDENTITY;");

            return strSQL;

        }
    }
}

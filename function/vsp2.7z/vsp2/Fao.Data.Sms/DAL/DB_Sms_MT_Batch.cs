﻿
namespace Fao.Data.Sms.DAL
{
    public class DB_Sms_MT_Batch : BaseDal
    {
    }
}

﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace Fao.Data.Sms.DAL
{
    public class DB_Sms_MT_Detail : BaseDal
    {
        /// <summary>
        /// 通过事务插入同一类型的多个实体
        /// </summary>
        /// <typeparam name="T">实体list</typeparam>
        /// <param name="objs">实体对象</param>
        /// <returns>返回每一个插入成功实体的ID，顺序与插入时一致</returns>
        public static int[] Inserts<T>(IList<T> objs)
        {
            int[] result = new int[objs.Count];
            string[] sqls = new string[objs.Count];

            if (objs.Count == 0)
            {
                return result;
            }

            StringBuilder strSQL = new StringBuilder();
            List<SqlParameter[]> lstP = new List<SqlParameter[]>();

            SqlParameter[] curP;
            for (int i = 0; i < objs.Count; i++)
            {
                strSQL = GetInsertSQL(objs[i], i.ToString(), out curP);
                sqls[i] = strSQL.ToString();
                lstP.Add(curP);
            }

            //调用事务
            result = SQLPlus.RunSqlByTransation(sqls, lstP);

            return result;
        }

        /// <summary>
        /// 根据用户验证过的手机号，得到用户的姓名，公司名
        /// </summary>
        /// <param name="mobile"></param>
        /// <returns></returns>
        public static DataTable getContactInfo(string mobile)
        {
            SqlParameter param = new SqlParameter("@mobile", mobile); 
            return SQLPlus.ExecuteDataTable(CommandType.StoredProcedure, new StringBuilder("ProcGetUserbyVerifyPhone"), param);

        }
    }
}
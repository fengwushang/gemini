﻿
namespace Fao.Data.Sms.DAL
{
    public class BaseSet
    {
        /// <summary>
        /// 主键
        /// </summary>
        public static string PrimaryKey
        {
            get { return "PrimaryKey"; }
        }

        /// <summary>
        /// 表名
        /// </summary>
        public static string TableName
        {
            get { return "TableName"; }
        }

        /// <summary>
        /// 实体里的标示
        /// </summary>
        public static string ViewStatus
        {
            get { return "_View_Status"; }
        }

        public static string NULL
        {
            get { return "@null"; }
        }

        public static string DateTimeLongNull
        {
            get { return "1900-01-01 00:00:00"; }
        }

        public static string DateShortNull
        {
            get { return "0001-1-1 0:00:00"; }
        }

        public static string DateTimeShortNull
        {
            get { return "1900-1-1 0:00:00"; }
        }
    }
}

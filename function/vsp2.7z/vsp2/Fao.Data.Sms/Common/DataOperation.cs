﻿using System.Data;


namespace Fao.Data.Sms.Common
{
    public class DataOperation
    {
        /// <summary>
        /// 根据数据类型得到数据库类型
        /// </summary>
        /// <param name="dataType"></param>
        /// <returns></returns>
        public static object GetSqlDbTypeByDataType(string dataType)
        {
            dataType = dataType.ToLower();

            if (dataType == DataType.String)
            {
                return SqlDbType.NVarChar;
            }
            else if (dataType == DataType.Int16)
            {
                return SqlDbType.SmallInt;
            }
            else if (dataType == DataType.Int32)
            {
                return SqlDbType.Int;
            }
            else if (dataType == DataType.Int64)
            {
                return SqlDbType.BigInt;
            }
            else if (dataType == DataType.Boolean)
            {
                return SqlDbType.Bit;
            }
            else if (dataType == DataType.DateTime)
            {
                return SqlDbType.DateTime;
            }
            else if (dataType == DataType.Double)
            {
                return SqlDbType.Float;
            }
            else if (dataType == DataType.Float)
            {
                return SqlDbType.Float;
            }
            else if (dataType == DataType.Decimal)
            {
                return SqlDbType.Decimal;
            }
            else
            {
                return SqlDbType.Variant;
            }
        }
    }
}

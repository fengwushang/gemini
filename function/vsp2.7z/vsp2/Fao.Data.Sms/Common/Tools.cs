﻿using System;
using System.Reflection;

namespace Fao.Data.Sms.Common
{
    public class Tools
    {
        /// <summary>
        /// 获取对象指定属性的值
        /// </summary>
        /// <typeparam name="T">类</typeparam>
        /// <param name="obj">对象</param>
        /// <param name="propertyName">属性名称</param>
        /// <returns>返回该属性的值</returns>
        public static Object GetPropertyValue<T>(T obj, string propertyName)
        {

            Type t = obj.GetType();//获得该类的Type

            Object value = "";

            //再用Type.GetProperties获得PropertyInfo[]
            foreach (PropertyInfo pi in t.GetProperties())
            {
                object name = pi.Name;//用pi.GetValue获得值

                name += "";
                name = name.ToString().ToLower();

                propertyName += "";
                propertyName = propertyName.ToLower();

                if (string.Equals(name, propertyName))
                {
                    value = pi.GetValue(obj, null);
                    break;
                }
            }
            return value;
        }
    }
}

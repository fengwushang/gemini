﻿using System.Text.RegularExpressions;

namespace Fao.Data.Sms.Common
{
    public static class Check
    {
        /// <summary>
        /// 校验手机号码
        /// </summary>
        /// <param name="mobile">手机号码</param>
        /// <returns>true:是正确的格式 false:是错误的格式或者为空</returns>
        public static bool IsMobile(string mobile)
        {
            //string pattern = @"^(1[35]\d{9}|189\d{8})$";  
            string pattern = @"^1\d{10}$";
            bool flag = IsMatch(mobile, pattern);
            return flag;
        }

        /// <summary>
        /// 判断内容是否符合正则表达式 不区分大小写
        /// </summary>
        /// <param name="content">内容</param>
        /// <param name="pattern">正则表达式</param>
        /// <returns>true:符合 flase:不符合</returns>
        public static bool IsMatch(string content, string pattern)
        {
            Regex r = new Regex(pattern, RegexOptions.IgnoreCase);
            Match m = r.Match(content);
            return m.Success;
        }
    }
}

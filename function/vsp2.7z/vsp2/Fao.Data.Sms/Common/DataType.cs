﻿
namespace Fao.Data.Sms.Common
{

    /// <summary>
    /// 数据类型类 需加入更多
    /// </summary>
    public static class DataType
    {
        /// <summary>
        /// 字符串
        /// </summary>
        public static string String
        {
            get { return "system.string"; }
        }
        /// <summary>
        /// 布尔值
        /// </summary>
        public static string Boolean
        {
            get { return "system.boolean"; }
        }
        /// <summary>
        /// 16位的有符号整数
        /// </summary>
        public static string Int16
        {
            get { return "system.int16"; }
        }
        /// <summary>
        /// 32有符号整数
        /// </summary>
        public static string Int32
        {
            get { return "system.int32"; }
        }
        /// <summary>
        /// 64位有符号的整数
        /// </summary>
        public static string Int64
        {
            get { return "system.int64"; }
        }
        /// <summary>
        /// 浮点数
        /// </summary>
        public static string Double
        {
            get { return "system.double"; }
        }
        public static string Float
        {
            get { return "system.float"; }
        }
        /// <summary>
        /// 日期和时间数据
        /// </summary>
        public static string DateTime
        {
            get { return "system.datetime"; }
        }
        /// <summary>
        /// 特殊的数据类型
        /// </summary>
        public static string Object
        {
            get { return "System.Object"; }
        }

        public static string Decimal
        {
            get
            {
                return "System.Decimal";
            }
        }

    }
}
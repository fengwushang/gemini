﻿using System;
using System.ComponentModel;


namespace Fao.Data.Sms.Model
{
    [Serializable]
    public class Sms_MT_DetailInfo
    {
        public string TableName
        {
            get { return "Sms_MT_Detail"; }
        }
        public string PrimaryKey
        {
            get { return "BigDetailID"; }
        }

        private System.Int64 _BigDetailID;
        private bool _BigDetailID_Status;
        [Description("下行短信详情ID")]
        public System.Int64 BigDetailID
        {
            get { return _BigDetailID; }
            set
            {
                _BigDetailID = value;
                _BigDetailID_Status = true;
            }
        }
        public bool BigDetailID_View_Status
        {
            get { return _BigDetailID_Status; }
            set
            {
                _BigDetailID_Status = value;
            }
        }

        private System.Int64 _BatchID;
        private bool _BatchID_Status;
        [Description("批次ID")]
        public System.Int64 BatchID
        {
            get { return _BatchID; }
            set
            {
                _BatchID = value;
                _BatchID_Status = true;
            }
        }
        public bool BatchID_View_Status
        {
            get { return _BatchID_Status; }
            set
            {
                _BatchID_Status = value;
            }
        }

        private string _Mobile;
        private bool _Mobile_Status;
        [Description("手机号")]
        public string Mobile
        {
            get { return _Mobile; }
            set
            {
                _Mobile = value;
                _Mobile_Status = true;
            }
        }
        public bool Mobile_View_Status
        {
            get { return _Mobile_Status; }
            set
            {
                _Mobile_Status = value;
            }
        }

        private int _Reserve;
        private bool _Reserve_Status;
        [Description("状态0成功,-1,-2失败")]
        public int Reserve
        {
            get { return _Reserve; }
            set
            {
                _Reserve = value;
                _Reserve_Status = true;
            }
        }
        public bool Reserve_View_Status
        {
            get { return _Reserve_Status; }
            set
            {
                _Reserve_Status = value;
            }
        }

        private DateTime _SendTime;
        private bool _SendTime_Status;
        [Description("发送时间")]
        public DateTime SendTime
        {
            get { return _SendTime; }
            set
            {
                _SendTime = value;
                _SendTime_Status = true;
            }
        }
        public bool SendTime_View_Status
        {
            get { return _SendTime_Status; }
            set
            {
                _SendTime_Status = value;
            }
        }

        private int _ResendFlag;
        private bool _ResendFlag_Status;
        [Description("是否是重发记录（1.是 0.不是）")]
        public int ResendFlag
        {
            get { return _ResendFlag; }
            set
            {
                _ResendFlag = value;
                _ResendFlag_Status = true;
            }
        }
        public bool ResendFlag_View_Status
        {
            get { return _ResendFlag_Status; }
            set
            {
                _ResendFlag_Status = value;
            }
        }

        private int _Flag;
        private bool _Flag_Status;
        [Description("是否删除")]
        public int Flag
        {
            get { return _Flag; }
            set
            {
                _Flag = value;
                _Flag_Status = true;
            }
        }
        public bool Flag_View_Status
        {
            get { return _Flag_Status; }
            set
            {
                _Flag_Status = value;
            }
        }

        private string _ReportState;
        private bool _ReportState_Status;
        [Description("ReportState")]
        public string ReportState
        {
            get { return _ReportState; }
            set
            {
                _ReportState = value;
                _ReportState_Status = true;
            }
        }
        public bool ReportState_View_Status
        {
            get { return _ReportState_Status; }
            set
            {
                _ReportState_Status = value;
            }
        }

        private System.Int64 _MessageID;
        private bool _MessageID_Status;
        [Description("MessageID")]
        public System.Int64 MessageID
        {
            get { return _MessageID; }
            set
            {
                _MessageID = value;
                _MessageID_Status = true;
            }
        }
        public bool MessageID_View_Status
        {
            get { return _MessageID_Status; }
            set
            {
                _MessageID_Status = value;
            }
        }

        private string _GetewayID;
        private bool _GetewayID_Status;
        [Description("GetewayID")]
        public string GetewayID
        {
            get { return _GetewayID; }
            set
            {
                _GetewayID = value;
                _GetewayID_Status = true;
            }
        }
        public bool GetewayID_View_Status
        {
            get { return _GetewayID_Status; }
            set
            {
                _GetewayID_Status = value;
            }
        }


        private System.Int64 _BigContactAUID;
        private bool _BigContactAUID_Status;
        [Description("接收人id")]
        public System.Int64 BigContactAUID
        {
            get { return _BigContactAUID; }
            set
            {
                _BigContactAUID = value;
                _BigContactAUID_Status = true;
            }
        }
        public bool BigContactAUID_View_Status
        {
            get { return _BigContactAUID_Status; }
            set
            {
                _BigContactAUID_Status = value;
            }
        }

    }
}

﻿using System;
using System.ComponentModel;

namespace Fao.Data.Sms.Model
{
    [Serializable]
    public class Sms_MT_BatchInfo
    {
        public string TableName
        {
            get { return "Sms_MT_Batch"; }
        }
        public string PrimaryKey
        {
            get { return "BigBatchID"; }
        }

        private System.Int64 _BigBatchID;
        private bool _BigBatchID_Status;
        [Description("批次ID")]
        public System.Int64 BigBatchID
        {
            get { return _BigBatchID; }
            set
            {
                _BigBatchID = value;
                _BigBatchID_Status = true;
            }
        }
        public bool BigBatchID_View_Status
        {
            get { return _BigBatchID_Status; }
            set
            {
                _BigBatchID_Status = value;
            }
        }

        private int _MsgType;
        private bool _MsgType_Status;
        [Description("短信类型（1普通发送 2点对点）")]
        public int MsgType
        {
            get { return _MsgType; }
            set
            {
                _MsgType = value;
                _MsgType_Status = true;
            }
        }
        public bool MsgType_View_Status
        {
            get { return _MsgType_Status; }
            set
            {
                _MsgType_Status = value;
            }
        }

        private string _MsgContent;
        private bool _MsgContent_Status;
        [Description("短信内容")]
        public string MsgContent
        {
            get { return _MsgContent; }
            set
            {
                _MsgContent = value;
                _MsgContent_Status = true;
            }
        }
        public bool MsgContent_View_Status
        {
            get { return _MsgContent_Status; }
            set
            {
                _MsgContent_Status = value;
            }
        }

        private string _WapPushUrl;
        private bool _WapPushUrl_Status;
        [Description("Wap Push Url地址")]
        public string WapPushUrl
        {
            get { return _WapPushUrl; }
            set
            {
                _WapPushUrl = value;
                _WapPushUrl_Status = true;
            }
        }
        public bool WapPushUrl_View_Status
        {
            get { return _WapPushUrl_Status; }
            set
            {
                _WapPushUrl_Status = value;
            }
        }

        private int _SendMode;
        private bool _SendMode_Status;
        [Description("发送方式（1.立即发送,2.定时发送，3.循环发送）")]
        public int SendMode
        {
            get { return _SendMode; }
            set
            {
                _SendMode = value;
                _SendMode_Status = true;
            }
        }
        public bool SendMode_View_Status
        {
            get { return _SendMode_Status; }
            set
            {
                _SendMode_Status = value;
            }
        }

        private DateTime _SendTime;
        private bool _SendTime_Status;
        [Description("发送时间")]
        public DateTime SendTime
        {
            get { return _SendTime; }
            set
            {
                _SendTime = value;
                _SendTime_Status = true;
            }
        }
        public bool SendTime_View_Status
        {
            get { return _SendTime_Status; }
            set
            {
                _SendTime_Status = value;
            }
        }

        private DateTime _CreateTime;
        private bool _CreateTime_Status;
        [Description("创建时间")]
        public DateTime CreateTime
        {
            get { return _CreateTime; }
            set
            {
                _CreateTime = value;
                _CreateTime_Status = true;
            }
        }
        public bool CreateTime_View_Status
        {
            get { return _CreateTime_Status; }
            set
            {
                _CreateTime_Status = value;
            }
        }

        private int _ReplyFlag;
        private bool _ReplyFlag_Status;
        [Description("是否回复（1.需要，2.不需要）")]
        public int ReplyFlag
        {
            get { return _ReplyFlag; }
            set
            {
                _ReplyFlag = value;
                _ReplyFlag_Status = true;
            }
        }
        public bool ReplyFlag_View_Status
        {
            get { return _ReplyFlag_Status; }
            set
            {
                _ReplyFlag_Status = value;
            }
        }

        private int _SendFlag;
        private bool _SendFlag_Status;
        [Description("是否发送（0.取消 1.待发，2.已发送）")]
        public int SendFlag
        {
            get { return _SendFlag; }
            set
            {
                _SendFlag = value;
                _SendFlag_Status = true;
            }
        }
        public bool SendFlag_View_Status
        {
            get { return _SendFlag_Status; }
            set
            {
                _SendFlag_Status = value;
            }
        }

        private int _ReportStatusFlag;
        private bool _ReportStatusFlag_Status;
        [Description("是否返回状态报告（1.需要 0不需要）")]
        public int ReportStatusFlag
        {
            get { return _ReportStatusFlag; }
            set
            {
                _ReportStatusFlag = value;
                _ReportStatusFlag_Status = true;
            }
        }
        public bool ReportStatusFlag_View_Status
        {
            get { return _ReportStatusFlag_Status; }
            set
            {
                _ReportStatusFlag_Status = value;
            }
        }

        private int _Flag;
        private bool _Flag_Status;
        [Description("是否删除")]
        public int Flag
        {
            get { return _Flag; }
            set
            {
                _Flag = value;
                _Flag_Status = true;
            }
        }
        public bool Flag_View_Status
        {
            get { return _Flag_Status; }
            set
            {
                _Flag_Status = value;
            }
        }

        private System.Int64 _OperatorID;
        private bool _OperatorID_Status;
        [Description("发送人ID")]
        public System.Int64 OperatorID
        {
            get { return _OperatorID; }
            set
            {
                _OperatorID = value;
                _OperatorID_Status = true;
            }
        }
        public bool OperatorID_View_Status
        {
            get { return _OperatorID_Status; }
            set
            {
                _OperatorID_Status = value;
            }
        }

        private int _IntBatchBackList;
        private bool _IntBatchBackList_Status;
        [Description("去黑名单标识  1已去黑  0未去黑 (默认：0)")]
        public int IntBatchBackList
        {
            get { return _IntBatchBackList; }
            set
            {
                _IntBatchBackList = value;
                _IntBatchBackList_Status = true;
            }
        }
        public bool IntBatchBackList_View_Status
        {
            get { return _IntBatchBackList_Status; }
            set
            {
                _IntBatchBackList_Status = value;
            }
        }


    }
}
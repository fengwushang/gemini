﻿using System;
using System.Collections.Generic;
using System.Linq;
using Fao.Data.Sms.Common;
using System.Text;
using System.Data;

namespace Fao.Data.Sms
{
    public sealed class SendSms
    { 
        /// <summary>
        /// 发送实体
        /// </summary> 
        public class SmsSend
        {
            public string smsContetnt { get; set; } //短信内容
            public int smsSendUserID { get; set; } //发送人ID 
            public string smsReceiveNumList { get; set; } //接收号码字符串，以半角逗号隔开
        }

        /// <summary>
        ///发送短信,插入到数据库
        ///实体参数：1 短信内容,2 发送人ID,3 发送号码集合
        /// </summary>
        /// <param name="SS"></param>
        /// <returns>True发送成功，False 发送失败</returns>
        public static bool Insert(SmsSend SS)
        {
            Dictionary<string, string> NumberList = new Dictionary<string, string>();
            NumberList = FormationPhoneNum(SS.smsReceiveNumList);

            List<Model.Sms_MT_DetailInfo> list = new List<Model.Sms_MT_DetailInfo>();
            Model.Sms_MT_BatchInfo batch = new Model.Sms_MT_BatchInfo();

            batch.MsgContent = SS.smsContetnt;  // 短信内容 
            batch.SendMode = 1;       //1 即时发送 2定时发送时,要有发送时间
            batch.SendTime = DateTime.Now;
            batch.MsgType = 1;
            batch.ReplyFlag = 1;
            batch.SendFlag = 1;
            batch.ReportStatusFlag = 1;
            batch.OperatorID = SS.smsSendUserID; // 发送用户ID  
            //if (Request.QueryString["from"] == "hr")
            batch.Flag = 2;   //基本都是2
            batch.IntBatchBackList = 0;

            int flag = BLL.Sms_MT_Batch.Add(batch);
            if (flag == 0)
            {
                return false;
            }
            #region OldCode
            //foreach (var item in NumberList)
            //{
            //    list.Add(new Model.Sms_MT_DetailInfo
            //    {
            //        Mobile = item.Value,       //用户手机号
            //        Reserve = 1,
            //        SendTime = batch.SendTime,
            //        ResendFlag = 0,
            //        BatchID = flag,
            //        BigContactAUID = Convert.ToInt32(item.Key)  //发给哪个用户的
            //    });
            //}
            //int count = 200;
            //int i = 0;
            //bool result = true;
            //while (count * i <= list.Count)
            //{
            //    result = BLL.Sms_MT_Detail.InsertAll(list.Where((item, index) => index >= count * i && index < count * i + count).ToList());
            //    i++;
            //}
            //return result;
            #endregion
            DataTable dt = GetTableDetail();
            int k = 0;
            foreach (var item in NumberList)
            {
                dt.Rows.Add();
                dt.Rows[k]["BigDetailID"] = k;
                dt.Rows[k]["Mobile"] = item.Key;     //用户手机号 张恕军注意
                dt.Rows[k]["Reserve"] = 1;
                dt.Rows[k]["SendTime"] = batch.SendTime;
                dt.Rows[k]["ResendFlag"] = 0;
                dt.Rows[k]["BatchID"] = flag;
                dt.Rows[k]["BigContactAUID"] = item.Value;  //发给哪个用户的 张恕军注意
                dt.Rows[k]["IntDetailBackList"] = 1;
                ++k;
            }

            if (k > 0)
            {
                //批量插入详情
                DAL.SQLPlus.BulkCopy(dt, "Sms_MT_Detail", true);
                //去黑名单
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("exec Prc_Sms_FilterBlacklist {0},{1}", flag, SS.smsSendUserID);
                DAL.SQLPlus.ExecuteNonQuery(CommandType.Text, sb);
            }
            return true;

        }
        //构造短信详细内容数据源
        private static DataTable GetTableDetail()
        {
            DataTable dtNw = new DataTable();

            dtNw.Columns.Add("BigDetailID");
            dtNw.Columns["BigDetailID"].DataType = typeof(long);

            dtNw.Columns.Add("BatchID");
            dtNw.Columns["BatchID"].DataType = typeof(long);

            dtNw.Columns.Add("Mobile");
            dtNw.Columns["Mobile"].DataType = typeof(string);

            dtNw.Columns.Add("Reserve");
            dtNw.Columns["Reserve"].DataType = typeof(int);

            dtNw.Columns.Add("SendTime");
            dtNw.Columns["SendTime"].DataType = typeof(DateTime);

            dtNw.Columns.Add("ResendFlag");
            dtNw.Columns["ResendFlag"].DataType = typeof(int);

            dtNw.Columns.Add("Flag");
            dtNw.Columns["Flag"].DataType = typeof(int);

            dtNw.Columns.Add("ReportState");
            dtNw.Columns["ReportState"].DataType = typeof(string);

            dtNw.Columns.Add("BigContactAUID");
            dtNw.Columns["BigContactAUID"].DataType = typeof(long);

            dtNw.Columns.Add("MessageID");
            dtNw.Columns["MessageID"].DataType = typeof(long);

            dtNw.Columns.Add("GetewayID");
            dtNw.Columns["GetewayID"].DataType = typeof(string);

            dtNw.Columns.Add("IntDetailBackList");
            dtNw.Columns["IntDetailBackList"].DataType = typeof(int);

            return dtNw;
        }

        /// <summary>
        ///  组织、过滤 手机号
        /// </summary>
        /// <param name="PhoneNumStr"></param>
        /// <returns></returns>
        private static Dictionary<string, string> FormationPhoneNum(string PhoneNumStr)
        {
            Dictionary<string, string> phoneDic = new Dictionary<string, string>();
            string[] arr = PhoneNumStr.Trim().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var i in arr)
            {
                string[] a = i.Trim().Split(new char[] { 'A' }, StringSplitOptions.RemoveEmptyEntries);
                if (a.Length < 2)
                    continue;
                if (phoneDic.ContainsKey(a[1]))//用手机号作为Key，过滤重复手机号。
                    continue;
                else
                    if (Check.IsMobile(a[1].ToString()))  //加入号码集 
                        phoneDic.Add(a[1], a[0]);
            }
            return phoneDic;
        }

        /// <summary>
        ///  组织、过滤 手机号
        /// </summary>
        /// <param name="PhoneNumStr"></param>
        /// <returns></returns>
        public static string FormationPhoneFirst(string PhoneNumStr)
        {
            StringBuilder sb = new StringBuilder();
            Dictionary<string, string> phoneDic = new Dictionary<string, string>();
            string[] arr = PhoneNumStr.Trim().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var i in arr)
            {
                string[] a = i.Trim().Split(new char[] { 'A' }, StringSplitOptions.RemoveEmptyEntries);
                if (a.Length < 2)
                    continue;
                if (phoneDic.ContainsKey(a[1]))//用手机号作为Key，过滤重复手机号。
                    continue;
                else
                    if (Check.IsMobile(a[1].ToString()))  //加入号码集 
                        phoneDic.Add(a[1], a[0]);
            }

            foreach (var item in phoneDic)
            {
                sb.Append(item.Key + "A" + item.Value);
            } 
            return sb.ToString();
        }

    }
}
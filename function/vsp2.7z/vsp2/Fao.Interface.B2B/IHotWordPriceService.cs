﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// HotWordPrice服务接口-Power by CodeGG
    /// </summary>
    public interface IHotWordPriceService : ICrud<HotWordPrice>
    {
        /// <summary>
        /// 根据SmHotWordPrice查询模型，返回VmHotWordPrice视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmHotWordPrice> GetHotWordPrices(SmHotWordPrice searchModel);

        /// <summary>
        /// 根据id，返回VmHotWordPrice视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmHotWordPrice GetHotWordPriceByID(string id);

        /// <summary>
        /// 返回该类数据，该词的竞价排名
        /// </summary>
        /// <param name="id">分类</param>
        /// <param name="keyword">关键词</param>
        /// <returns></returns>
        List<VmHotWordPrice> GetOneHotWordPrices(string keyword);

        /// <summary>
        /// 得到热词价格
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VmHotWordPricePaging GetHotWordPricePaging(SmHotWordPrice sm, int page, int rows);

        /// <summary>
        /// 删除热词价格
        /// </summary>
        /// <param name="EncriptID"></param>
        /// <returns></returns>
        string DeleteHotWordPrice(string EncriptID);

        /// <summary>
        /// 添加热词价格
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddHotWordPrice(VmHotWordPrice model);

        /// <summary>
        /// 修改热词价格
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateHotWordPrice(VmHotWordPrice model);
    }
}
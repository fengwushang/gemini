﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// UserTransaction服务接口-Power by CodeGG
    /// </summary>
    public interface IUserTransactionService : ICrud<UserTransaction>
    {
        /// <summary>
        /// 根据SmUserTransaction查询模型，返回VmUserTransaction视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmUserTransaction> GetUserTransactions(SmUserTransaction searchModel);

        /// <summary>
        /// 根据id，返回VmUserTransaction视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmUserTransaction GetUserTransactionByID(string id);

        /// <summary>
        /// 获取当前用户交易账户信息
        /// </summary>
        /// <returns></returns>
        VmUserTransaction GetCurrentUserTransaction(FaoB2BEntities context);

        /// <summary>
        /// 获取当前用户交易账户信息
        /// </summary>
        /// <returns></returns>
        VmUserTransaction GetCurrentUserTransaction();

        /// <summary>
        /// 账户充值
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="money"></param>
        /// <returns></returns>
        string ReCharge(int userID, decimal money);


        /// <summary>
        /// 购买短信
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="buyCount"></param>
        /// <param name="smsValue"></param>
        /// <returns></returns>
        string BuyMsg(FaoB2BEntities context, int buyCount, decimal smsValue, int SMSInterval);

        /// <summary>
        /// 更改用户发短信条数
        /// </summary>
        /// <param name="sendCount"></param>
        /// <returns></returns>
        string updateMsgCount(int sendCount);

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="email"></param>
        /// <param name="NewPassword"></param>
        /// <param name=""></param>
        /// <returns></returns>
        int ChangPayPWD(string Email, string NewPassword, string OldPassword);

        /// <summary>
        /// 充值PPC账号
        /// </summary>
        /// <param name="PWD"></param>
        /// <param name="Rechange"></param>
        /// <returns></returns>
        string PPCRechange(string PWD, decimal Rechange);
    }
}
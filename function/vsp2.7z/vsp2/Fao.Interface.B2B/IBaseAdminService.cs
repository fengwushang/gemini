﻿using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Data.B2B;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-21 10:32:34
    /// BaseAdmin服务接口-Power by CodeGG
    /// </summary>
    public interface IBaseAdminService : ICrud<BaseAdmin>
    {
        /// <summary>
        /// 根据SmBaseAdmin查询模型，返回VmBaseAdmin分页数据
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <param name="pageIndex">页所引</param>
        /// <param name="pageCount">页记录数</param>
        /// <returns>分页数据</returns>
        BaseAdminPaging GetBaseAdmins(SmBaseAdmin searchModel, int pageIndex, int pageCount);

        /// <summary>
        /// 根据id，返回VmBaseAdmin视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmBaseAdmin GetBaseAdminByID(string id);

        /// <summary>
        /// 修改管理员
        /// </summary>
        /// <param name="model">VmBaseAdmin 视图模型</param>
        /// <returns></returns>
        int UpdateAdmin(VmBaseAdmin model);

        /// <summary>
        /// 逻辑删除管理员
        /// </summary>
        /// <param name="id">管理员id</param>
        /// <returns></returns>
        int RemoveAdminByID(int id);

        /// <summary>
        /// 添加管理员
        /// </summary>
        /// <param name="model">VmBaseAdmin 视图模型</param>
        /// <returns></returns>
        int AddAdmin(VmBaseAdmin model);
        /// <summary>
        /// 验证登陆信息
        /// </summary>
        /// <param name="adminName">登录名</param>
        /// <param name="passWord">密码</param>
        /// <returns></returns>
        VmBaseAdmin ValidateUser(string adminName, string passWord);

        
    }
}
﻿using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Data.B2B;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-20 10:18:31
    /// BaseLog服务接口-Power by CodeGG
    /// </summary>
    public interface IBaseLogService : ICrud<BaseLog>
    {
        /// <summary>
        /// 根据SmBaseLog查询模型，返回VmBaseLog分页数据
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <param name="pageIndex">页所引</param>
        /// <param name="pageCount">页记录数</param>
        /// <returns>分页数据</returns>
        BaseLogPaging GetBaseLogs(SmBaseLog searchModel, int pageIndex, int pageCount);

        /// <summary>
        /// 根据id，返回VmBaseLog视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmBaseLog GetBaseLogByID(string id);
        /// <summary>
        /// 根据VmBaseLog 模型写日志
        /// </summary>
        /// <param name="vmBaseLog"></param>
        void WriteLog(FaoB2BEntities context, VmBaseLog vmBaseLog);
    }
}
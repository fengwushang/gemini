﻿using Fao.Data.B2B;
using Fao.Data.B2B.SM;
using Fao.Data.B2B.VM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LeaveMsg服务接口-Power by CodeGG
    /// </summary>
    public interface ILeaveMsgService : ICrud<LeaveMsg>
    {
        /// <summary>
        /// 根据SmLeaveMsg查询模型，返回VmLeaveMsg视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmLeaveMsg> GetLeaveMsgs(SmLeaveMsg searchModel);

        /// <summary>
        /// 根据id，返回VmLeaveMsg视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmLeaveMsg GetLeaveMsgByID(string id);

        /// <summary>
        /// 添加留言（询价、报价）
        /// </summary>
        /// <param name="vmModel">VmLeaveMsg视图模型</param>
        /// <returns></returns>
        int AddLeaveMsg(VmLeaveMsg vmModel);

        /// <summary>
        /// 添加多个留言（询价、报价）
        /// </summary>
        /// <param name="vmModel"></param>
        /// <returns></returns>
        int AddLeaveMsgByIds(VmLeaveMsg vmModel);

        /// <summary>
        /// 返回分布对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        VmLeaveMsgPaging GetLeaveMsgsWithPager(SmLeaveMsg search,int page,int rows);

        /// <summary>
        /// 删除消息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string DeleteLeaveMsg(int id);

        /// <summary>
        /// 批量删除
        /// </summary>
        /// <param name="ids">id集合</param>
        /// <returns></returns>
        string DeleteLeaveMsgAll(string ids);

        /// <summary>
        /// 根据表名，id集合，返回要询价(报价、留言)的信息列表集合
        /// </summary>
        /// <param name="tableID">来源表</param>
        /// <param name="ids">id主键集合</param>
        /// <returns></returns>
        List<VMMsgObject> GetMsgObjects(string tableID, string ids);
    }
}

﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// HotWord服务接口-Power by CodeGG
    /// </summary>
    public interface IHotWordService : ICrud<HotWord>
    {
        /// <summary>
        /// 根据SmHotWord查询模型，返回VmHotWord视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>热词分页</returns>
        VmHotWordList GetHotWords(int id);


        /// <summary>
        /// 根据id，返回VmHotWord视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmHotWord GetHotWordByID(string id);

        /// <summary>
        /// 得到HotWord列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VmHotWordList GetHotWordPaging(SmHotWord sm, int page, int rows);

        /// <summary>
        /// 检索关键词时，插入数据库
        /// </summary>
        /// <param name="hw"></param>
        /// <returns></returns>
        void AddHotWord(string id, string type);

        /// <summary>
        /// 获取替换的热词
        /// </summary>
        /// <returns></returns>
        HotWordString GetHotWordString();
    }
}
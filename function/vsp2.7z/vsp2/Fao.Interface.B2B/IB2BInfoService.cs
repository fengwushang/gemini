﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// B2BInfo服务接口-Power by CodeGG
    /// </summary>
    public interface IB2BInfoService : ICrud<B2BInfo>
    {
        /// <summary>
        /// 根据SmB2BInfo查询模型，返回VmB2BInfo视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmB2BInfo> GetB2BInfos(SmB2BInfo searchModel);

        /// <summary>
        /// 根据id，返回VmB2BInfo视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmB2BInfo GetB2BInfoByID(FaoB2BEntities context,int id);

        /// <summary>
        /// 根据id，返回VmB2BInfo视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmB2BInfo GetB2BInfoByID(int id);
        /// <summary>
        /// 审批B2B信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string AuditingB2BInfo(string Encriptid,int auditingResult);

        /// <summary>
        /// 返回分布列表
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        VMB2BInfoList GetAuditingPager(SmB2BInfo searchModel, int page, int rows);


        /// <summary>
        /// 返回电商门户页面需要的供需信息列表。
        /// </summary>
        /// <param name="info">查询条件</param>
        /// <param name="page">当前第几页</param>
        /// <param name="rows">每页多少条</param>
        /// <returns></returns>
        VmInfoForHomePaging SearchInfosPaging(SmB2BInfo info, int page, int rows);

        /// <summary>
        /// 添加供应信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddSupplyInfo(VmSupply model, VmB2BInfoPicture picture);

        /// <summary>
        /// 修改供应信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateSupplyInfo(VmSupply model, VmB2BInfoPicture picture=null);

        /// <summary>
        /// 根据ID得到供应信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmSupply GetSupplyInfoBy(int id);

        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        VMSupplyPaging GetSupplyPager(SmSupply search,int page ,int rows);

        /// <summary>
        /// 添加求购信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddBuyInfo(VmBuy model, VmB2BInfoPicture picture);

        /// <summary>
        /// 修改求购信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateBuyInfo(VmBuy model, VmB2BInfoPicture picture=null);

        /// <summary>
        /// 根据ID得到求购信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmBuy GetBuyInfoBy(int id);

        /// <summary>
        /// 根据条件得到求购信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        VmBuyPaging GetBuyPager(SmBuy search,int page,int rows);

        /// <summary>
        /// 添加合作信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddCooperationInfo(VmCooperationInfo model,VmB2BInfoPicture picture);

        /// <summary>
        /// 修改合作信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateCooperationInfo(VmCooperationInfo model, VmB2BInfoPicture picture=null);

        /// <summary>
        /// 根据ID得到合作信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmCooperationInfo GetCooperationInfoBy(int id);

        /// <summary>
        /// 根据条件得到合作信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        VmCooperationPaging GetCooperationPager(SmCooperation search,int page,int rows);


        /// <summary>
        /// 添加招商信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddCanvassBussinessInfo(VmCanvassBussiness model,VmB2BInfoPicture picture);

        /// <summary>
        /// 修改招商信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateCanvassBussinessInfo(VmCanvassBussiness model,VmB2BInfoPicture picture=null);

        /// <summary>
        /// 根据ID得到招商信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmCanvassBussiness GetCanvassBussinessInfoBy(int id);

        /// <summary>
        /// 根据条件得到招商信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        VmCanvassBussinessPaging GetCanvassBussinessPager(SmCanvassBussiness search,int page,int rows);

        /// <summary>
        /// 获取比对信息列表
        /// </summary>
        /// <param name="ids">加密信息id集合字符串，用“,”分割</param>
        /// <returns></returns>
        List<VmB2BInfo> GetCompareInfos(string ids);
        /// <summary>
        /// 得到统计B2B信息
        /// </summary>
        /// <param name="type"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        VmCountInfo GetB2BInfoCount(int type);

        /// <summary>
        /// 添加代理信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="picture"></param>
        /// <returns></returns>
        string AddProxyInfo(VmProxy model,VmB2BInfoPicture picture);

        /// <summary>
        /// 修改代理信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateProxyInfo(VmProxy model, VmB2BInfoPicture picture=null);

        /// <summary>
        /// 根据ID得到代理信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmProxy GetProxyInfoBy(int id);

        /// <summary>
        /// 根据条件得到代理信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        VmProxyPaging GetProxyPager(SmProxy search, int page, int rows);

        /// <summary>
        /// 删除选择记录
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        string DeleteChooses(string[] IDs);

        /// <summary>
        /// 刷新选中记录
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        string RefreshChooses(string[] IDs);

        /// <summary>
        /// 提交选中记录
        /// </summary>
        /// <param name="IDs"></param>
        /// <returns></returns>
        string ApproveChooses(string[] IDs);

        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="b2bInfo"></param>
        void UpdateBrowserCount(VmB2BInfo b2bInfo);
    }
}
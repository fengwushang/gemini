﻿using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fao.Data.B2B;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-20 10:18:31
    /// BaseDictionary服务接口-Power by CodeGG
    /// </summary>
    public interface IBaseDictionaryService : ICrud<BaseDictionary>
    {
        /// <summary>
        /// 根据SmBaseDictionary查询模型，返回VmBaseDictionary视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmBaseDictionary> GetBaseDictionarys(SmBaseDictionary searchModel);

        /// <summary>
        /// 根据id，返回VmBaseDictionary视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmBaseDictionary GetBaseDictionaryByID(FaoB2BEntities context,int id);

        /// <summary>
        /// 添加字典项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddDictionItem(VmBaseDictionary model);

        /// <summary>
        /// 修改字典项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateDictionItem(VmBaseDictionary model);

        /// <summary>
        /// 删除字典项
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        int DeleteDictionItem(int id);

        /// <summary>
        /// 字典项上移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        string ItemUP(int ItemID);

        /// <summary>
        /// 字典项下移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        string ItemDown(int ItemID);
    }
}
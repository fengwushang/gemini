﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// Attachment服务接口-Power by CodeGG
    /// </summary>
    public interface IAttachmentService : ICrud<Attachment>
    {
        /// <summary>
        /// 根据SmAttachment查询模型，返回VmAttachment视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmAttachment> GetAttachments(FaoB2BEntities context,SmAttachment searchModel);

        /// <summary>
        /// 根据id，返回VmAttachment视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmAttachment GetAttachmentByID(FaoB2BEntities context,string id);

        /// <summary>
        /// 通过主表ID得到该ID下的所有图片信息
        /// </summary>
        /// <param name="PK"></param>
        /// <returns></returns>
        List<VmAttachment> GetAttachmentsByTablePK(FaoB2BEntities context,int PK,int type=6);

        /// <summary>
        /// 通过BelongTablePrikeyID得到所有图片信息
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        IQueryable<Attachment> GetAttachmentsByTableType(int type);

        /// <summary>
        /// 返回指定信息id集合的对应主要附件url
        /// </summary>
        /// <param name="infoIDs">指定信息id集合</param>
        /// <returns></returns>
        List<Attachment> GetMainAttachments(IQueryable<Attachment> query, IEnumerable<int> infoIDs);

        /// <summary>
        /// 添加附件
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddAttachment(FaoB2BEntities context,VmAttachment model);

        /// <summary>
        /// 更新附件
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateAttachment(FaoB2BEntities context,VmAttachment model);

        /// <summary>
        /// 删除附件
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string DeleteAttachment(FaoB2BEntities context,int id);

        /// <summary>
        /// 通过主表和主键ID得到该ID下的所有图片信息
        /// </summary>
        /// <param name="PK"></param>
        /// <returns></returns>
        List<VmAttachment> GetAttachmentsByTableAndPK(int table, int PK);
    }
}
﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Product服务接口-Power by CodeGG
    /// </summary>
    public interface IProductService : ICrud<Product>
    {
        /// <summary>
        /// 根据SmProduct查询模型，返回VmProduct视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmProduct> GetProducts(SmProduct searchModel);

        /// <summary>
        /// 根据id，返回VmProduct视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmProduct GetProductByID(int id);

        /// <summary>
        /// 根据询价产品id 集合串，返回VmProduct视图模型列表
        /// </summary>
        /// <param name="ids">询价产品id 集合串</param>
        /// <returns>视图模型列表</returns>
        List<VmProduct> GetProductsByIDs(string ids);
    }
}
﻿using Fao.Data.B2B;


namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: chf , 2013-07-11
    /// BaseLog服务接口- 
    /// </summary>
    public interface IBasePlatformService : ICrud<BasePlatform>
    {
        /// <summary>
        /// 添加一个新数据
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        int AddBasePlatform(BasePlatform model);

        /// <summary>
        /// 得到对应平台的用户ID
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="tid"></param>
        /// <returns></returns>
        int GetPlatformID(int uid, int tid);
    }
}

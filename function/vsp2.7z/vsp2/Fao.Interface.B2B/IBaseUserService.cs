﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections.Specialized;
using Fao.Data.B2B.MV;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// BaseUser服务接口-Power by CodeGG
    /// </summary>
    public interface IBaseUserService : ICrud<BaseUser>
    {
        /// <summary>
        /// 根据SmBaseUser查询模型，返回VmBaseUser视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmBaseUser> GetBaseUsers(SmBaseUser searchModel);

        /// <summary>
        /// 根据id，返回VmBaseUser视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmBaseUser GetBaseUserByID(string id);

        /// <summary>
        /// 验证用户名称密码是否正确
        /// </summary>
        /// <param name="userName">用户名aram>
        /// <param name="passWord">密码</param>
        /// <param name="error">错误</param>
        /// <returns></returns>
        bool ValidateUser(string userName, string passWord, ref NameValueCollection error);

        /// <summary>
        /// 用户登陆
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="autoLogin"></param>
        void Login(string email, string password, bool autoLogin);

        /// <summary>
        /// 检查Email是否补注册
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        int CheckEmail(string email);

        /// <summary>
        /// 注册用户
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        int RegisterUser(VmRegister model);

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="email"></param>
        /// <param name="NewPassword"></param>
        /// <param name="p"></param>
        /// <returns></returns>
        int ChangPassword(string email, string NewPassword, string OldPassword);

        /// <summary>
        ///登出
        /// </summary>
        void Logout();

        /// <summary>
        /// 得到当前用户
        /// </summary>
        /// <returns></returns>
        BaseUser CurrentUser();

        /// <summary>
        /// 得到当前用户
        /// </summary>
        /// <returns></returns>
        BaseUser CurrentUser(IQueryable<BaseUser> query);

        /// <summary>
        /// 获取当前用户id
        /// </summary>
        /// <returns></returns>
        string CurrentUserID();

        /// <summary>
        /// 获得当前用户信息及扩展信息
        /// </summary>
        /// <returns></returns>
        VMUserInfo GetCurrentUserInfo(FaoB2BEntities context);


        /// <summary>
        /// 获得当前用户信息及扩展信息
        /// </summary>
        /// <returns></returns>
        VMUserInfo GetCurrentUserInfo();

        /// <summary>
        /// 修改当前用户信息及扩展信息
        /// </summary>
        /// <param name="vm"></param>
        /// <returns></returns>
        string UpadateUserInfo(VMUserInfo vm);

        /// <summary>
        /// 修改当前用户的手机，手机验证码
        /// </summary>
        /// <param name="vm"></param>
        /// <returns></returns>
        string UpdateUserPhone(VMUserInfo vm);

        /// <summary>
        /// 邮箱激活验证
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        int VerifyUserMail(VmRegister model);

        /// <summary>
        /// 修改用户的邮箱 或手机
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="MailOrPhone"></param>
        /// <returns></returns>
        string UpdateUserMail(int uid, string MailOrPhone);

        /// <summary>
        /// 登录后设置Cookies
        /// </summary>
        /// <param name="user"></param>
        /// <param name="autoLogin"></param>
        void SetLoginCookies(BaseUser user, bool autoLogin);
    }
}
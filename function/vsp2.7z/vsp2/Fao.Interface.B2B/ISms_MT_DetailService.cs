﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-03-13 17:03:47
    /// Sms_MT_Detail服务接口-Power by CodeGG
    /// </summary>
    public interface ISms_MT_DetailService : ICrud<Sms_MT_Detail>
    {
        /// <summary>
        /// 根据SmSms_MT_Detail查询模型，返回VmSms_MT_Detail视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmSms_MT_Detail> GetSms_MT_Details(SmSms_MT_Detail searchModel);

        /// <summary>
        /// 根据id，返回VmSms_MT_Detail视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmSms_MT_Detail GetSms_MT_DetailByID(string id);


        /// <summary>
        /// 根据条件得到短信详细内容 的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VmSms_MT_DetailPaing GetSmSDetailPager(SmSms_MT_Detail search, int page, int rows);

        /// <summary>
        /// 根据条件得到 收件箱 的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VmSmsInboxPaging GetSmsInboxPager(smSmsInbox search, int page, int rows);


        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="MsgContent">短信内容</param>
        /// <param name="NumList">接收用户的UserID+"A"接收用户的手机号码(该号码必须经过验证)</param>
        /// 如 NumList：1365A13691433299,1366A15899998888
        /// <returns></returns> 
        string SendSms(string MsgContent, string NumList);
    }
}
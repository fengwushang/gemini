﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: sjp , 2013-07-18
    /// SMSBlackList服务接口-Power by sjp
    /// </summary>
    public interface ISMSBlackListService : ICrud<VmSMSBlackList>
    {
        #region 业务接口

        /// <summary>
        /// 根据SmSMSBlackList查询模型，返回SMSBlackList视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <param name="page">当前页数</param>
        /// <param name="rows">页大小</param>
        /// <returns>手机黑名单 视图模型列表</returns>
        List<VmSMSBlackList> GetSMSBlackLists(SmSMSBlackList searchModel);

        /// <summary>
        /// 根据id，返回SMSBlackList视图
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>手机黑名单 视图模型</returns>
        VmSMSBlackList GetSMSBlackListByID(string id);

        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="sm">关键字，发布时间</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">页大小</param>
        /// <returns>手机黑名单 </returns>
        VmSMSBlackListList GetSMSBlackListList(SmSMSBlackList sm, string page, string rows,string isNotSystemUser);

        /// <summary>
        /// 手机黑名单 保存
        /// </summary>
        /// <returns></returns>
        string Save(VmSMSBlackList model, string isNotSystemUser);

        #endregion   
    }
}

﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Area服务接口-Power by CodeGG
    /// </summary>
    public interface IBaseAreaService : ICrud<BaseArea>
    {
        /// <summary>
        /// 根据SmArea查询模型，返回VmArea视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmBaseArea> GetAreas(SmBaseArea searchModel);

        /// <summary>
        /// 根据id，返回VmArea视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmBaseArea GetAreaByID(string id);

        /// <summary>
        /// 删除地区，1删除成功，2已删除，其他为删除失败
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        int DeleteArea(int id);

        /// <summary>
        /// 更新地区
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateArea(VmBaseArea model);

        /// <summary>
        /// 添加地区
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddArea(VmBaseArea model);

        /// <summary>
        /// 地区上移
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string ItemUP(int id);

        /// <summary>
        /// 地区下移
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string ItemDown(int id);

        /// <summary>
        /// 返回地区信息的id，名称，父地区名称数据等。
        /// </summary>
        /// <param name="areaIDs">需要获取的地区id集合</param>
        /// <returns></returns>
        List<VmBaseArea> GetAreasWithParentName(IQueryable<BaseArea> query, List<int> areaIDs);
    }
}
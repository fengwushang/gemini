﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// BaseIndustry服务接口-Power by CodeGG
    /// </summary>
    public interface IBaseIndustryService : ICrud<BaseIndustry>
    {
        /// <summary>
        /// 根据SmBaseIndustry查询模型，返回VmBaseIndustry视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmBaseIndustry> GetBaseIndustrys(SmBaseIndustry searchModel);

        /// <summary>
        /// 根据id，返回VmBaseIndustry视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmBaseIndustry GetBaseIndustryByID(string id);

        /// <summary>
        /// 根把ID 返回VmBaseIndustry 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        List<VmBaseIndustry> GetIndustryWithParentName(List<int> industryIDs);

        /// <summary>
        /// 删除行业，1删除成功，2已删除，其他为删除失败
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        int DeleteInd(int id);

        /// <summary>
        /// 更新行业
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateInd(VmBaseIndustry model);

        /// <summary>
        /// 添加行业
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddInd(VmBaseIndustry model);

        /// <summary>
        /// 行业上移
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string ItemUP(int id);

        /// <summary>
        /// 行业下移
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        string ItemDown(int id);
         
    }
}
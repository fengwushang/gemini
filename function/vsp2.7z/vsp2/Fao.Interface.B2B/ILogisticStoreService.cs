﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticStore服务接口-Power by CodeGG
    /// </summary>
    public interface ILogisticStoreService : ICrud<LogisticStore>
    {
        /// <summary>
        /// 根据SmLogisticStore查询模型，返回VmLogisticStore视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmLogisticStore> GetLogisticStores(SmLogisticStore searchModel);

        /// <summary>
        /// 根据id，返回VmLogisticStore视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmLogisticStore GetLogisticStoreByID(string id);

        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        LogisticStorePaging GetLogisticStoreWithPage(SmLogisticStore searchModel, int pageIndex, int pageCount);


        /// <summary>
        /// 添加仓库信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddLogisticStoreInfo(VmLogisticStore model, VmB2BInfoPicture picture);

        /// <summary>
        /// 修改仓库信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateLogisticStoreInfo(VmLogisticStore model, VmB2BInfoPicture picture = null);

        /// <summary>
        /// 根据ID得到仓库信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmLogisticStore GetLogisticStoreInfoBy(string id);

        /// <summary>
        /// 根据ID得到仓库信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmLogisticStore GetLogisticStoreInfoBy(FaoB2BEntities context,string id);

        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        LogisticStorePaging GetLogisticStorePager(SmLogisticStore search, int page, int rows);

        /// <summary>
        /// 得到仓库统计信息
        /// </summary>
        /// <returns></returns>
        VmCountInfo GetLogisticStoreInfoCount();

        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,2刷新,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        string StoreBatch(int type, string chooses);

        /// <summary>
        /// 得到审批列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        LogisticStorePaging GetAuditingPager(SmLogisticStore sm, int page, int rows);

        /// <summary>
        /// 审批操作
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        string Auditing(string ID, int Result);

        /// <summary>
        /// 增加浏览数
        /// </summary>
        /// <param name="model"></param>
        void UpdateBrowserCount(VmLogisticStore model);
    }
}
﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections.Specialized;
using Fao.Data.B2B.MV;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: sjp , 2013-07-03
    /// BaseUser服务接口-Power by sjp
    /// </summary>
    
    public interface IBasePlatUserService
    {
        /// <summary>
        /// 检测登录账户是否存在
        /// </summary>
        /// <param name="IntTypeID"></param>
        /// <param name="userID"></param>
        /// <param name="VarTokenID"></param>
        /// <returns></returns>
        int GetCheckToken(int IntTypeID, int userID, string VarTokenID);
        /// <summary>
        /// 添加注册用户
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        int AddRegisterUser(VmBasePlatUser user);

        /// <summary>
        /// 添加注册用户
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        int AddRegisterUserWcf(VmBasePlatUser user);

        /// <summary>
        /// 插入到平台表中其他平台用户 2个
        /// </summary>
        int InsertOtherPlatform(string str);

        /// <summary>
        /// 从ps跳转登录
        /// </summary>
        /// <param name="userid"></param>
        void Login_ps(string userid);
        /// <summary>
        /// 向联合登录表中插入一条数据
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddEntity(PlatUser model);
        /// <summary>
        /// b2b向ps跳转检测用户是否存在
        /// </summary>
        /// <param name="IntTypeID"></param>
        /// <param name="userID"></param>
        /// <param name="VarTokenID"></param>
        /// <returns></returns>
        int GetPlatUser(int IntTypeID, int userID, string VarTokenID);
        /// <summary>
        /// 存在的话就删除这条数据
        /// </summary>
        /// <param name="IntTypeID"></param>
        /// <param name="userID"></param>
        /// <param name="VarTokenID"></param>
        /// <returns></returns>
        string DelPlatUser(int IntTypeID, int userID, string VarTokenID);
    }
}

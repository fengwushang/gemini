﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticVehicle服务接口-Power by CodeGG
    /// </summary>
    public interface ILogisticVehicleService : ICrud<LogisticVehicle>
    {
        /// <summary>
        /// 根据SmLogisticVehicle查询模型，返回VmLogisticVehicle视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmLogisticVehicle> GetLogisticVehicles(SmLogisticVehicle searchModel);

        /// <summary>
        /// 根据id，返回VmLogisticVehicle视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmLogisticVehicle GetLogisticVehicleByID(FaoB2BEntities context,string id);
        /// <summary>
        /// 根据id，返回VmLogisticVehicle视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmLogisticVehicle GetLogisticVehicleByID( string id);

        /// <summary>
        /// 添加车辆信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddVehicleInfo(VmLogisticVehicle model, VmB2BInfoPicture picture);

        /// <summary>
        /// 修改车辆信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateVehicleInfo(VmLogisticVehicle model, VmB2BInfoPicture picture = null);


        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        VMVehiclePaging GetVehiclePager(SmLogisticVehicle search, int page, int rows);

        /// <summary>
        /// 得到统计车辆信息
        /// </summary>
        /// <param name="type"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        VmCountInfo GetVehicleInfoCount();

        /// <summary>
        /// 得到当前用户的所有车辆信息
        /// </summary>
        /// <returns></returns>
        List<VmLogisticVehicle> GetCurrentUserVehicle();

        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        string VehicleBatch(int type, string chooses);

        /// <summary>
        /// 得到审批信息
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VMVehiclePaging GetAuditingPager(SmLogisticVehicle sm, int page, int rows);

        /// <summary>
        /// 审批
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        string Auditing(string ID, int Result);

        /// <summary>
        /// 检查车牌号是否存在
        /// </summary>
        /// <param name="LicenseNum">车牌号</param>
        /// <param name="id">主键ID</param>
        /// <returns></returns>
        bool CheckVehicle(string LicenseNum,string id);
    }
}
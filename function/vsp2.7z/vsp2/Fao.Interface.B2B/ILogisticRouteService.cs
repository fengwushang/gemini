﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticRoute服务接口-Power by CodeGG
    /// </summary>
    public interface ILogisticRouteService : ICrud<LogisticRoute>
    {
        /// <summary>
        /// 根据SmLogisticRoute查询模型，返回VmLogisticRoute视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmLogisticRoute> GetLogisticRoutes(SmLogisticRoute searchModel);

        /// <summary>
        /// 根据id，返回VmLogisticRoute视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmLogisticRoute GetLogisticRouteByID(string id);

        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        LogisticRoutePaging GetLogisticRouteWithPage(SmLogisticRoute searchModel, int pageIndex, int pageCount);

        /// <summary>
        /// 添加物流专线信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddLogisticRouteInfo(VmLogisticRoute model, VmB2BInfoPicture picture);

        /// <summary>
        /// 修改物流专线信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateLogisticRouteInfo(VmLogisticRoute model, VmB2BInfoPicture picture = null);

        /// <summary>
        /// 根据ID得到物流专线信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmLogisticRoute GetLogisticRouteInfoBy(string id);

        /// <summary>
        /// 根据ID得到物流专线信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmLogisticRoute GetLogisticRouteInfoBy(FaoB2BEntities context, string id);

        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        LogisticRoutePaging GetLogisticRoutePager(SmLogisticRoute search, int page, int rows);

        /// <summary>
        /// 得到物流专线统计信息
        /// </summary>
        /// <returns></returns>
        VmCountInfo GetLogisticRouteInfoCount();

        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,2刷新,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        string RouteBatch(int type, string chooses);

        /// <summary>
        /// 审批分页信息
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        LogisticRoutePaging GetAuditingPager(SmLogisticRoute sm, int page, int rows);

        /// <summary>
        /// 审批操作
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        string Auditing(string ID, int Result);

        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="model"></param>
        void UpdateBrowserCount(VmLogisticRoute model);
    }
}
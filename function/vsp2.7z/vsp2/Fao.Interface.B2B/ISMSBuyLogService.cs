﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// SMSBuyLog服务接口-Power by CodeGG
    /// </summary>
    public interface ISMSBuyLogService : ICrud<SMSBuyLog>
    {
        /// <summary>
        /// 根据SmSMSBuyLog查询模型，返回VmSMSBuyLog视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmSMSBuyLog> GetSMSBuyLogs(SmSMSBuyLog searchModel);


        /// <summary>
        /// 根据条件得到 购买记录 的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VmSMSBuyLogPaging GetSmSMSBuyLogPager(SmSMSBuyLog search, int page, int rows);

        /// <summary>
        /// 根据id，返回VmSMSBuyLog视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmSMSBuyLog GetSMSBuyLogByID(string id);

        /// <summary>
        /// 登录用户购买短信
        /// </summary>
        /// <param name="buySum"></param>
        /// <param name="payPwd"></param>
        /// <returns></returns>
        string BuyPhoneSms(string buySum, string payPwd);

        /// <summary>
        /// 发短信，更改剩余短信的条数
        /// </summary>
        /// <param name="sendCount"></param>
        /// <returns></returns>
        string updateMsgCount(int sendCount);

    }
}
﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// LogisticVehicleSource服务接口-Power by CodeGG
    /// </summary>
    public interface ILogisticVehicleSourceService : ICrud<LogisticVehicleSource>
    {
        /// <summary>
        /// 根据SmLogisticVehicleSource查询模型，返回VmLogisticVehicleSource视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmLogisticVehicleSource> GetLogisticVehicleSources(SmLogisticVehicleSource searchModel);

        /// <summary>
        /// 根据id，返回VmLogisticVehicleSource视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmLogisticVehicleSource GetLogisticVehicleSourceByID(string id);    


        /// <summary>
        /// 添加车源信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddVechicleSourceInfo(VmLogisticVehicleSource model, VmB2BInfoPicture picture);

        /// <summary>
        /// 修改车源信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateVehicleSourceInfo(VmLogisticVehicleSource model, VmB2BInfoPicture picture = null);

        /// <summary>
        /// 根据ID得到车源信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmLogisticVehicleSource GetVehicleSourceInfoBy(string id);

        /// <summary>
        /// 根据ID得到车源信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmLogisticVehicleSource GetVehicleSourceInfoBy(FaoB2BEntities context, string id);

        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        LogisticVehicleSourcePaging GetVehicleSourcePager(SmLogisticVehicleSource search, int page, int rows);

        /// <summary>
        /// 得到车源统计信息
        /// </summary>
        /// <returns></returns>
        VmCountInfo GetVehicleSourceInfoCount();
        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        LogisticVehicleSourcePaging GetLogisticVehicleSourcesWithPage(SmLogisticVehicleSource searchModel, int pageIndex, int pageCount);

        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,2刷新,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        string VehicleSourceBatch(int type, string chooses);

        /// <summary>
        /// 得到审批分页信息
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        LogisticVehicleSourcePaging GetAuditingPager(SmLogisticVehicleSource sm, int page, int rows);

        /// <summary>
        /// 审批信息
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        string Auditing(string ID, int Result);

        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="model"></param>
        void UpdateBrowserCount(VmLogisticVehicleSource model);
    }
}
﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Enterprise服务接口-Power by CodeGG
    /// </summary>
    public interface IEnterpriseService : ICrud<Enterprise>
    {
        /// <summary>
        /// 根据SmEnterprise查询模型，返回VmEnterprise视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmEnterprise> GetEnterprises(SmEnterprise searchModel);

        /// <summary>
        /// 根据id，返回VmEnterprise视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmEnterprise GetEnterpriseByID(FaoB2BEntities context, string id);
        /// <summary>
        /// 根据id，返回VmEnterprise视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmEnterprise GetEnterpriseByID( string id);
        /// <summary>
        /// 根据用户的企业信息
        /// </summary>
        /// <returns></returns>
        VmEnterprise GetCurrentEnterprise(FaoB2BEntities context);

        /// <summary>
        /// 获取企业用户管理列表分页数据
        /// </summary>
        /// <param name="user">查询条件</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页条数</param>
        /// <returns></returns>
        VmEnterprisePaging GetAdminEnterprises(SmEnterprise ent, int page, int rows);

        /// <summary>
        /// 获取当前企业信息
        /// </summary>
        /// <returns></returns>
        VMEntInfo GetCurrentEntInfo();

        /// <summary>
        /// 修改企业资料
        /// </summary>
        /// <param name="vmModel"></param>
        /// <returns></returns>
        string UpdateEntInfo(VMEntInfo vmModel);

        /// <summary>
        /// 冻结企业
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        string FreezeEnt(int eid);   
    }
}
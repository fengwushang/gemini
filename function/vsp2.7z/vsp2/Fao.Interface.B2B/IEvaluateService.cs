﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Evaluate服务接口-Power by CodeGG
    /// </summary>
    public interface IEvaluateService : ICrud<Evaluate>
    {
        /// <summary>
        /// 根据SmEvaluate查询模型，返回VmEvaluate视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmEvaluate> GetEvaluates(SmEvaluate searchModel);

        /// <summary>
        /// 根据id，返回VmEvaluate视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmEvaluate GetEvaluateByID(string id);

        /// <summary>
        /// 根据信息id，类型。返回该信息的评论列表分页数据
        /// </summary>
        /// <param name="id">页面实体的id</param>
        /// <param name="type">实体属于哪类表</param>
        /// <returns></returns>
        VmEvaluatePaging GetMessageEvaluates(int id, int type);

        /// <summary>
        /// 添加指定类型，指定表主键的评论。返回成功标识
        /// </summary>
        /// <param name="comment"></param>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <returns>1成功，2当前用户未登录</returns>
        string AddMessageEvaluate(VmEvaluate comment, int id, int type);
    }
}
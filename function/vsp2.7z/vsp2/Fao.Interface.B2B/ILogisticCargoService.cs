﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticCargo服务接口-Power by CodeGG
    /// </summary>
    public interface ILogisticCargoService : ICrud<LogisticCargo>
    {
        /// <summary>
        /// 根据SmLogisticCargo查询模型，返回VmLogisticCargo视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmLogisticCargo> GetLogisticCargos(SmLogisticCargo searchModel);

        /// <summary>
        /// 根据id，返回VmLogisticCargo视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmLogisticCargo GetLogisticCargoByID(string id);

        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="searchModel"></param>
        /// <returns></returns>
        LogisticCargoPaging GetLogisticCargosWithPage(SmLogisticCargo searchModel, int pageIndex, int pageCount);

        /// <summary>
        /// 添加货源信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddLogisticCargoInfo(VmLogisticCargo model, VmB2BInfoPicture picture);

        /// <summary>
        /// 修改货源信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string UpdateLogisticCargoInfo(VmLogisticCargo model, VmB2BInfoPicture picture = null);

        /// <summary>
        /// 根据ID得到货源信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmLogisticCargo GetLogisticCargoInfoBy(string id);

        /// <summary>
        /// 根据ID得到货源信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        VmLogisticCargo GetLogisticCargoInfoBy(FaoB2BEntities context, string id);


        /// <summary>
        /// 根据条件得到信息的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        LogisticCargoPaging GetLogisticCargoPager(SmLogisticCargo search, int page, int rows);

        /// <summary>
        /// 得到货源统计信息
        /// </summary>
        /// <returns></returns>
        VmCountInfo GetLogisticCargoInfoCount();

        /// <summary>
        /// 批量操作
        /// </summary>
        /// <param name="type">操作类型1删除,2刷新,3提交</param>
        /// <param name="chooses"></param>
        /// <returns></returns>
        string CargoBatch(int type, string chooses);

        /// <summary>
        /// 得到审批列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        LogisticCargoPaging GetAuditingPager(SmLogisticCargo sm, int page, int rows);

        /// <summary>
        /// 审批
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Result"></param>
        /// <returns></returns>
        string Auditing(string ID, int Result);

        /// <summary>
        /// 增加浏览次数
        /// </summary>
        /// <param name="model"></param>
        void UpdateBrowserCount(VmLogisticCargo model);
    }
}
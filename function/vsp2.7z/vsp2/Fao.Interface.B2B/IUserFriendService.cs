﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// UserFriend服务接口-Power by CodeGG
    /// </summary>
    public interface IUserFriendService : ICrud<UserFriend>
    {
        /// <summary>
        /// 根据SmUserFriend查询模型，返回VmUserFriend视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmUserFriend> GetUserFriends(SmUserFriend searchModel);

        /// <summary>
        /// 根据id，返回VmUserFriend视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmUserFriend GetUserFriendByID(int id);

        /// <summary>
        /// 添加一条好友或关注记录。返回添加信息
        /// </summary>
        /// <param name="userid">要添加的用户id</param>
        /// <param name="type">该好友的类型id，2为加关注，1为加好友</param>
        /// <returns>0为操作失败，1为操作成功，2为当前用户未登录，3为已存在该记录</returns>
        string AddFriend(int userid, int type);

        /// <summary>
        /// 返回好友或关注列表
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        VmUserFriendPaging GetUserFriendsWithPage(SmUserFriend search, int page, int rows);

        /// <summary>
        /// 删除好友或关注信息
        /// </summary>
        /// <param name="friendID"></param>
        /// <returns></returns>
        string DeleteFriend(int friendID);

    }
}
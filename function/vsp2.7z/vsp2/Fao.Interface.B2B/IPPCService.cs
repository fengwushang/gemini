﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// PPC服务接口-Power by CodeGG
    /// </summary>
    public interface IPPCService : ICrud<PPC>
    {
        /// <summary>
        /// 根据SmPPC查询模型，返回VmPPC视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmPPC> GetPPCs(SmPPC searchModel);

        /// <summary>
        /// 根据id，返回VmPPC视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmPPC GetPPCByID(string id);

        /// <summary>
        /// 该热词在该类信息的竞价历史
        /// </summary>
        /// <param name="id"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        VmPPCPaging GetOneHotWordHistory(string id, string keyword);


        /// <summary>
        /// 添加一条信息
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddPPC(VmPPC model, List<Tuple<string, string>> timeSpan, string payPassword);

        /// <summary>
        /// 显示用户推广列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VmPPCPaging GetPPCPager(SmPPC sm, int page, int rows);

        /// <summary>
        /// 改变状态
        /// </summary>
        /// <param name="state"></param>
        /// <param name="EncryptID"></param>
        /// <returns></returns>
        string ChangeFlag(int state, string EncryptID);

        /// <summary>
        /// 扣除竞价费用
        /// </summary>
        /// <param name="ppc">竞价ID</param>
        /// <returns></returns>
        int DeductionForExpenses(string ppc);

        /// <summary>
        /// 竞价记录分页数据
        /// </summary>
        /// <param name="searchModel"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageCount"></param>
        /// <returns></returns>
        VMPPCRecordPaging GetPPCRecordsWithPage(SmPPCRecord searchModel, int pageIndex, int pageCount);


        /// <summary>
        /// 得到用户出价列表
        /// </summary>
        /// <param name="sm"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VmPPCPaging GetPPCPaging(SmPPC sm, int page, int rows);

        /// <summary>
        /// 删除推广记录
        /// </summary>
        /// <param name="ppcType">推广类型</param>
        /// <param name="keyID">推广逐渐</param>
        /// <returns></returns>
        int DeletePPC(int ppcType, int keyID);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Interface.B2B
{
    public interface ISiteSetService
    {
        /// <summary>
        /// 生成首页数据
        /// </summary>
        /// <returns></returns>
        string SetIndex();
    }
}

﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-03-13 17:03:47
    /// Sms_MT_Batch服务接口-Power by CodeGG
    /// </summary>
    public interface ISms_MT_BatchService : ICrud<Sms_MT_Batch>
    {
        /// <summary>
        /// 根据SmSms_MT_Batch查询模型，返回VmSms_MT_Batch视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmSms_MT_Batch> GetSms_MT_Batchs(SmSms_MT_Batch searchModel);

        /// <summary>
        /// 根据id，返回VmSms_MT_Batch视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmSms_MT_Batch GetSms_MT_BatchByID(string id);

        /// <summary>
        /// 根据条件得到发件箱 的分页对象
        /// </summary>
        /// <param name="search"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <returns></returns>
        VmSms_MT_BatchPaging GetSmSmsBatchPager(SmSms_MT_Batch search, int page, int rows);

        /// <summary>
        /// 删除短信
        /// </summary>
        /// <param name="IDList"></param>
        /// <returns></returns>
        string DeleteSMSChoose(string IDList);

    }
}
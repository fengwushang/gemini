﻿using Fao.Data.B2B;
using Fao.Data.B2B.VM;
using Fao.Data.B2B.SM;
using Fao.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fao.Interface.B2B
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Category服务接口-Power by CodeGG
    /// </summary>
    public interface ICategoryService : ICrud<Category>
    {
        /// <summary>
        /// 根据SmCategory查询模型，返回VmCategory视图模型列表
        /// </summary>
        /// <param name="searchModel">查询模型</param>
        /// <returns>视图模型列表</returns>
        List<VmCategory> GetCategorys(SmCategory searchModel);

        /// <summary>
        /// 根据id，返回VmCategory视图模型
        /// </summary>
        /// <param name="id">实体主键id</param>
        /// <returns>视图模型</returns>
        VmCategory GetCategoryByID(int id);

        /// <summary>
        /// 添加分类项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string AddCategory(VmCategory model);

        /// <summary>
        /// 修改分类项
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        string Updatecategory(VmCategory model);

        /// <summary>
        /// 删除分类项
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        int DeleteCategory(int id);

        /// <summary>
        /// 分类项上移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        string ItemUP(int ItemID);

        /// <summary>
        /// 分类项下移
        /// </summary>
        /// <param name="ItemID"></param>
        /// <returns></returns>
        string ItemDown(int ItemID);

    }
}
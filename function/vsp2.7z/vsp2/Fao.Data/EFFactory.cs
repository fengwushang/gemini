﻿
using Fao.Common;
using Fao.Data.B2B;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data
{
    /// <summary>
    /// created by：yzq 2013-01-17
    /// EF实体框架数据提供工厂
    /// </summary>
    public sealed class EFFactory
    {
        #region B2BEF
        private static FaoB2BEntities _B2BEF;
        private static FaoB2BEntities B2BEF
        {
            get
            {
                //通过配置文件"EFmode"，判断处理返回单例，或新实例
                switch (Utils.GetAppValueByName("EFmode"))
                {
                    case "Single":
                        if (_B2BEF == null)
                        {
                            _B2BEF = new FaoB2BEntities();
                        }
                        return _B2BEF;
                    case "New":
                        return new FaoB2BEntities(); 
                    default:
                        return new FaoB2BEntities();

                }
            }
             
        }

        #endregion

        public static DbContext GetEF(string dbName)
        {

            switch (dbName)
            {

                case "FaoB2BEntities":
                    return B2BEF;

                default:
                    throw new Exception("@解析EF实例异常：请检查EF(" + dbName + ")是否存在！");

            }
        }

        public static void RestartEF(string dbName)
        {
            switch (dbName)
            {

                case "FaoB2BEntities":
                     _B2BEF= null;
                     break;
                default:
                    throw new Exception("@解析EF实例异常：请检查EF(" + dbName + ")是否存在！");

            }
        }

        
         
    }
}

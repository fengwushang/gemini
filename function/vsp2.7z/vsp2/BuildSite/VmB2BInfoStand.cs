﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuildSite
{
    public class VmB2BInfoStand
    {
        /// <summary>
        /// B2BInfo的主键ID
        /// </summary>
        public int IntInfoID { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public DateTime DteRefresh { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        public string VaInfoTitle { get; set; }

        /// <summary>
        /// 要价
        /// </summary>
        public string VarPriceAsk { get; set; }

        /// <summary>
        /// 地区
        /// </summary>
        public string VarAreaName { get; set; }

        /// <summary>
        /// 类型ID
        /// </summary>
        public int IntInfoType { get; set; }

        /// <summary>
        /// 单价
        /// </summary>
        public Decimal DecUnitPrice { get; set; }

        /// <summary>
        /// 单位
        /// </summary>
        public string VarUnitName { get; set; }

        /// <summary>
        /// 需求量
        /// </summary>
        public int IntTotalAvailability { get; set; }

        /// <summary>
        /// 最低保障金
        /// </summary>
        public int IntMinSecurityDeposit { get; set; }
    }
}

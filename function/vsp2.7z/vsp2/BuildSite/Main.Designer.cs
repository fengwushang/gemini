﻿namespace BuildSite
{
    partial class Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CbCreateIndexSpan = new System.Windows.Forms.ComboBox();
            this.LabCreatePsIndex = new System.Windows.Forms.Label();
            this.BtnCreateB2BIndex = new System.Windows.Forms.Button();
            this.TimerIndex = new System.Windows.Forms.Timer(this.components);
            this.btn_cj = new System.Windows.Forms.Button();
            this.lab_CJ = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(108, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 19;
            this.label2.Text = "分钟";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 18;
            this.label1.Text = "每隔";
            // 
            // CbCreateIndexSpan
            // 
            this.CbCreateIndexSpan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CbCreateIndexSpan.FormattingEnabled = true;
            this.CbCreateIndexSpan.Items.AddRange(new object[] {
            "2",
            "4",
            "6",
            "8",
            "10",
            "30",
            "60",
            "720",
            "1440",
            "10080"});
            this.CbCreateIndexSpan.Location = new System.Drawing.Point(54, 20);
            this.CbCreateIndexSpan.Name = "CbCreateIndexSpan";
            this.CbCreateIndexSpan.Size = new System.Drawing.Size(48, 20);
            this.CbCreateIndexSpan.TabIndex = 17;
            // 
            // LabCreatePsIndex
            // 
            this.LabCreatePsIndex.AutoSize = true;
            this.LabCreatePsIndex.ForeColor = System.Drawing.Color.BlueViolet;
            this.LabCreatePsIndex.Location = new System.Drawing.Point(250, 26);
            this.LabCreatePsIndex.Name = "LabCreatePsIndex";
            this.LabCreatePsIndex.Size = new System.Drawing.Size(41, 12);
            this.LabCreatePsIndex.TabIndex = 16;
            this.LabCreatePsIndex.Text = "消息：";
            // 
            // BtnCreateB2BIndex
            // 
            this.BtnCreateB2BIndex.Location = new System.Drawing.Point(156, 16);
            this.BtnCreateB2BIndex.Name = "BtnCreateB2BIndex";
            this.BtnCreateB2BIndex.Size = new System.Drawing.Size(88, 31);
            this.BtnCreateB2BIndex.TabIndex = 15;
            this.BtnCreateB2BIndex.Text = "生成首页";
            this.BtnCreateB2BIndex.UseVisualStyleBackColor = true;
            this.BtnCreateB2BIndex.Click += new System.EventHandler(this.BtnCreateB2BIndex_Click);
            // 
            // TimerIndex
            // 
            this.TimerIndex.Tick += new System.EventHandler(this.TimerIndex_Tick);
            // 
            // btn_cj
            // 
            this.btn_cj.Location = new System.Drawing.Point(156, 73);
            this.btn_cj.Name = "btn_cj";
            this.btn_cj.Size = new System.Drawing.Size(88, 31);
            this.btn_cj.TabIndex = 20;
            this.btn_cj.Text = "生成CSS和JS";
            this.btn_cj.UseVisualStyleBackColor = true;
            this.btn_cj.Click += new System.EventHandler(this.btn_cj_Click);
            // 
            // lab_CJ
            // 
            this.lab_CJ.AutoSize = true;
            this.lab_CJ.ForeColor = System.Drawing.Color.BlueViolet;
            this.lab_CJ.Location = new System.Drawing.Point(250, 82);
            this.lab_CJ.Name = "lab_CJ";
            this.lab_CJ.Size = new System.Drawing.Size(41, 12);
            this.lab_CJ.TabIndex = 21;
            this.lab_CJ.Text = "消息：";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(692, 262);
            this.Controls.Add(this.lab_CJ);
            this.Controls.Add(this.btn_cj);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CbCreateIndexSpan);
            this.Controls.Add(this.LabCreatePsIndex);
            this.Controls.Add(this.BtnCreateB2BIndex);
            this.Name = "Main";
            this.Text = "B2B电子商务自动生成程序";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CbCreateIndexSpan;
        private System.Windows.Forms.Label LabCreatePsIndex;
        private System.Windows.Forms.Button BtnCreateB2BIndex;
        private System.Windows.Forms.Timer TimerIndex;
        private System.Windows.Forms.Button btn_cj;
        private System.Windows.Forms.Label lab_CJ;
    }
}


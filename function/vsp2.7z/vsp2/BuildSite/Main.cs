﻿using Fao.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Configuration;

namespace BuildSite
{
    public partial class Main : Form
    {
        public static XElement validSite = null;

        public static string SitePath = string.Empty;

        public Main()
        {
            InitializeComponent();
            //初始化信息
            InitB2BSite();

        }

        private void BtnCreateB2BIndex_Click(object sender, EventArgs e)
        {
            B2BIndex();//生成首页
        }

        private void InitB2BSite()
        {
            //初始化下拉列表
            this.CbCreateIndexSpan.SelectedIndex = 5;

            SitePath = Application.StartupPath.Remove(Application.StartupPath.LastIndexOf("\\") + 1);
            //SitePath = @"D:\gongzuo\FaoB2B\Code\FaoB2B\";
            var configPath = SitePath + "Config\\Site.config";
            //读取配置文件节点
            XDocument siteXml = XDocument.Load(configPath);

            //获取有当前效配置节点
            validSite = siteXml.XPathSelectElement("//site[@name='" + siteXml.Root.Attribute("valid").Value + "']");
        }

        /// <summary>
        /// 生成B2B首页
        /// </summary>
        private void B2BIndex()
        {
            //BtnCreateB2BIndex.Enabled = false;
            //CbCreateIndexSpan.Enabled = false;
            TimerIndex.Interval = 1000 * 60;//一分钟
            TimerIndex.Start();
            indextime = int.Parse(CbCreateIndexSpan.Text) - 1;
            #region 生成
            string IndexHtml = string.Empty;
            string replaceHtml = string.Empty;
            try
            {
                string accessPath = validSite.Element("index").Attribute("accessRule").Value;
                //保存首页的根路径 + 首页替换规则生成的路径
                string savePath = IOHelper.GetPath(validSite.Element("path").Value) + accessPath;
                //首页模板的路径
                string tempPath = SitePath + validSite.Element("index").Value;
                //网站根目录
                string indexPath = validSite.Element("uri").Value;
                //ps网站根目录
                string psPath = validSite.Element("ps").Value;
                //模板文件内容
                IndexHtml = IOHelper.ReadFromFile(tempPath);
                SqlParameter[] commandParameters = new SqlParameter[] { };
                StringBuilder buider = new StringBuilder("ProcGetSiteIndexData");
                DataSet ds = SQLPlus.ExecuteDataSet(CommandType.StoredProcedure, buider, commandParameters);
                //dataset返回的数据表依次为: 货源、库源、车辆、专线，供求招合代
                #region 替换站点
                IndexHtml = IndexHtml.Replace("<%=site%>", indexPath);

                IndexHtml = IndexHtml.Replace("<%=ps%>", validSite.Element("ps").Value);
                #endregion

                #region 替换发布信息平台
                Dictionary<int, string> mydics = new Dictionary<int, string>();
                mydics.Add(1, indexPath + "My/SupplyIndex?state=3&mid=11");
                mydics.Add(2, indexPath + "My/BuyIndex?state=3&mid=12");
                mydics.Add(3, indexPath + "My/CanvassBussinessIndex?state=3&mid=13");
                mydics.Add(4, indexPath + "My/CooperationIndex?state=3&mid=14");
                mydics.Add(5, indexPath + "My/ProxyIndex?state=3&mid=15");
                mydics.Add(6, indexPath + "Logistic/CargoIndex?mid=21&state=3");
                mydics.Add(7, indexPath + "Logistic/StoreIndex?&mid=22&state=3");
                mydics.Add(8, indexPath + "Logistic/VehicleSourceIndex?mid=23");
                mydics.Add(9, indexPath + "Logistic/RouteIndex?mid=24");

                foreach (var mydic in mydics)
                {
                    IndexHtml = IndexHtml.Replace(string.Format("<%=B2BMy_{0}%>", mydic.Key), mydic.Value);
                }

                #endregion

                var context = new FaoB2B_DevEntities();
                #region 替换热词
                string lowString = string.Empty;
                var words = context.HotWords.Where(e => e.IntWordType < 6)
                    .GroupBy(e => new { e.IntWordType, e.VarWord })
                    .Select(e => new
                    {
                        IntWordType = e.Key.IntWordType,
                        VarWord = e.Key.VarWord,
                        Count = e.Count()
                    })
                    .GroupBy(e => e.IntWordType)
                    .Select(e => new
                    {
                        IntWordType = e.Key,
                        Words = e.OrderByDescending(n => n.Count).Take(5)
                    }).ToList();

                //替换供应
                var gys = words.Where(e => e.IntWordType == 1).Select(e => e.Words).FirstOrDefault();
                if (gys != null)
                {
                    foreach (var gy in gys)
                    {
                        lowString += string.Format("<li><a class='.word'  href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a></li> ", indexPath, gy.IntWordType, gy.VarWord);
                    }
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoHotWord_g%>", lowString);
                lowString = string.Empty;
                //求购
                var qgs = words.Where(e => e.IntWordType == 2).Select(e => e.Words).FirstOrDefault();
                if (qgs != null)
                {
                    foreach (var qg in qgs)
                    {
                        lowString += string.Format("<li><a class='.word'  href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a></li> ", indexPath, qg.IntWordType, qg.VarWord);
                    }
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoHotWord_q%>", lowString);
                lowString = string.Empty;
                //招商
                var zss = words.Where(e => e.IntWordType == 3).Select(e => e.Words).FirstOrDefault();
                if (zss != null)
                {
                    foreach (var zs in zss)
                    {
                        lowString += string.Format("<li><a class='.word'   href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a> <li>", indexPath, zs.IntWordType, zs.VarWord);
                    }
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoHotWord_z%>", lowString);
                lowString = string.Empty;
                //合作
                var hzs = words.Where(e => e.IntWordType == 4).Select(e => e.Words).FirstOrDefault();
                if (hzs != null)
                {
                    foreach (var hz in hzs)
                    {
                        lowString += string.Format("<li><a class='.word'  href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a> </li>", indexPath, hz.IntWordType, hz.VarWord);
                    }
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoHotWord_h%>", lowString);
                lowString = string.Empty;
                //代理
                var dls = words.Where(e => e.IntWordType == 5).Select(e => e.Words).FirstOrDefault();
                if (dls != null)
                {
                    foreach (var dl in dls)
                    {
                        lowString += string.Format("<li><a class='.word'  href='{0}home/Infos/{1}/{2}' target='_blank'>{2}</a> </li>", indexPath, dl.IntWordType, dl.VarWord);
                    }
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoHotWord_d%>", lowString);
                lowString = string.Empty;
                #endregion

                #region 替换货源、库源、车辆、专线
                //替换货源数据
                replaceHtml = string.Empty;
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    replaceHtml += string.Format("<tr><td><a href='{5}' target='_blank'>{0}</a></td><td>{1}---{2}</td><td>{3}  kg</td><td>{4}</td>", dr["VarCargoTitle"], dr["sArea"], dr["eArea"], Utils.DecimalFormat2(dr["VarCargoWeight"].ToString()), dr["DteRefresh"], indexPath + "Logistic/CargoInfo/" + Security.Encrypt(dr["IntCargoID"]) + "?tab=6");
                }
                IndexHtml = IndexHtml.Replace("<%=Cargo%>", replaceHtml);


                //替换库源数据
                replaceHtml = string.Empty;
                foreach (DataRow dr in ds.Tables[1].Rows)
                {
                    replaceHtml += string.Format("<tr><td><a href='{5}' target='_blank'>{0}</a></td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td>"
                        , dr["VarStoreTitle"], dr["VarItemName"]
                        , Utils.DecimalFormat2(dr["IntStoreUseCapacity"].ToString()) + "  m³"
                        , dr["VarAreaName"]
                        , dr["DteRefresh"], indexPath + "Logistic/StoreInfo/" + Security.Encrypt(dr["IntStoreID"]) + "?tab=7");
                }
                IndexHtml = IndexHtml.Replace("<%=Store%>", replaceHtml);


                //替换车源数据
                replaceHtml = string.Empty;
                foreach (DataRow dr in ds.Tables[2].Rows)
                {
                    replaceHtml += string.Format("<tr><td><a href='{6}' target='_blank'>{0}</a></td><td><a href='{6}' target='_blank'>{1}</a></td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td>"
                        , dr["sArea"], dr["eArea"]
                        , dr["VehicleType"]
                        , dr["VaVehicleSize"] + "  m³"
                        , Utils.DecimalFormat2(dr["VarMaxLoad"].ToString()) + "  吨"
                        , dr["DteRefresh"]
                        , indexPath + "Logistic/VehicleSourceInfo/" + Security.Encrypt(dr["IntVehicleSourceID"]) + "?tab=8"
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=VehicleSource%>", replaceHtml);


                //替换专线
                replaceHtml = string.Empty;
                foreach (DataRow dr in ds.Tables[3].Rows)
                {
                    replaceHtml += string.Format("<tr><td><a href='{6}' target='_blank'>{0}</a></td><td><a href='{6}' target='_blank'>{1}</a></td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td>"
                        , dr["sArea"], dr["eArea"]
                        , dr["VarGoodsType"], dr["LoadAsk"]
                        , dr["IntIsBF"], dr["DteRefresh"]
                        , indexPath + "Logistic/RouteInfo/" + Security.Encrypt(dr["IntRouteID"]) + "?tab=8"
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=Route%>", replaceHtml);

                #endregion

                #region 替换供求招合代

                DataTable dt = ds.Tables[4];
                List<VmB2BInfoStand> infos = Utils.List<VmB2BInfoStand>(dt);
                #region 老版本替换
                ////文件id集合
                //var infoIDs = infos.Select(e => e.IntInfoID);
                ////附件ID集合
                //var attList = attachmentService.GetMainAttachments(context.Attachments, infoIDs)
                //                        .Select(e => new
                //                        {
                //                            e.IntBelongTablePrikeyID,
                //                            e.VarFilePath
                //                        }).ToList();
                ////结果集
                //var list = infos.Join(attList, p => p.IntInfoID, q => q.IntBelongTablePrikeyID, (p, q) => new
                //{
                //    p.IntInfoID,
                //    p.VaInfoTitle,
                //    p.VarAreaName,
                //    VarPriceAsk = string.IsNullOrEmpty(p.VarPriceAsk) ? "面议" : p.VarPriceAsk,
                //    p.DteRefresh,
                //    p.IntInfoType,
                //    q.VarFilePath,
                //    DecUnitPrice=Utils.DecimalFormat2(p.DecUnitPrice.ToString()),
                //    p.VarUnitName,
                //    IntTotalAvailability = Utils.DecimalFormat2(p.IntTotalAvailability.ToString()),
                //    IntMinSecurityDeposit=Utils.DecimalFormat2(p.IntMinSecurityDeposit.ToString())
                //});

                //List<string> urlList = new List<string> { "b2binfo/Sell/{1}?t=1", "b2binfo/Buy/{1}?t=2", "b2binfo/Invest/{1}?t=3", "b2binfo/Cooperate/{1}?t=4", "b2binfo/Proxy/{1}?t=5" };
                //for (int i = 0; i < urlList.Count; i++)
                //{
                //    //替换供应
                //    var b2bList = list.Where(e => e.IntInfoType == (i + 1)).ToList();
                //    int b2bCount = b2bList.Count;
                //    foreach (var item in b2bList)
                //    {
                //        //替换图片
                //        int index = b2bList.IndexOf(item);

                //        //替换第一条和第6条的图片图片
                //        if (index == 0 || index == 5)
                //        {
                //            IndexHtml = IndexHtml.Replace(string.Format("<%=B2BInfo{0}_{1}_Tit%>", (i + 1), (index + 1)), item.VaInfoTitle);
                //            IndexHtml = IndexHtml.Replace(string.Format("<%=B2BInfo{0}_{1}_Img%>", (i + 1), (index + 1)), item.VarFilePath);
                //            IndexHtml = IndexHtml.Replace(string.Format("<%=B2BInfo{0}_{1}_Url%>", (i + 1), (index + 1)), string.Format("{0}" + urlList[i], indexPath, Security.Encrypt(item.IntInfoID)));
                //        }
                //        //替换列表上面数据
                //        switch (i + 1)
                //        {
                //            case 1: replaceHtml += string.Format(" <li><span class='f_r'>&nbsp;{0}</span><a href='{1}' target='_blank'>[  <span class='gq_area'>{3}</span>  ]&nbsp;&nbsp;{2}</a></li>", string.Format("{0}元/{1}", item.DecUnitPrice, item.VarUnitName), string.Format("{0}" + urlList[i], indexPath, Security.Encrypt(item.IntInfoID)), item.VaInfoTitle, item.VarAreaName); break;
                //            case 2: replaceHtml += string.Format(" <li><span class='f_r'>&nbsp;{0}</span><a href='{1}' target='_blank'>[  <span class='gq_area'>{3}</span>  ]&nbsp;&nbsp;{2}</a></li>", item.IntTotalAvailability + item.VarUnitName, string.Format("{0}" + urlList[i], indexPath, Security.Encrypt(item.IntInfoID)), item.VaInfoTitle, item.VarAreaName); break;
                //            case 3: replaceHtml += string.Format(" <li><span class='f_r'>&nbsp;{0}</span><a href='{1}' target='_blank'>[  <span class='gq_area'>{3}</span>  ]&nbsp;&nbsp;{2}</a></li>", string.Format("{0}元", item.IntMinSecurityDeposit), string.Format("{0}" + urlList[i], indexPath, Security.Encrypt(item.IntInfoID)), item.VaInfoTitle, item.VarAreaName); break;
                //            case 4: replaceHtml += string.Format(" <li><span class='f_r'>&nbsp;{0}</span><a href='{1}' target='_blank'>{2}</a></li>", item.VarAreaName, string.Format("{0}" + urlList[i], indexPath, Security.Encrypt(item.IntInfoID)), item.VaInfoTitle); break;
                //            case 5: replaceHtml += string.Format(" <li><span class='f_r'>&nbsp;{0}</span><a href='{1}' target='_blank'>[  <span class='gq_area'>{3}</span>  ]&nbsp;&nbsp;{2}</a></li>", string.Format("{0}元", item.IntMinSecurityDeposit), string.Format("{0}" + urlList[i], indexPath, Security.Encrypt(item.IntInfoID)), item.VaInfoTitle, item.VarAreaName); break;
                //            default: break;
                //        }
                //        //如果是最后一项则开始替换。
                //        if (index == b2bCount - 1 || index == 4)
                //        {
                //            if (index < 5)
                //            {
                //                //替换列表
                //                IndexHtml = IndexHtml.Replace(string.Format("<%=B2BInfo{0}_1%>", i + 1), replaceHtml);
                //                replaceHtml = string.Empty;
                //            }
                //            else
                //            {
                //                //替换列表
                //                IndexHtml = IndexHtml.Replace(string.Format("<%=B2BInfo{0}_6%>", i + 1), replaceHtml);
                //                replaceHtml = string.Empty;
                //            }
                //        }
                //    }
                //}
                //for (int i = 1; i < 6; i++)
                //{
                //    IndexHtml = IndexHtml.Replace(string.Format("<%=B2BInfo{0}_6%>", i ), replaceHtml);
                //    IndexHtml = IndexHtml.Replace(string.Format("<%=B2BInfo{0}_6_Tit%>", i), replaceHtml);
                //}
                #endregion
                #region 新版本替换
                List<VmB2BInfoStand> tmpInfos = null;
                Dictionary<int, string> infodics = new Dictionary<int, string>();
                infodics.Add(1, indexPath + "b2binfo/Sell/{0}?t=1");
                infodics.Add(2, indexPath + "b2binfo/Buy/{0}?t=2");
                infodics.Add(3, indexPath + "b2binfo/Invest/{0}?t=3");
                infodics.Add(4, indexPath + "b2binfo/Cooperate/{0}?t=4");
                infodics.Add(5, indexPath + "b2binfo/Proxy/{0}?t=5");
                foreach (var infodic in infodics)
                {
                    tmpInfos = infos.Where(e => e.IntInfoType == infodic.Key).ToList();
                    replaceHtml = string.Empty;
                    foreach (var tmp in tmpInfos)
                    {
                        replaceHtml += string.Format("<li><a href='{0}' target='_blank'><span class='cl_area'>【&nbsp;{1}&nbsp;】</span> <span class='cl_title'>{2}</span> <span class='cl_unit'>{3}</span> <span class='cl_date'>{4}</span> </a></li>",
                            string.Format(infodic.Value, Security.Encrypt(tmp.IntInfoID))
                            , tmp.VarAreaName
                            , tmp.VaInfoTitle
                            , ReplaceUnit(tmp)
                            , tmp.DteRefresh.ToString("MM-dd"));
                    }
                    IndexHtml = IndexHtml.Replace(string.Format("<%=B2BInfo_{0}%>", infodic.Key), replaceHtml);
                }

                #endregion



                #endregion

                #region 替换农产品价格
                //取供应数据 IntInfoType=1    IntFlag=3通过审批
                var gyLists = context.B2BInfos.Where(e => e.IntInfoType == 1 && e.IntFlag == 3).Take(12).ToList();
                replaceHtml = string.Empty;
                foreach (var entity in gyLists)
                {
                    // <li><span class="f_r">&nbsp;90.00 元<b>/件</b></span><a href="javascript:void(0);" target="_blank">杀虫剂</a></li>
                    replaceHtml += string.Format(" <li><span class=\"f_r\">&nbsp;{0} 元<b>/{1}</b></span><a href=\"{2}\" target=\"_blank\">{3}</a></li>"
                        , Utils.DecimalFormat2(entity.DecUnitPrice.ToString())
                        , entity.VarUnitName
                        , string.Format("{0}b2binfo/Sell/{1}?t=1", indexPath, Security.Encrypt(entity.IntInfoID))
                        , entity.VaInfoTitle);
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoSell%>", replaceHtml);
                #endregion

                #region 替换最新发布
                //<%=B2BInfoNewPublish%>
                List<B2BInfo> NewPublishs = context.B2BInfos.Where(e => e.IntFlag == 3).OrderBy(e => e.DteRefresh).Take(9).ToList();
                replaceHtml = string.Empty;
                foreach (B2BInfo entity in NewPublishs)
                {
                    // <li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='{1}' target='_blank'>{2}</a></li>"
                        , entity.DteRefresh.ToString("MM-dd")
                        , string.Format(infodics[entity.IntInfoType], Security.Encrypt(entity.IntInfoID))
                        , entity.VaInfoTitle
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoNewPublish%>", replaceHtml);
                #endregion

                #region 替换ps文章
                replaceHtml = string.Empty;
                ds = GetDataFaoPS();
                // 替换热点资讯，取点击量最高的文章9
                //替换Title
                dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    replaceHtml = string.Format("<a href='{0}{1}' target='_blank' >{2}</a>"
                        , psPath
                        , dt.Rows[0]["VarUriPath"]
                        , dt.Rows[0]["VarTitle"]
                        );
                    IndexHtml = IndexHtml.Replace("<%=B2BInfoHotInfoTit%>", replaceHtml);
                    dt.Rows.Remove(dt.Rows[0]);
                    replaceHtml = string.Empty;
                }
                foreach (DataRow dr in dt.Rows)
                {
                    //<li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='{1}{2}' target='_blank'>{3}</a></li>"
                        , dr["Time"]
                        , psPath
                        , dr["VarUriPath"]
                        , dr["VarTitle"]);
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoHotInfo%>", replaceHtml);
                replaceHtml = string.Empty;
                //替换农产品行情研究中心 --取独家观点
                dt = ds.Tables[1];
                foreach (DataRow dr in dt.Rows)
                {
                    // <li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='{1}{2}' target='_blank'>{3}</a></li>"
                        , dr["Time"]
                        , psPath
                        , dr["VarUriPath"]
                        , dr["VarTitle"]
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_djgd%>", replaceHtml);
                replaceHtml = string.Empty;

                // 替换国内、国外、社会、更多
                dt = ds.Tables[2];
                //国内价格
                foreach (DataRow dr in dt.Rows)
                {
                    // <li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='{1}{2}' target='_blank'>{3}</a></li>"
                        , dr["Time"]
                        , psPath
                        , dr["VarUriPath"]
                        , dr["VarTitle"]
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_gnjg%>", replaceHtml);
                replaceHtml = string.Empty;
                //国际动态
                dt = ds.Tables[3];
                foreach (DataRow dr in dt.Rows)
                {
                    // <li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='{1}{2}' target='_blank'>{3}</a></li>"
                        , dr["Time"]
                        , psPath
                        , dr["VarUriPath"]
                        , dr["VarTitle"]
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_gjdt%>", replaceHtml);
                replaceHtml = string.Empty;
                //供需分析
                dt = ds.Tables[4];
                foreach (DataRow dr in dt.Rows)
                {
                    // <li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='{1}{2}' target='_blank'>{3}</a></li>"
                        , dr["Time"]
                        , psPath
                        , dr["VarUriPath"]
                        , dr["VarTitle"]
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_gxfx%>", replaceHtml);
                replaceHtml = string.Empty;
                //进出口分析
                dt = ds.Tables[5];
                foreach (DataRow dr in dt.Rows)
                {
                    // <li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='{1}{2}' target='_blank'>{3}</a></li>"
                        , dr["Time"]
                        , psPath
                        , dr["VarUriPath"]
                        , dr["VarTitle"]
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_jckfx%>", replaceHtml);
                replaceHtml = string.Empty;

                //替换栏目id
                dt = ds.Tables[6];
                if (dt.Rows.Count > 0)
                {
                    IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_gnjg_ID%>", string.Format("{0}list.html?p={1}", psPath, dt.Rows[0]["gnjg"]));
                    IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_gjdt_ID%>", string.Format("{0}list.html?p={1}", psPath, dt.Rows[0]["gjdt"]));
                    IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_gxfx_ID%>", string.Format("{0}list.html?p={1}", psPath, dt.Rows[0]["gxfx"]));
                    IndexHtml = IndexHtml.Replace("<%=B2BInfoPart_jckfx_ID%>", string.Format("{0}list.html?p={1}", psPath, dt.Rows[0]["jckfx"]));
                }

                //最新发布<%=B2BInfo_jjpm%>
                var b2bs = context.B2BInfos.Where(e => e.IntFlag == 3)
                    .GroupBy(e => e.IntInfoType)
                    .OrderBy(e => e.Key)
                    .Select(e => e.OrderByDescending(m => m.DteRefresh).Take(2)).ToList();
                List<B2BInfo> entitys = new List<B2BInfo>();
                b2bs.ForEach(e => entitys.AddRange(e));
                entitys = entitys.OrderByDescending(e => e.DteRefresh).ToList();
                foreach (var entity in entitys)
                {
                    replaceHtml += string.Format("<li><span class='f_r'>&nbsp;{0}</span><a href='{2}' target='_blank'>{1}</a></li>"
                        , entity.DteRefresh.ToString("MM-dd")
                        , entity.VaInfoTitle
                        , string.Format("{0}" + infodics[entity.IntInfoType], indexPath, Security.Encrypt(entity.IntInfoID)));
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfo_jjpm%>", replaceHtml);

                //今日聚焦<%=B2BInfo_jrjj_title%>
                List<string> urls = new List<string>();
                dt = ds.Tables[7];
                if (dt.Rows.Count > 1)
                {
                    IndexHtml = IndexHtml.Replace("<%=B2BInfo_jrjj_title%>", string.Format("<a href='{0}{1}' target='_blank' >{2}</a>"
                        , psPath
                        , dt.Rows[0]["VarUriPath"]
                        , dt.Rows[0]["VarTitle"]));
                    dt.Rows.Remove(dt.Rows[0]);
                }
                foreach (DataRow dr in dt.Rows)
                {
                    string url = string.Format("<a href='{0}{1}' target='_blank' >{2}</a>"
                        , psPath
                        , dr["VarUriPath"]
                        , dr["VarTitle"]
                        );
                    urls.Add(url);
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfo_jrjj%>", string.Join("<span>|&nbsp;&nbsp;</span>", urls));

                //替换最新发布
                //<%=B2BInfoNewPublish%>
                //dt = ds.Tables[8];
                //replaceHtml = string.Empty;
                //foreach (DataRow dr in dt.Rows)
                //{
                //    // <li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                //    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='{1}{2}' target='_blank'>{3}</a></li>"
                //        , dr["Time"]
                //        , psPath
                //        , dr["VarUriPath"]
                //        , dr["VarTitle"]
                //        );
                //}
                //IndexHtml = IndexHtml.Replace("<%=B2BInfoNewPublish%>", replaceHtml);
                //替换公告
                dt = ds.Tables[9];
                replaceHtml = string.Empty;
                foreach (DataRow dr in dt.Rows)
                {
                    // <li><span>&nbsp;03-08</span><a href="javascript:void(0);" target="_blank">今日农产品价格将不会有太大涨幅</a></li>
                    replaceHtml += string.Format("<li><span>&nbsp;{0}</span><a href='javascript:void(0)'  title='{1}'>{2}</a></li>"
                        , dr["Time"]
                        , dr["VarContent"]
                        , dr["VarTitle"]
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfoBulletin%>", replaceHtml);

                #endregion

                #region 替换竞价排名
                Dictionary<int, string> allDetails = infodics.ToDictionary(e => e.Key, e => e.Value + "&ppc={1}");
                allDetails.Add(6, indexPath + "Logistic/CargoInfo/{0}?ppc={1}&tab=6");
                allDetails.Add(7, indexPath + "Logistic/StoreInfo/{0}?ppc={1}&tab=7");
                allDetails.Add(8, indexPath + "Logistic/VehicleSourceInfo/{0}?ppc={1}&tab=8");
                allDetails.Add(9, indexPath + "Logistic/RouteInfo/{0}?ppc={1}&tab=9");
                buider = new StringBuilder("ProcGetPPCTopOneList ");
                commandParameters = new SqlParameter[] { };
                DataSet dsPPC = SQLPlus.ExecuteDataSet(CommandType.StoredProcedure, buider, commandParameters);
                DataTable dtPPC = dsPPC.Tables[0];
                replaceHtml = string.Empty;
                foreach (DataRow dr in dtPPC.Rows)
                {
                    replaceHtml += string.Format("<li><a href='{0}' target='_blank'>【 {2} 】{1}</a></li>"
                        , string.Format(allDetails[Utils.ToInt(dr["IntType"].ToString())], Security.Encrypt(dr["IntID"]), dr["IntPPCID"])
                        , dr["VarTitle"]
                        , dr["TypeName"]
                        );
                }
                IndexHtml = IndexHtml.Replace("<%=B2BInfo_PPC%>", replaceHtml);
                #endregion
                //替换结束


                //写文件 
                IOHelper.WriteToFile(IndexHtml, savePath, Encoding.UTF8);

                this.LabCreatePsIndex.Text = "生成时间：" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "   >>距离下次自动生成时间：" + indextime + "分";
            #endregion


            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }

        }

        /// <summary>
        /// 返回PS中的文章数据
        /// </summary>
        /// <returns></returns>
        private DataSet GetDataFaoPS()
        {
            StringBuilder proc = new StringBuilder("Proc_DataForB2B_Index");
            SqlParameter[] commandParameters = new SqlParameter[] { };
            return SQLPlus.ExecuteDataSet(FaoPSConnectionString, CommandType.StoredProcedure, proc, commandParameters);
        }

        public int indextime = 30;
        private void TimerIndex_Tick(object sender, EventArgs e)
        {
            string LabCreatePsIndexStr = LabCreatePsIndex.Text;
            if (LabCreatePsIndexStr.Contains(">>"))
            {
                LabCreatePsIndexStr = LabCreatePsIndexStr.Replace("  >>", "|");
                LabCreatePsIndexStr = LabCreatePsIndexStr.Split('|')[0].ToString();
            }
            LabCreatePsIndex.Text = LabCreatePsIndexStr + "  >>距离下次自动生成时间：" + indextime + "分";
            //如果时间结束，自动生成！
            if (indextime == 0)
            {
                indextime = int.Parse(CbCreateIndexSpan.Text);
                B2BIndex();
            }
            indextime = indextime - 1;
        }

        /// <summary>
        /// 获取附件集合
        /// </summary>
        /// <param name="infoIDs"></param>
        /// <returns></returns>
        /// 
        public List<BuildSite.Attachment> GetMainAttachments(IEnumerable<int> infoIDs)
        {
            using (var context = new FaoB2B_DevEntities())
            {
                var discInfoIDs = infoIDs.Distinct();
                var entities = context.Attachments
                        .Where(e => discInfoIDs.Contains(e.IntBelongTablePrikeyID))
                        .OrderBy(e => e.IntOrder)
                        .GroupBy(g => g.IntBelongTablePrikeyID)
                        .Select(g => g.FirstOrDefault());
                var list = entities.ToList();
                var dbAttIDs = list.Select(a => a.IntBelongTablePrikeyID).ToList();
                foreach (var infoid in discInfoIDs)
                {
                    if (!dbAttIDs.Contains(infoid))
                    {
                        list.Add(new BuildSite.Attachment
                        {
                            IntBelongTablePrikeyID = infoid,
                            VarFilePath = "/content/Images/empty_info.gif"
                        });
                    }
                }
                return list;
            }

        }

        /// <summary>
        /// FaoPS链接字符串
        /// </summary>
        private static string FaoPSConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["FaoPS"].ToString();
            }
        }

        private void btn_cj_Click(object sender, EventArgs e)
        {
            #region 拷贝js css
            //首先赋值 css，js文件夹到站点目录下，如果有，则删除后全部覆盖。
            IOHelper.DeleteDir(validSite.Element("path").Value + "css", true);
            IOHelper.DeleteDir(validSite.Element("path").Value + "js", true);
            //再将模板中的css，js文件复制到该目录下
            string cssPath = validSite.Element("css").Value;
            string jsPath = validSite.Element("js").Value;
            IOHelper.CopyDir(SitePath + cssPath, validSite.Element("path").Value + cssPath.Substring(cssPath.LastIndexOf("\\") + 1));
            IOHelper.CopyDir(SitePath + jsPath, validSite.Element("path").Value + jsPath.Substring(jsPath.LastIndexOf("\\") + 1));
            this.lab_CJ.Text = "生成时间：" + DateTime.Now.ToString("yyyy-MM-dd HH:mm");
            #endregion
        }
        /// <summary>
        /// 替换数据
        /// </summary>
        /// <param name="vm"></param>
        /// <returns></returns>
        private string ReplaceUnit(VmB2BInfoStand vm)
        {
            string result = string.Empty;
            switch (vm.IntInfoType)
            {
                case 1:
                    result = string.Format("{0}元/{1}", Utils.DecimalFormat2(vm.DecUnitPrice.ToString()), vm.VarUnitName);
                    break;
                case 2:
                    result = Utils.DecimalFormat2(vm.IntTotalAvailability.ToString()) + vm.VarUnitName;
                    break;
                case 3:
                    result = string.Format("{0}元", Utils.DecimalFormat2(vm.IntMinSecurityDeposit.ToString()));
                    break;
                case 5:
                    result = string.Format("{0}元", Utils.DecimalFormat2(vm.IntMinSecurityDeposit.ToString()));
                    break;
                default: break;
            }
            return result;
        }

    }
}

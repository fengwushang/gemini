﻿// Default code generation is disabled for model 'D:\TFS_009\FaoB2B\Code\Fao.Data.B2B\FaoB2B.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.
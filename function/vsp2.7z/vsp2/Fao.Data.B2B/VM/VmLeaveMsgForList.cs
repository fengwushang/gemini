﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// VmLeaveMsgForList视图模型-Power by CodeGG
    /// </summary>
    public class VmLeaveMsgForList
    {
        /// <summary>
        /// 加密ID
        /// </summary>
        public string EncriptID { get; set; }

        /// <summary>
        /// 分类
        /// </summary>
        public string BelongTable { get; set; }

        /// <summary>
        /// 类型 1询价，2报价，3留言
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// 信息标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public string CreateDate { get; set; }

        /// <summary>
        /// 联系人
        /// </summary>
        public string Contact { get; set; }

        /// <summary>
        /// 联系方式
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 加密联系方式
        /// </summary>
        public string EncriptPhone { get; set; }

        /// <summary>
        /// 已读2，未读1
        /// </summary>
        public string Flag { get; set; }
    }

    /// <summary>
    /// 用于LeaveMsg分页的对象
    /// </summary>
    public class VmLeaveMsgPaging
    {
        /// <summary>
        /// 当前页行
        /// </summary>
        public List<VmLeaveMsgForList> rows { get; set; }

        /// <summary>
        /// 记录总条数
        /// </summary>
        public int total { get; set; }
    }
}

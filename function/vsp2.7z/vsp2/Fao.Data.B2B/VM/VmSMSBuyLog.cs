﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// SMSBuyLog视图模型-Power by CodeGG
    /// </summary>
    public class VmSMSBuyLog
    {
        /// <summary>
        /// 行号
        /// </summary> 
        public long RowNum { get; set; }

        //主键
        public int IntBuyUserID { get; set; }

        //购买条数
        public int IntBuyNum { get; set; }

        //创建日期
        public string DteCreate { get; set; }

        //标志位；0删除，1有效
        public int IntFlag { get; set; }
    }


    //购买分页
    public class VmSMSBuyLogPaging
    {
        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前页面数据
        /// </summary>
        public List<VmSMSBuyLog> rows { get; set; }
    }

}
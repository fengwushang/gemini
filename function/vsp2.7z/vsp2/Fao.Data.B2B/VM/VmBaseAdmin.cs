﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-21 10:32:34
    /// BaseAdmin视图模型-Power by CodeGG
    /// </summary>
    public class VmBaseAdmin
    {
        public int IntAdminID { get; set; }

        //管理员登陆名称
        public string VarAdminName { get; set; }

        //管理员密码
        public string VarPassWord { get; set; }

        public string ValidateCode { get; set; }

        //管理员真实姓名
        public string VarRealName { get; set; }

        //性别
        public Nullable<int> IntSex { get; set; }
        public string VarSex
        {
            get
            {
                switch (IntSex)
                {
                    case 1: return "男";
                    case 2: return "女";
                    default: return "";
                }
            }
        }

        //角色：1系统管理员，2审核员
        public string VarAuthority { get; set; }
        public string Authority
        {
            get
            {
                string val = "";
                string[] arr = VarAuthority.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string item in arr)
                {
                    switch (item)
                    {
                        case "1": val += " 系统管理员 "; break;
                        case "2": val += " 审核员 "; break;
                        default: break;
                    }
                }
                return val;
            }
        }
    }

    /// <summary>
    /// BaseLog 分页数据
    /// </summary>
    public class BaseAdminPaging
    {
        public int total { get; set; }
        public List<VmBaseAdmin> rows { get; set; }
    }
}
﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Brand视图模型-Power by CodeGG
    /// </summary>
    public class VmBrand
    {
        
    }
}
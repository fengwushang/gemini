﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// LogisticVehicleSource视图模型-Power by CodeGG
    /// </summary>
    public class VmLogisticVehicleSource
    {
        //车源表
        public string VehicleSourceID { get; set; }

        /// <summary>
        /// 企业ID
        /// </summary>
        public string EntID { get; set; }

        /// <summary>
        /// 企业名称
        /// </summary>
        public string EntName { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int? UserID { get; set; }
        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 外键，起始地，地区表ID
        /// </summary>
        [Required(ErrorMessage="请选择出发地")]
        [Display(Name="出发地")]
        public int AreaIDStart { get; set; }
        /// <summary>
        /// 起始地
        /// </summary>
        public string StartArea { get; set; }

        /// <summary>
        /// 外键，目的地，地区表ID
        /// </summary>
        [Required(ErrorMessage="请选择目的地")]
        [Display(Name="目的地")]
        public int AreaIDEnd { get; set; }

        /// <summary>
        /// 目的地
        /// </summary>
        public string EndArea { get; set; }

        /// <summary>
        /// 外键，车辆表
        /// </summary>
        [Required(ErrorMessage="请选择车源车辆")]
        [Display(Name = "车源车辆")]
        public int VehicleID { get; set; }

        /// <summary>
        /// 车牌号码
        /// </summary>
        public string LicenseNum { get; set; }

        /// <summary>
        /// 联系人
        /// </summary>
        [Required(ErrorMessage="请填写联系人")]
        [StringLength(98,ErrorMessage="请确保联系人长度小于10个字符")]
        [Display(Name="联系人")]
        public string Contact { get; set; }

        /// <summary>
        /// 联系电话
        /// </summary>
        [Required(ErrorMessage="请填写联系电话")]
        [RegularExpression(@"((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)",ErrorMessage="请填写正确的电话号码")]
        [Display(Name="联系电话")]
        public string Phone { get; set; }

        /// <summary>
        /// 发布日期字符串
        /// </summary>
        public string DteCreate { get; set; }

        /// <summary>
        /// 刷新时间字符串
        /// </summary>
        public string DteRefresh { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public DateTime? RefreshDate { get; set; }

        /// <summary>
        /// 有效期至
        /// </summary>
        public string DteValid { get; set; }

        /// <summary>
        /// 有效期
        /// </summary>
        public DateTime? ValidDate { get; set; }

        /// <summary>
        /// 浏览次数
        /// </summary>
        public int BrowserCount { get; set; }

        /// <summary>
        /// 详细说明
        /// </summary>
        [StringLength(2800,ErrorMessage="请确保详细信息内容小于2800个字符")]
        [Display(Name="详细信息")]
        public string Details { get; set; }

        /// <summary>
        /// 标志位： 0 删除，1保存，2 待审批，3通过，4不通过
        /// </summary>
        public int? Flag { get; set; }

        /// <summary>
        /// 图片URL
        /// </summary>
        public string ImgUrl { get; set; }

        /// <summary>
        /// 所有图片的地址
        /// </summary>
        public List<string> ImageUrl { get; set; }

        /// <summary>
        /// 所有图片的ID
        /// </summary>
        public List<string> ImageID { get; set; }

        //车辆信息
        public VmLogisticVehicle Vehicle { get; set; }
        
        //车辆类型
        public string Type { get; set; }

        //短信
        public string Sms { get; set; }

        /// <summary>
        /// 是否推广
        /// </summary>
        public string ISTG { get; set; }

        /// <summary>
        /// 信息推广id，null为没有参加推广
        /// </summary>
        public string PPCID { get; set; }
    }

        /// <summary>
    /// 车源 分页数据
        /// </summary>
    public class LogisticVehicleSourcePaging
    {
        public int total { get; set; }
        public List<VmLogisticVehicleSource> rows { get; set; }
    }
}
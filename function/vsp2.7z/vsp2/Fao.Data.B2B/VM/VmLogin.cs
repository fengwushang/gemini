﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.MV
{
    /// <summary>
    /// 登陆用VM
    /// </summary>
    public class VmLogin
    {
        /// <summary>
        /// 用户名
        /// </summary>
        [Required(ErrorMessage = "请填写用户名")]
        public string UserName { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        [Required(ErrorMessage = "请填写密码"),DataType(DataType.Password)]
        public string PassWord { get; set; }

        /// <summary>
        /// 验证码
        /// </summary>
        [Required(ErrorMessage="请填写验证码")]
        public string ValidateCode { get; set; }

        /// <summary>
        /// 是否自动登陆
        /// </summary>
        [Display(Name="自动登陆")]
        public bool AutoLogin { get; set; }
    }

    public class VmSimpLogin 
    {
        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public string PassWord { get; set; }
    }
}

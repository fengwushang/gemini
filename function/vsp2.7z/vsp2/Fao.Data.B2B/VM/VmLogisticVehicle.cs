﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticVehicle视图模型-Power by CodeGG
    /// </summary>
    public class VmLogisticVehicle
    {
        /// <summary>
        /// 加密ID
        /// </summary>
        public string EncriptID { get; set; }

        /// <summary>
        /// 车牌号
        /// </summary>
        [Required(ErrorMessage="请填写车牌号码")]
        [StringLength(20,ErrorMessage="请确保车牌号码长度小于20个字符")]
        [Display(Name="车牌号码")]
        [RegularExpression("^[\u4e00-\u9fa5]{1}[A-Z]{1}[A-Z_0-9]{5}$",ErrorMessage="请填写正确的车牌号码")]
        public string LicenseNum { get; set; }

        /// <summary>
        /// 行车证号
        /// </summary>
        [Required(ErrorMessage="请填写行车证号码")]
        [StringLength(30,ErrorMessage="请确保行车证号码长度小于30个字符")]
        [Display(Name="行车证号")]
        public string VehicleNumber { get; set; }

        /// <summary>
        /// 出厂日期
        /// </summary>
        [Required(ErrorMessage="请选择出厂日期")]
        [Display(Name="出厂日期")]
        public DateTime Manufacture { get; set; }

        /// <summary>
        /// 出厂日期字符串
        /// </summary>
        public string StrManufacture { get; set; }
        
        /// <summary>
        /// 车辆尺寸长*宽*高
        /// </summary>
        public string VehicleSize { get; set; }

        /// <summary>
        /// 长
        /// </summary>
        [Required(ErrorMessage = "请填写车辆尺寸(长)")]
        [Display(Name="车辆尺寸(长)")]
        [StringLength(4,ErrorMessage="请确保车辆尺寸(长)长度小于4位数")]
        public decimal? Long { get; set; }
        /// <summary>
        /// 宽
        /// </summary>
        [Required(ErrorMessage = "请填写车辆尺寸(宽)")]
        [StringLength(4,ErrorMessage="请确保车辆尺寸(宽)长度小于4位数")]
        [Display(Name = "车辆尺寸(宽)")]
        public decimal? Wide { get; set; }
        /// <summary>
        /// 高
        /// </summary>
        [Required(ErrorMessage = "请填写车辆尺寸(高)")]
        [Display(Name = "车辆尺寸(高)")]
        [StringLength(4, ErrorMessage = "请确保车辆尺寸(高)长度小于4位数")]
        public decimal? High { get; set; }

        /// <summary>
        /// 车辆类型
        /// </summary>
        [Required(ErrorMessage="请选择车辆类型")]
        [Display(Name="车辆类型")]
        public int? VehicleType { get; set; }
        public string Type { get; set; }

        /// <summary>
        /// 车辆类型字符串
        /// </summary>
        public string StrVehicleType { get; set; }

        /// <summary>
        /// 最大载重
        /// </summary>
        [Required(ErrorMessage="请填写最大载重量")]
        [RegularExpression("^[0-9]+(.[0-9]{1,2})?$", ErrorMessage = "请填写量大载重量")]
        [StringLength(10,ErrorMessage="请确保最大载重量长度小于10位数")]
        [Display(Name="最大载重量")]
        public decimal? MaxLoad { get; set; }

        /// <summary>
        /// 最大体积
        /// </summary>
        [Display(Name="最大体积")]
        [StringLength(10,ErrorMessage="请确保最大体积长度小于10位数")]
        public decimal? MaxVolume { get; set; }

        /// <summary>
        /// 有没有GPS
        /// </summary>
        [Required(ErrorMessage="请选择有没有GPS")]
        [Display(Name="安装GPS")]
        public int IsGPS { get; set; }

        /// <summary>
        /// 有没有保险
        /// </summary>
        [Required(ErrorMessage="请选择有没有保险")]
        [Display(Name="车辆保险")]
        public int IsInsurance { get; set; }

        /// <summary>
        /// 有没有温控
        /// </summary>
        [Required(ErrorMessage="请选择有没有温度控制")]
        [Display(Name="测试控制")]
        public int IsTemp { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? CreatDate { get; set; }

        /// <summary>
        /// 创建时间字符串
        /// </summary>
        public string StrCreateDate { get; set; }

        /// <summary>
        /// 所有图片的ID
        /// </summary>
        public List<string> ImageID { get; set; }

        /// <summary>
        /// 标志位
        /// </summary>
        public int? Flag { get; set; }

        /// <summary>
        /// 第一张图片的地址
        /// </summary>
        public string FirstImageUrl { get; set; }

        /// <summary>
        /// 所有图片的地址
        /// </summary>
        public List<string> ImageUrl { get; set; }

        /// <summary>
        /// 有效期
        /// </summary>
        public DateTime? ValidDate { get; set; }
        
        /// <summary>
        /// 有效期字符串
        /// </summary>
        public string StrValidDate { get; set; }
    }

    /// <summary>
    /// 供应信息的分页对象
    /// </summary>
    public class VMVehiclePaging
    {
        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前页数据
        /// </summary>
        public List<VmLogisticVehicle> rows { get; set; }
    }

}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    public class VmGegBackPassword
    {
        
        public string ValidationCode { get; set; }
        [Required(ErrorMessage="请填写密码")]
        [StringLength(20,MinimumLength=6,ErrorMessage="请确保密码长度在6到20个字符之间")]
        public string NewPassword { get; set; }
    }
}

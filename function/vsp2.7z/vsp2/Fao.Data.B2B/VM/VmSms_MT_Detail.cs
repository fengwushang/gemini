﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-03-13 17:03:47
    /// Sms_MT_Detail视图模型-Power by CodeGG
    /// </summary>
    public class VmSms_MT_Detail
    {
        /// <summary>
        /// 行号
        /// </summary> 
        public long RowNum { get; set; }

        /// <summary>
        /// 详细信息主键
        /// </summary>
        public Int64 BigDetailID { get; set; }

        /// <summary>
        /// 真实姓名
        /// </summary>
        public string VarRealName { get; set; }

        /// <summary>
        /// 企业名称
        /// </summary>
        public string VarEnterpriseName { get; set; }

        /// <summary>
        /// 发送时间
        /// </summary>
        public string SendTime { get; set; }

        /// <summary>
        /// 发送报告
        /// </summary>
        public string ReportState { get; set; }
    }

    /// <summary>
    /// 短信细节分页
    /// </summary>
    public class VmSms_MT_DetailPaing
    {
        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前页面数据
        /// </summary>
        public List<VmSms_MT_Detail> rows { get; set; }
    }


    /// <summary>
    /// 收件箱
    /// </summary>
    public class VmSmsInbox
    {

        //回短信表ID
        public int msgid { get; set; }

        /// <summary>
        /// 短信内容
        /// </summary>
        public string sms_content { get; set; }

        /// <summary>
        /// 发送时间
        /// </summary>
        public DateTime up_time { get; set; }

        /// <summary>
        /// 回短信的手机号
        /// </summary>
        public string mobile_no { get; set; }

        /// <summary>
        /// 行号
        /// </summary> 
        public string RowNum { get; set; }

        /// <summary>
        /// 真实姓名
        /// </summary>
        public string VarRealName { get; set; }

        /// <summary>
        /// 企业名称
        /// </summary>
        public string VarEnterpriseName { get; set; }
    }

    /// <summary>
    /// 收信箱 分页
    /// </summary>
    public class VmSmsInboxPaging
    {
        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前页面数据
        /// </summary>
        public List<VmSmsInbox> rows { get; set; }
    }


}
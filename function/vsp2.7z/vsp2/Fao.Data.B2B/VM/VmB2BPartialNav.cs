﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// B2b信息导航对象
    /// </summary>
    public class VmPartialNav
    {
        /// <summary>
        /// 信息类型
        /// </summary>
        public int Type { get; set; }

        /// <summary>
        /// URL字符串
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// 信息名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// 当前修改的ID
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// 在菜单项中的序号
        /// </summary>
        public string Index { get; set; }
    }
}

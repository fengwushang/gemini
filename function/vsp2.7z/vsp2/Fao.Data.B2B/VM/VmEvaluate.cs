﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Evaluate视图模型-Power by CodeGG
    /// </summary>
    public class VmEvaluate
    {
        /// <summary>
        /// 评论ID，加密后的字符串
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// 评论分值
        /// </summary>
        public string Cost { get; set; }

        /// <summary>
        /// 评论内容
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// 评论用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 评论时间
        /// </summary>
        public string CreateDate { get; set; }

        /// <summary>
        /// 是否匿名评论
        /// </summary>
        public string IsAnonymous { get; set; }
    }

    /// <summary>
    /// 评论视图分页类
    /// 适用于easyui对分页数据的要求
    /// </summary>
    public class VmEvaluatePaging
    {
        /// <summary>
        /// 总数
        /// </summary>
        public string total { get; set; }

        /// <summary>
        /// 数据行
        /// </summary>
        public List<VmEvaluate> rows { get; set; }

    }
}
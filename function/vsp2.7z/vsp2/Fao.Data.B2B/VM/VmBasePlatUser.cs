﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: sjp , 2013-07-03
    /// BaseUser视图模型-Power by sjp
    /// </summary>
    public class VmBasePlatUser
    {
        /// <summary>
        ///用户ID，主键
        /// </summary>
        public string IntUserID { get; set; }

        /// <summary>
        ///手机号码
        /// </summary>
        public string VarPhone { get; set; }

        /// <summary>
        ///手机验证标识位：1已验证，2没验证
        /// </summary>
        public string IntPhoneVerify { get; set; }

        /// <summary>
        ///注册邮箱
        /// </summary>
        public string VarEmail { get; set; }

        /// <summary>
        ///邮箱验证标识位：1已验证，2没验证
        /// </summary>
        public string IntEmailVerify { get; set; }

        /// <summary>
        ///邮箱验证码，注册、找回密码验证
        /// </summary>
        public string VarEmailVerifyCode { get; set; }

        /// <summary>
        ///邮箱验证码 失效时间
        /// </summary>
        public string DteEmailVerifyValid { get; set; }

        /// <summary>
        ///真实姓名
        /// </summary>
        public string VarRealName { get; set; }

       

        /// <summary>
        ///昵称
        /// </summary>
        public string VarNickName { get; set; }

        /// <summary>
        ///密码
        /// </summary>
        public string VarPWD { get; set; }

       

        /// <summary>
        ///标识位：1当前在线，2当前不在线 当前是否在线
        /// </summary>
        public string IntCurrentLogin { get; set; }

        /// <summary>
        ///有效状态标识：0 已删除，1 未激活， 2正常 ，3 冻结中
        /// </summary>
        public string IntFlag { get; set; }

        /// <summary>
        ///类型标志位：1 普通用户组，2企业用户组，3后台用户 前台账号
        /// </summary>
        public string IntUserGroup { get; set; }

      
    }
}

﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// BaseUser视图模型-Power by CodeGG
    /// </summary>
    public class VmBaseUser
    {
        /// <summary>
        /// 用户昵称
        /// </summary>
        public string UserNickName { get; set; }

        /// <summary>
        /// 用户真实名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 企业名称
        /// </summary>
        public string EntName { get; set; }

        /// <summary>
        /// 未读信件的条数
        /// </summary>
        public int MsgCount { get; set; }

        /// <summary>
        /// 资金
        /// </summary>
        public decimal Money { get; set; }
    }
}
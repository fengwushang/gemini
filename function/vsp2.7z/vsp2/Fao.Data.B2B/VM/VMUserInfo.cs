﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// UserExtension视图模型-Power by CodeGG
    /// edit by:chf ，2013-3-11 16:21:04
    /// </summary>
    public class VMUserInfo
    {
        //主键
        public int UserID { get; set; }

        //手机号码
        public string Phone { get; set; }

        //手机是否已经验证：1已验证，2没验证
        public int IntPhoneVerify { get; set; }

        //注册邮箱
        [Required(ErrorMessage = "请填写登录邮箱")]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}", ErrorMessage = "请填写有效的登录邮箱")]
        public string Email { get; set; }

        //用户姓名
        [Required(ErrorMessage = "请填写真实姓名")]
        public string RealName { get; set; }

        //昵称
        [Required(ErrorMessage = "请填写昵称")]
        public string NickName { get; set; }

        //用户扩展表
        public int ExtensionID { get; set; }

        //用户QQ号，可能是邮箱
        [RegularExpression(@"[0-9]{5,11}", ErrorMessage = "QQ输入错误")]
        public string QQ { get; set; }

        //性别；1男，2女
        [Display(Name="性别")]
        public int? Sex { get; set; }

        //年龄
        [Display(Name = "年龄")]
        public int? Age { get; set; }
    }

    /// <summary>
    /// 用户交易扩展表
    /// </summary>
    public class VMTransaction
    {
        //主键
        public int IntUserTransaction { get; set; }

        //用户ID
        public int IntUserID { get; set; }

        //用户账户余额
        public decimal DecAccountBalance { get; set; }

        //用户支付密码
        public string VarPaymentPwd { get; set; }

        //剩余短信条数
        public int IntPhoneMsgSum { get; set; }

        //推广余额
        public decimal DecPPCBalance { get; set; }

        //号段类型
        public int IntSMSInterval { get; set; }

        //短信子号
        public int IntSMSSrcID { get; set; }

        //标志位
        public int IntFlag { get; set; }
    }


    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// UserExtension视图模型-Power by CodeGG
    /// </summary>
    public class VMEntInfo
    {
        //主键
        public int EnterpriseID{ get; set; }

        //企业名称
        [Required(ErrorMessage = "请填写企业名称")]
        public string EnterpriseName{ get; set; }

        //外键，字典表，企业性质
        public int EnterpriseTypeID{ get; set; }
        public string EnterpriseTypeName { get; set; }

        //外键，所属行业
        public int IndustryID{ get; set; }
        public string IndustryName { get; set; }

        //外键，所在城市
        public int AreaID{ get; set; }
        public string AreaName { get; set; }

        //企业规模 （多少人）
        [Required(ErrorMessage = "请填写企业规模")]
        public string EnterpriseScale { get; set; }

        //企业描述
        [Required(ErrorMessage = "请填写企业描述")]
        [StringLength(2000, MinimumLength = 10, ErrorMessage = "请输入10-2000个字符")]
        public string EnterpriseDescrip { get; set; }

        //企业简介
        [Required(ErrorMessage = "请填写企业简介")]
        [StringLength(500, MinimumLength = 10, ErrorMessage = "请输入10-500个字符")]
        public string EnterpriseBrief { get; set; }

        //邮编
        [Required(ErrorMessage = "请填写邮编")]
        [RegularExpression(@"^[0-9]{6}$", ErrorMessage = "邮编格式不正确")]
        public string Zipcode { get; set; }

        //企业地址
        [Required(ErrorMessage = "请填写企业地址")]
        [StringLength(500, MinimumLength = 10, ErrorMessage = "请输入10-300个字符")]
        public string Address { get; set; }

        //联系电话
        [Required(ErrorMessage = "请填写联系电话")]
        [RegularExpression(@"0\d{2,3}-\d{5,9}|0\d{2,3}-\d{5,9}", ErrorMessage = "正确格式:区号-电话号")]
        public string ContactPhone { get; set; }


        //客服电话
        [Required(ErrorMessage = "请填写客服电话")]
        [RegularExpression(@"0\d{2,3}-\d{5,9}|0\d{2,3}-\d{5,9}", ErrorMessage = "正确格式:区号-电话号")]
        public string CustomerPhone { get; set; }

        //传真
        [Required(ErrorMessage = "请填写传真")]
        [RegularExpression(@"^(([0\+]\d{2,3}-)?(0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$", ErrorMessage = "正确格式:区号-传真号")]
        public string FixNum { get; set; }

        //网址
        [Required(ErrorMessage = "请填写网址")]
        public string WebSiteURL { get; set; }

        public int? Flag { get; set; }
    }
}

﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// Attachment视图模型-Power by CodeGG
    /// </summary>
    public class VmAttachment
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 标志位属于那张表
        /// </summary>
        public int BelongTable { get; set; }
        /// <summary>
        /// 主键
        /// </summary>
        public int PK { get; set; }
        /// <summary>
        /// 文件名
        /// </summary>
        public string FileName { get; set; }
        /// <summary>
        /// 文件路径
        /// </summary>
        public string Path { get; set; }
        /// <summary>
        /// 描述 
        /// </summary>
        public string Descrip { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int Order { get; set; }
        /// <summary>
        /// 标志位,有效性
        /// </summary>
        public int? Flag { get; set; }
    }
}
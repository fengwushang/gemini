﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LeaveMsg视图模型-Power by CodeGG
    /// </summary>
    public class VmLeaveMsg
    {

        public int IntLeaveMsgID { get; set; }

        //留言表标志位；归属表的区分。1 (LogisticCargo) 货源表，2(LogisticStore)库源表，3（LogisticVehicle）车辆表 ，
        //4(LogisticVehicleSource)车源表，5(LogisticRoute)物流专线表, 6 (B2BInfo)信息表，7(Authenticate)认证表
        public int IntBelongTable { get; set; }

        //外键，附件归属表的主键ID
        public int IntBelongTablePrikeyID { get; set; }

        //[Required(ErrorMessage="请选择要询价（留言、报价）信息")]
        public string Ids { get; set; }

        //外键，接收用户ID
        public int IntReviceUserID { get; set; }

        //留言类型标志位；1询价，2报价，3留言
        public int IntMsgType { get; set; }

        //标题
        //[Required(ErrorMessage = "请填写标题")]
        public string VarTitle { get; set; }

        //内容， 所有的东西组织成一个整体作为内容
        //[Required(ErrorMessage = "请填写内容")]
        public string VarContent { get; set; }

        //联系人姓名
        //[Required(ErrorMessage = "请填写联系人")]
        public string VarContact { get; set; }
        //性别
        public int IntSex { get; set; }
        //固话
        public string VarTelPhone { get; set; }
        //QQ
        public string VarQQ { get; set; }
        //Email
        public string VarEmail { get; set; }
        //电话，多个电话用半角逗号分隔
        //[Required(ErrorMessage = "请填写联系方式")]
        public string VarPhone { get; set; }

        //[Required(ErrorMessage = "请填写验证码")]
        public string VarCode { get; set; }

        //创建时间
        public DateTime DteCreate { get; set; }
    }
}

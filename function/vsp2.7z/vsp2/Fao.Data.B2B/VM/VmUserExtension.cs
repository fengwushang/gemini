﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// UserExtension视图模型-Power by CodeGG
    /// </summary>
    public class VmUserExtension
    {

    }
}
﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-20 10:18:31
    /// BaseDictionary视图模型-Power by CodeGG
    /// </summary>
    public class VmBaseDictionary
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int ItemID { get; set; }

        /// <summary>
        /// 父键
        /// </summary>
        public int ParentID { get; set; }

        /// <summary>
        /// 字典项名称
        /// </summary>
        [Required(ErrorMessage="请填写字典项名称")]
        [StringLength(30,ErrorMessage="请确保字典项名称长度小于30个字符")]
        public string ItemName { get; set; }

        /// <summary>
        /// 字典项描述
        /// </summary>
        [StringLength(95, ErrorMessage = "请确保字典项描述长度小于95个字符")]
        public string ItemDescription { get; set; }

        /// <summary>
        /// 字典项简称
        /// </summary>
        [Required(ErrorMessage = "请填写字典项简称")]
        [StringLength(30, ErrorMessage = "请确保字典项简称长度小于95个字符")]
        public string Abbreviation { get; set; }

        /// <summary>
        /// treeGrid使用状态
        /// </summary>
        public string state { get; set; }

        /// <summary>
        /// treeGrid使用父ID
        /// </summary>
        public int _parentId { get; set; }
    }
}
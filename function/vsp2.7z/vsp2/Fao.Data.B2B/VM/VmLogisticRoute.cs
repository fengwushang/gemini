﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticRoute视图模型-Power by CodeGG
    /// </summary>
    public class VmLogisticRoute
    {
        //物流专线表
        public string RouteID { get; set; }

        /// <summary>
        ///加密ID
        /// </summary>
        public string EncriptID { get; set; }

        /// <summary>
        /// 企业ID
        /// </summary>
        public string EntID { get; set; }

        /// <summary>
        /// 企业名称
        /// </summary>
        public string EntName { get; set; }

        //外键，车辆表
        [Required(ErrorMessage = "请选择专线车辆")]
        public int VehicleID { get; set; }

        /// <summary>
        /// 车牌号
        /// </summary>
        public string LicenseNum { get; set; }

        //车辆信息
        public VmLogisticVehicle Vehicle { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        //物流专线名称
        public string RouteTitle { get; set; }

        /// <summary>
        /// 外键，起始地，地区表ID
        /// </summary>
        [Required(ErrorMessage="请选择起始地")]
        [Display(Name="起始地")]
        public int? AreaIDStart { get; set; }

        /// <summary>
        /// 起始地
        /// </summary>
        public string StartArea { get; set; }

        /// <summary>
        /// 外键，目的地，地区表ID
        /// </summary>
        [Required(ErrorMessage="请选择目的地")]
        [Display(Name="目的地")]
        public int? AreaIDEnd { get; set; }

        /// <summary>
        /// 目的地
        /// </summary>
        public string EndArea { get; set; }


        //出发地 联系人
        [Required(ErrorMessage="请填写出发地联系人")]
        [StringLength(90,ErrorMessage="请确保出发地联系人字段长度小于10个字符")]
        [Display(Name="出发地联系人")]
        public string ContactStart { get; set; }

        //出发地 联系人电话
        [Required(ErrorMessage="请填写出发地联系电话")]
        [RegularExpression(@"((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)", ErrorMessage = "请填写正确的电话号码")]
        [Display(Name="出发地联系人电话")]
        public string ContactPhoneStart { get; set; }

        //目的地 联系人
        [StringLength(90, ErrorMessage = "请确保目的地联系人字段长度小于10个字符")]
        [Display(Name="目的地联系人")]
        public string ContactEnd { get; set; }

        //目的地 联系人电话
        [RegularExpression(@"((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)", ErrorMessage = "请填写正确的电话号码")]
        [Display(Name="目的地联系人电话")]
        public string ContactPhoneEnd { get; set; }

        //货物类别
        public int GoodsType { get; set; }
        
        /// <summary>
        /// 货物类别
        /// </summary>
        [StringLength(180,ErrorMessage="请确保货物要求字段长度小于180字符")]
        [Display(Name = "货物类别")]
        public string Type { get; set; }

        //外键，字典表，组货要求
        [Required(ErrorMessage="请选择组货要求")]
        [Display(Name="组货要求")]
        public int? LoadAsk { get; set; }
        public string Ask { get; set; }

        //沿途停靠地
        [Display(Name="沿途停靠地")]
        [StringLength(120,ErrorMessage="请确保沿途停靠地长度小于120个字符")]
        public string WayStop { get; set; }

        //1不往返，2 往返
        [Display(Name="是否往返")]
        public int IsBF { get; set; }

        //运费
        [Display(Name="运费")]
        [StringLength(8, ErrorMessage = "请确保运费小于8位数")]
        public decimal? CargoFreight { get; set; }

        //外键，字典表，运费单位
        [Display(Name="运费单位")]
        public int? FreightUnit { get; set; }
        public string Unit { get; set; }

        //发布日期
        public string DteCreate { get; set; }

        //有效期至
        public string DteValid { get; set; }

        //刷新时间
        public string DteRefresh { get; set; }

        //浏览次数
        public int BrowserCount { get; set; }

        //详细说明
        [StringLength(2800, ErrorMessage = "请确保详细信息内容小于2800个字符")]
        [Display(Name="详细说明")]
        public string Details { get; set; }

        //标志位： 0 删除，1保存，2 待审批，3通过，4不通过
        public int? Flag { get; set; }

        /// <summary>
        /// 图片URL
        /// </summary>
        public string ImgUrl { get; set; }

        /// <summary>
        /// 所有图片的地址
        /// </summary>
        public List<string> ImageUrl { get; set; }

        /// <summary>
        /// 有效期
        /// </summary>
        public DateTime? ValidDate { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public DateTime? RefreshDate { get; set; }

        /// <summary>
        /// 所有图片的ID
        /// </summary>
        public List<string> ImageID { get; set; }

        /// <summary>
        /// 是否推广
        /// </summary>
        public string ISTG { get; set; }

        /// <summary>
        /// 信息推广id，null为没有参加推广
        /// </summary>
        public string PPCID { get; set; }

        /// <summary>
        /// 短信相关信息
        /// </summary>
        public string Sms { get; set; }

        /// <summary>
        /// 车辆类型
        /// </summary>
        public string VehicleType { get; set; }

        /// <summary>
        /// 车辆载重
        /// </summary>
        public string MaxLoad { get; set; }

    }

    /// <summary>
    /// 物流专线 分页数据
    /// </summary>
    public class LogisticRoutePaging
    {
        public int total { get; set; }
        public List<VmLogisticRoute> rows { get; set; }
    }
}
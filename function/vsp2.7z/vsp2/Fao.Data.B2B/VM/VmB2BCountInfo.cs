﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// B2B统计信息
    /// </summary>
    public class VmCountInfo
    {
        /// <summary>
        /// 已发布数量
        /// </summary>
        public int Release { get; set; }
        /// <summary>
        /// 审批中数量
        /// </summary>
        public int Approving { get; set; }
        /// <summary>
        /// 未通过数量
        /// </summary>
        public int NotAdopt { get; set; }
        /// <summary>
        /// 已发期数量
        /// </summary>
        public int Overdue { get; set; }

        /// <summary>
        /// 已保存
        /// </summary>
        public int Saving { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// 供应信息添加 修改 列表VM类
    /// </summary>
    public class VmSupply
    {
        /// <summary>
        /// 加密主键ID
        /// </summary>
        public string EncriptID { get; set; }

        /// <summary>
        /// 地区ID
        /// </summary>
        [Required(ErrorMessage="请选择地区")]
        [Display(Name="地区")]
        public int? AreaID { get; set; }

        /// <summary>
        /// 地区名称
        /// </summary>
        public string AreaName { get; set; }

        /// <summary>
        /// 分类ID
        /// </summary>
        [Required(ErrorMessage = "请选择所属分类"), Display(Name = "所属分类")]
        public int? CategoryID { get; set; }

        /// <summary>
        /// 所属分类
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        [Required(ErrorMessage="请填写标题"),
        StringLength(30,MinimumLength=2,ErrorMessage="请确保标题长度在2-30个字符之间"),
        Display(Name="标题")]
        public string Title { get; set; }

        /// <summary>
        /// 型号
        /// </summary>
        [StringLength(50,ErrorMessage="请确保型号长度小于50个字符"),Display(Name="型号")]
        public string Model { get; set; }

        /// <summary>
        /// 产品规格
        /// </summary>
        [StringLength(50,ErrorMessage="请确保产品规格小于50个字符"),Display(Name="产品规格")]
        public string Specification { get; set; }

        /// <summary>
        /// 详细说明
        /// </summary>
        [StringLength(2800,ErrorMessage="请确保详细说明小于2800个字符"),Display(Name="详细说明")]
        public string Content { get; set; }

        /// <summary>
        /// 过期时间
        /// </summary>
        [Display(Name="过期时间")]
        public DateTime? ValidDate { get; set; }

        /// <summary>
        /// 失效时间字符串
        /// </summary>
        public string StrValidDate { get; set; }

        /// <summary>
        /// 单位名称
        /// </summary>
        [Display(Name = "单位名称")]
        [StringLength(10,ErrorMessage="请确保单位名称长度小于10个字符")]
        [Required(ErrorMessage="请填写计量单位")]
        public string UnitName {get;set;}

        /// <summary>
        /// 单价
        /// </summary>
        [Display(Name = "单价")]
        [StringLength(8,ErrorMessage="请确保单价长度小于8位数")]
        [Required(ErrorMessage="请填写单价")]
        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// 最小起订数据 
        /// </summary>
        [Display(Name = "最小起订数量")]
        [StringLength(10,ErrorMessage="请确保最小起订数量长度小于10位数")]
        [Required(ErrorMessage="请填写最小起订数量")]
        public int? MOQ { get; set; }

        /// <summary>
        /// 供货总量 
        /// </summary>
        [Display(Name = "供货总量")]
        [StringLength(10,ErrorMessage="请确保供货总量长度小于10位数")]
        [Required(ErrorMessage="请填写供货问题")]
        public int? Total { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? CreateDate { get; set; }

        /// <summary>
        /// 创建时间字符串
        /// </summary>
        public string StrCreateDate { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public DateTime? RefreshDate { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public string StrRefreshDate { get; set; }

        /// <summary>
        /// 标志位
        /// </summary>
        public int? Flag { get; set; }

        /// <summary>
        /// 第一张图片的地址
        /// </summary>
        public string FirstImageUrl { get; set; }

        /// <summary>
        /// 所有图片的地址
        /// </summary>
        public List<string> ImageUrl { get; set; }

        /// <summary>
        /// 所有图片的ID
        /// </summary>
        public List<string> ImageID { get; set; }

        /// <summary>
        /// 浏览次数
        /// </summary>
        public int? BrowserCount { get; set; }

        /// <summary>
        /// 是否推广
        /// </summary>
        public string ISTG { get; set; }
    }

    /// <summary>
    /// 供应信息的分页对象
    /// </summary>
    public class VMSupplyPaging
    {
        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前页数据
        /// </summary>
        public List<VmSupply> rows { get; set; }
    }
}

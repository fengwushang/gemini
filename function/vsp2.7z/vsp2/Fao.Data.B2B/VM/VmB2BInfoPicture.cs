﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// B2B上传文件信息
    /// </summary>
    public class VmB2BInfoPicture
    {
        /// <summary>
        /// 文件URL
        /// </summary>
        public List<string> PictureUrls { get; set; }
        /// <summary>
        /// 文件ID
        /// </summary>
        public List<string> PictureIDs { get; set; }
        /// <summary>
        /// 文件原始名称
        /// </summary>
        public List<string> OriginalName { get; set; }

        
    }
}

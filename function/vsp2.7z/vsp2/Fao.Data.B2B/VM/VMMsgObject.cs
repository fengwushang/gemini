﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: mbx , 2013-02-26 11:10:27
    /// MsgObject视图模型-Power by CodeGG
    /// </summary>
    public class VMMsgObject
    {
        public int IntObjID { get; set; }
        public int type { get; set; }
        public string VarObj { get; set; }
        public int IntEnterpriseID { get; set; }
        public string VarEnterprise { get; set; }
    }
}

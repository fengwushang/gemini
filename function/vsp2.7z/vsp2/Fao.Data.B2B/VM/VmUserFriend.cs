﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// UserFriend视图模型-Power by CodeGG
    /// </summary>
    public class VmUserFriend
    {
        /// <summary>
        /// 加密主键
        /// </summary>
        public string FriendID { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string RealName { get; set; }

        /// <summary>
        /// 公司名
        /// </summary>
        public string EnterpriseName { get; set; }

        /// <summary>
        /// 联系方式 
        /// </summary>
        public string ContactPhone { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public string CreateDate { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public string Type { get; set; }
    }

    public class VmUserFriendPaging
    {
        /// <summary>
        /// 当前页显示记录
        /// </summary>
        public List<VmUserFriend> rows { get; set; }

        /// <summary>
        /// 记录总数
        /// </summary>
        public int total { get; set; }
    }
}
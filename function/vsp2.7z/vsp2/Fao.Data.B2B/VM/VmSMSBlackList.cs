﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: sjp , 2013-07-18
    /// SMSBlackList视图模型-Power by sjp
    /// </summary>
    public class VmSMSBlackList
    {
        /// <summary>
        ///SMSBlackList主键
        /// </summary>
        public string IntSMSBlackListID { get; set; }

        /// <summary>
        ///手机号码
        /// </summary>
        [RegularExpression(@"^(130|131|132|133|134|135|136|137|138|139|185|186|187)\d{8}$", ErrorMessage = "请填写正确格式手机号码")]
        public string VarPhone { get; set; }

        /// <summary>
        ///黑名单所属用户  0系统  >0 用户
        /// </summary>
        public string IntUserID { get; set; }

        /// <summary>
        ///黑名单所属用户名称
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        ///有效状态标识：0无效，1有效
        /// </summary>
        public string IntFlag { get; set; }

        /// <summary>
        ///外键，创建用户ID
        /// </summary>
        public string IntCreateUserID { get; set; }

        /// <summary>
        ///外键，最后一次修改的用户ID
        /// </summary>
        public string IntUpdateAdminID { get; set; }
    }

    /// <summary>
    ///手机黑名单 列表页显示
    /// </summary>
    public class VmSMSBlackListList
    {
        

        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前页面数据
        /// </summary>
        public List<VmSMSBlackList> rows { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-03-13 17:03:47
    /// Sms_MT_Batch视图模型-Power by CodeGG
    /// </summary>
    public class VmSms_MT_Batch
    {
        /// <summary>
        /// 收件箱主键
        /// </summary>
        public Int64 BigBatchID { get; set; }

        /// <summary>
        /// 序号
        /// </summary>
        public long RowNum { get; set; }

        /// <summary>
        /// 短信内容
        /// </summary>
        public string MsgContent { get; set; }

        /// <summary>
        /// 发送类型 1点对点， 2 普通发送 
        /// </summary>
        public int MsgType { get; set; }

        /// <summary>
        /// 发送时间
        /// </summary>
        public string SendTime { get; set; }

        /// <summary>
        /// 发信人
        /// </summary>
        public int OperatorID { get; set; }

        /// <summary>
        /// 发信人姓名
        /// </summary>
        public string Operator { get; set; }
    }

    public class VmSms_MT_BatchPaging
    {
        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前页面数据
        /// </summary>
        public List<VmSms_MT_Batch> rows { get; set; }
    }
}
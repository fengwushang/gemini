﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// Authenticate视图模型-Power by CodeGG
    /// </summary>
    public class VmAuthenticate
    {
        
    }
}
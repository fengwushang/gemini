﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// B2BInfo视图模型-Power by CodeGG
    /// </summary>
    public class VmB2BInfo
    {
        /// <summary>
        /// 主键,加密
        /// </summary>
        public string InfoID { get; set; }

        /// <summary>
        /// 分类名称
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// 类型ID
        /// </summary>
        public int TypeID { get; set; }

        /// <summary>
        /// 类型名称
        /// </summary>
        public string TypeName { get; set; }

        /// <summary>
        /// 企业id
        /// </summary>
        public string EnterpriseID { get; set; }

        /// <summary>
        /// 企业名称
        /// </summary>
        public string EnterpriseName { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 所在地
        /// </summary>
        public string AreaName { get; set; }

         

        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 单价-供应
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// 单位-供应
        /// </summary>
        public string UnitName { get; set; }

        /// <summary>
        /// 型号-供应
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        /// 最小起订数量-供应
        /// </summary>
        public int MOQ { get; set; }

        /// <summary>
        /// 价格要求-求购
        /// </summary>
        public string PriceAsk { get; set; }

        /// <summary>
        /// 供应：供货总量  求购：求购总量
        /// </summary>
        public int TotalAvailability { get; set; }

        /// <summary>
        /// 保证金，万元-招商：保证金;-代理：最低保证金
        /// </summary>
        public int MinSecurityDeposit { get; set; }
   
        /// <summary>
        /// 包装要求-求购
        /// </summary>
        public string Packagingrequire { get; set; }

        /// <summary>
        /// 规格要求 -供应-求购
        /// </summary>
        public string Specifications { get; set; }

        /// <summary>
        /// 信息内容
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// 联系人
        /// </summary>
        public string InfoContact { get; set; }

        /// <summary>
        /// 联系电话
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 移动电话
        /// </summary>
        public string MobilePhone { get; set; }

        /// <summary>
        /// 联系人邮箱
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// 失效时间
        /// </summary>
        public string DateValid { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public string DateCreate { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public string DateRefresh { get; set; }

        /// <summary>
        /// 浏览次数
        /// </summary>
        public int BrowserCount { get; set; }

        /// <summary>
        /// 标志位
        /// </summary>
        public int Flag { get; set; }

        /// <summary>
        /// 信息的主要图片url
        /// </summary>
        public string MainImgUrl { get; set; }

        public List<VmAttachment> Attachment { get; set; }
    }

    public class VMB2BInfoList
    {
        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前面数据
        /// </summary>
        public List<VmB2BInfo> rows { get; set; }
    }
}
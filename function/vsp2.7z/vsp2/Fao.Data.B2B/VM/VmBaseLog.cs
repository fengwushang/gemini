﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-20 10:18:31
    /// BaseLog视图模型-Power by CodeGG
    /// </summary>
    public class VmBaseLog
    {
        public int IntLogID { get; set; }
        public int IntUserID { get; set; }
        public int IntPlatform { get; set; }
        public string VarModel { get; set; }
        public string VarIP { get; set; }
        public string VarInfo { get; set; }
        public DateTime DateCreate { get; set; }
        public int IntLogType { get; set; }

        //操作用户
        public string VarUname { get; set; }

        //日志类型
        public string VarLogType
        {
            get
            {
                switch (IntLogType)
                {
                    case 1: return "登录日志";
                    case 2: return "操作日志";
                    case 3: return "错误日志";
                    default: return "";
                }
            }
        }
    }

    /// <summary>
    /// BaseLog 分页数据
    /// </summary>
    public class BaseLogPaging
    {
        public int total { get; set; }
        public List<VmBaseLog> rows { get; set; }
    }
}
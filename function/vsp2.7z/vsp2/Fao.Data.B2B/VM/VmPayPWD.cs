﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    public class VmPayPWD
    {
        /// <summary>
        /// 旧密码
        /// </summary>
        //[Display(Name = "旧密码"), Required(ErrorMessage = "请填写旧密码")]
        //[DataType(DataType.Password)]
        //public string OldPassword { get; set; }

        /// <summary>
        /// 新密码
        /// </summary>
        [Display(Name = "新密码"), Required(ErrorMessage = "请填写新密码")]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "请确保密码长度在6-20个字符之间")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        /// <summary>
        /// 确认新密码
        /// </summary>
        [Display(Name = "确认密码"), Required(ErrorMessage = "请填写确认密码")]
        [Compare("NewPassword", ErrorMessage = "两次输入的密码不一致")]
        [DataType(DataType.Password)]
        public string ComfirmPassword { get; set; }
    }
}

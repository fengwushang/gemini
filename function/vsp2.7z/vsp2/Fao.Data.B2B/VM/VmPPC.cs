﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; 

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// PPC视图模型-Power by CodeGG
    /// </summary>
    public class VmPPC
    {
        /// <summary>
        /// 热词分类
        /// </summary>
        public int IntWordType { get; set; }

        /// <summary>
        /// 热词
        /// </summary>
        public string VarKeyword { get; set; }

        /// <summary>
        /// 热词价格
        /// </summary>
        [Required(ErrorMessage = "请填写点击一次的价钱"), Display(Name = "热词价格")]
        public decimal DecValue { get; set; }

        /// <summary>
        /// 热词推广者
        /// </summary>
        public string VarNickName { get; set; }

        /// <summary>
        /// 价格排名
        /// </summary>
        public long? ValueRank { get; set; }

        /// <summary>
        /// 有效期至
        /// </summary>
        [Required(ErrorMessage = "请选择有效期")]
        public DateTime DteValid { get; set; }

        /// <summary>
        /// 要推广的信息主键
        /// </summary>
        [Required(ErrorMessage = "请选择要推广的信息ID")]
        public int IntTablePrimkeyID { get; set; }

        /// <summary>
        /// 加密信息ID
        /// </summary>
        public string EncriptTableID { get; set; }

        /// <summary>
        /// 推广信息标题
        /// </summary>
        public string Title { get; set; }

        ///有效的时间段
        public List<VmPPCTactic> ValidTimeSpan { get; set; }

        /// <summary>
        /// 类型名称
        /// </summary>
        public string WordTypeName { get; set; }

        /// <summary>
        /// 加密ID
        /// </summary>
        public string EncryptID { get; set; }

        /// <summary>
        /// 过期时间字符串
        /// </summary>
        public string StrValidDate { get; set; }

        /// <summary>
        /// 创建时间字符串
        /// </summary>
        public string StrCreateDate { get; set; }

        /// <summary>
        /// 有效性0删除，1有效，2无效
        /// </summary>
        public int Flag { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateDate { get; set; }
    }
 

    /// <summary>
    /// 热词价格分页
    /// </summary>
    public class VmPPCPaging
    {
        /// <summary>
        /// 当前页显示记录
        /// </summary>
        public List<VmPPC> rows { get; set; }

        /// <summary>
        /// 记录总数
        /// </summary>
        public int total { get; set; }
    }

}
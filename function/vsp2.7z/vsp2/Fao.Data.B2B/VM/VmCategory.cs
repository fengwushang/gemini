﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Category视图模型-Power by CodeGG
    /// </summary>
    public class VmCategory
    {
        /// <summary>
        /// 父键
        /// </summary>
        public int ParentID { get; set; }

        /// <summary>
        /// 主键
        /// </summary>
        public int CategoryID { get; set; }

        /// <summary>
        /// 分类名称
        /// </summary>
        [Required(ErrorMessage="请填写分类名称")]
        [StringLength(30,ErrorMessage="请确保分类名称长度小于30个字符")]
        public string CatogoryName { get; set; }

        /// <summary>
        /// 简称
        /// </summary>
        [Required(ErrorMessage = "请填写简称")]
        [StringLength(30, ErrorMessage = "请确保简称长度小于30个字符")]
        public string Abbreviation { get; set; }

        /// <summary>
        /// treegrid使用的状态
        /// </summary>
        public string state { get; set; }

        /// <summary>
        /// treegrid使用的父键
        /// </summary>
        public int _parentId { get; set; }

    }
}
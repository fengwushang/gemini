﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Enterprise视图模型-Power by CodeGG
    /// </summary>
    public class VmEnterprise
    {
        /// <summary>
        /// 企业ID，加密字符串
        /// </summary>
        public string EntID { get; set; }

        /// <summary>
        /// 企业ID，加密字符串
        /// </summary>
        public string UserID { get; set; }
        /// <summary>
        /// 联系人邮箱
        /// </summary>
        public string ContactEmail { get; set; }
        /// <summary>
        /// 企业名称
        /// </summary>
        public string EntName { get; set; }
        /// <summary>
        /// 企业电话
        /// </summary>
        public string EntPhone { get; set; }
        /// <summary>
        /// 联系人
        /// </summary>
        public string ContactUser { get; set; }
        /// <summary>
        /// 联系人电话
        /// </summary>
        public string ContactUserPhone { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public string CreateDate { get; set; }

        /// <summary>
        /// 详细信息
        /// </summary>
        public string Detail { get; set; }

        /// <summary>
        /// 地区
        /// </summary>
        public string AreaName { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// 企业标识
        /// </summary>
        public string Flag { get; set; }

        /// <summary>
        /// 用户标识
        /// </summary>
        public string uFlag { get; set; }

    }

    /// <summary>
    /// 企业视图分页类
    /// 适用于easyui对分页数据的要求
    /// </summary>
    public class VmEnterprisePaging
    {
        /// <summary>
        /// 总数
        /// </summary>
        public string total { get; set; }

        /// <summary>
        /// 数据行
        /// </summary>
        public List<VmEnterprise> rows { get; set; }

    }
}
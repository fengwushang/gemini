﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.MV
{
    /// <summary>
    /// 注册用VM
    /// </summary>
    public class VmRegister
    {
        /// <summary>
        /// 密码
        /// </summary>
        [Required(ErrorMessage = "请填写密码")]
        [DataType(DataType.Password)]
        [StringLength(20, MinimumLength = 6, ErrorMessage = "请确保密码长度在6-20个字符之间")]
        [Display(Name = "密码")]
        public string Password { get; set; }

        /// <summary>
        /// 确认密码
        /// </summary>
        [Required(ErrorMessage = "请确认密码")]
        [DataType(DataType.Password)]
        [Display(Name = "确认密码")]
        [Compare("Password", ErrorMessage = "密码不一致")]
        public string ConfirmPassword { get; set; }

        /// <summary>
        /// Email
        /// </summary>
        [Required(ErrorMessage = "请填写有效的E-mail地址")]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}", ErrorMessage = "请填写正确的EMail地址")]
        [Display(Name = "Email")]
        [StringLength(20,MinimumLength=6,ErrorMessage="请确保Email长度在6-20个字符之间")]
        public string Email { get; set; }


        public string UserID { get; set; }

        public int PhoneVerify { get; set; }
        public int EmailVerify { get; set; }

        public string  EmailVerifyCode{ get; set; }
        public DateTime DteEmailVerifyValid { get; set; }	
        
        public string NickName { get; set; }
        public string RealName { get; set; }
        public string Phone { get; set; }

        public int Age { get; set; }
        public string QQ { get; set; }
        public int Area { get; set; }
        public int Industry { get; set; }
        public int Sex { get; set; }
        public string Address { get; set; }

    }
}

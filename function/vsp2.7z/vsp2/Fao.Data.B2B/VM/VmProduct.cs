﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Product视图模型-Power by CodeGG
    /// </summary>
    public class VmProduct
    {
        public int IntProductID { get; set; }

        //产品编号
        public int VarProductNum { get; set; }

        //外键，属于那个品牌ID
        public int IntBrandID { get; set; }

        //单价
        public float DecimUnitPrice { get; set; }

        //外键，产地、地区表主键
        public int IntAreaID { get; set; }

        //品名
        public string VarProductName { get; set; }

        //型号
        public string VarProductType { get; set; }

        //售后服务
        public string VarAfterSerivice { get; set; }

        //包装规格
        public string VarPackaging { get; set; }

        //毛重
        public string VarGW { get; set; }

        //起订数量
        public int IntStartOrderNum { get; set; }

        //库存
        public int IntStock { get; set; }

        //创建日期
        public DateTime DateCreate { get; set; }

        //刷新时间
        public DateTime DateRefresh { get; set; }
    }
}
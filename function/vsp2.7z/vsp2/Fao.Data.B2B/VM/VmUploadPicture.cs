﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    public class VmUploadPicture
    {
        /// <summary>
        /// 缩略图文件名
        /// </summary>
        public string SmallFileName { get; set; }
        /// <summary>
        /// 路径
        /// </summary>
        public string Path { get; set; }
        /// <summary>
        /// ID
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// 生成文件名
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// 原文件名
        /// </summary>
        public string OriginalName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// HotWordPrice视图模型-Power by CodeGG
    /// </summary>
    public class VmHotWordPrice
    {
        /// <summary>
        /// 热词类型
        /// </summary>
        [Required(ErrorMessage="请选择热词类型")]
        [Display(Name="热词类型")]
        public int IntWordType { get; set; }

        /// <summary>
        /// 热词起步价格  
        /// </summary>
        [Display(Name="起步价格")]
        [Required(ErrorMessage="请填写起步价格")]
        public decimal DecStartPrice { get; set; }

        /// <summary>
        /// 热词加价幅度
        /// </summary>
        [Display(Name="加价幅度")]
        [Required(ErrorMessage="请填写加价幅度")]
        public decimal DecStepPrice { get; set; }

        /// <summary>
        /// 热词
        /// </summary>
        [Required(ErrorMessage="请填写热词")]
        public string VarWord { get; set; }

        /// <summary>
        /// 热词类型名称
        /// </summary>
        public string VarWordTypeName { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public string StrCreateDate { get; set; }

        /// <summary>
        /// 加密ID
        /// </summary>
        public string EncriptID { get; set; }
    }
     
    /// <summary>
    /// 热词价格分页
    /// </summary>
    public class VmHotWordPricePaging
    {
        /// <summary>
        /// 当前页显示记录
        /// </summary>
        public List<VmHotWordPrice> rows { get; set; }

        /// <summary>
        /// 记录总数
        /// </summary>
        public int total { get; set; }
    }
}
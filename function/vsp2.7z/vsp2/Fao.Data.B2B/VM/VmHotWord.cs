﻿using System;
using System.Collections.Generic; 

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: chf,2013-2-27 14:25:03
    /// HotWord视图模型-Power by CodeGG
    /// </summary>
    public class VmHotWord
    {
        /// <summary>
        /// 热词分类  
        /// </summary>
        public int IntWordType { get; set; }

        /// <summary>
        /// 热词
        /// </summary>
        public string VarWord { get; set; }

        /// <summary>
        /// 热词查询次数
        /// </summary>
        public int? WordCount { get; set; }

        /// <summary>
        /// 检索排名
        /// </summary>
        public long? CountRank { get; set; }

        /// <summary>
        /// 分类名称
        /// </summary>
        public string WordType { get; set; }

        /// <summary>
        /// 热词创建时间
        /// </summary>
        public string StrCreateDate { get; set; }

    }

    /// <summary>
    /// 热词分页
    /// </summary>
    public class VmHotWordList
    {
        /// <summary>
        /// 当前页显示记录
        /// </summary>
        public List<VmHotWord> rows { get; set; }

        /// <summary>
        /// 记录总数
        /// </summary>
        public int total { get; set; }
    }


    public class HotWordString
    {
        /// <summary>
        /// 供应
        /// </summary>
        public string HotGY { get; set; }
        /// <summary>
        /// 求购
        /// </summary>
        public string HotQG { get; set; }

        /// <summary>
        /// 招商
        /// </summary>
        public string HotZS { get; set; }

        /// <summary>
        /// 合作
        /// </summary>
        public string HotHZ { get; set; }

        /// <summary>
        /// 代理
        /// </summary>
        public string HotDL { get; set; }
        /// <summary>
        /// B2B站点
        /// </summary>
        public string B2BSite { get; set; }
        /// <summary>
        /// PS站点
        /// </summary>
        public string PSSite { get; set; }
    }

}
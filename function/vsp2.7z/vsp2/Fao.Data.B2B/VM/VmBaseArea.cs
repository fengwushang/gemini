﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Area视图模型-Power by CodeGG
    /// </summary>
    public class VmBaseArea
    {
        /// <summary>
        /// 父级ID
        /// </summary>
        public int ParentID { get; set; }

        /// <summary>
        /// 地区ID
        /// </summary>
        public int AreaID { get; set; }

        /// <summary>
        /// 地区I名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 地区简称
        /// </summary>
        public string AbbName { get; set; }

        /// <summary>
        /// 地区邮编
        /// </summary>
        public string Zip { get; set; }

        /// <summary>
        /// 地区编号
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// 是否港口
        /// </summary>
        public string IsPost { get; set; }

        /// <summary>
        /// 节点状态，easyui用
        /// </summary>
        public string state { get; set; }

        /// <summary>
        /// 父级id，easyui用
        /// </summary>
        public int _parentId { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// PPCRecord视图模型-Power by CodeGG
    /// </summary>
    public class VmPPCRecord
    {
        //竞价记录表  （所有从竞价结果列表中，点击过来的都记录）
        public int PPCRecordID { get; set; }

        //外键，竞价表主键
        public int PPCID { get; set; }

        //本次扣费金额   (扣钱：24小时一个IP扣一次，时间设置放到配置文件中)                        
        public decimal DecDeduction { get; set; }

        //创建时间                            
        public string DateCreate { get; set; }

        //事由 根据竞价记录信息组织
        public string Content { get; set; }
    }

    /// <summary>
    /// PPCRecord 分页数据
    /// </summary>
    public class VMPPCRecordPaging
    {
        public int total { get; set; }
        public List<VmPPCRecord> rows { get; set; }
    }
}
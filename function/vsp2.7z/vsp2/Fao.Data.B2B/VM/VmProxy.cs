﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// 代理信息
    /// </summary>
    public class VmProxy
    {
        /// <summary>
        /// 加密主键ID
        /// </summary>
        public string EncriptID { get; set; }

        /// <summary>
        /// 地区ID
        /// </summary>
        [Required(ErrorMessage = "请选择地区")]
        [Display(Name = "地区")]
        public int? AreaID { get; set; }

        /// <summary>
        /// 地区名称
        /// </summary>
        public string AreaName { get; set; }

        /// <summary>
        /// 分类ID
        /// </summary>
        [Required(ErrorMessage = "请选择所属分类"), Display(Name = "所属分类")]
        public int? CategoryID { get; set; }

        /// <summary>
        /// 所属分类
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        [Required(ErrorMessage = "请填写标题"),
        StringLength(30, MinimumLength = 2, ErrorMessage = "请确保标题长度在2-30个字符之间"),
        Display(Name = "标题")]
        public string Title { get; set; }

        /// <summary>
        /// 详细说明
        /// </summary>
        [StringLength(2800, ErrorMessage = "请确保详细说明小于2800个字符"), Display(Name = "详细说明")]
        public string Content { get; set; }

        /// <summary>
        /// 过期时间
        /// </summary>
        [Display(Name = "过期时间")]
        public DateTime? ValidDate { get; set; }

        /// <summary>
        /// 失效时间字符串
        /// </summary>
        public string StrValidDate { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? CreateDate { get; set; }

        /// <summary>
        /// 创建时间字符串
        /// </summary>
        public string StrCreateDate { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public DateTime? RefreshDate { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public string StrRefreshDate { get; set; }

        /// <summary>
        /// 标志位
        /// </summary>
        public int? Flag { get; set; }

        /// <summary>
        /// 第一张图片的地址
        /// </summary>
        public string FirstImageUrl { get; set; }

        /// <summary>
        /// 所有图片的地址
        /// </summary>
        public List<string> ImageUrl { get; set; }

        /// <summary>
        /// 所有图片的ID
        /// </summary>
        public List<string> ImageID { get; set; }

        /// <summary>
        /// 浏览次数
        /// </summary>
        public int? BrowserCount { get; set; }

        /// <summary>
        /// 最低保证金
        /// </summary>
        [Required(ErrorMessage = "请填写最低保证金"),
        Display(Name = "最低保证金")]
        [StringLength(8,ErrorMessage="请确保最低保证金小于8位数")]
        public int? SecurityDeposit { get; set; }

        /// <summary>
        /// 是否已推广
        /// </summary>
        public string ISTG { get; set; }
    }

    /// <summary>
    /// 代理信息分页对象
    /// </summary>
    public class VmProxyPaging
    {
        /// <summary>
        /// 总行数
        /// </summary>
        public int total { get; set; }

        /// <summary>
        /// 当前页数据
        /// </summary>
        public List<VmProxy> rows { get; set; }

    }


}

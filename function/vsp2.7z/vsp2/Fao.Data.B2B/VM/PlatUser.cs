﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: sjp , 2013-07-02
    /// 联合登录 PlatUser视图模型-Power by sjp
    /// </summary>
    public class PlatUser
    {
        /// <summary>
        /// 本平台的UserID
        /// </summary>
        public string IntCreateUserID { get; set; }
        /// <summary>
        /// 平台标识：1 B2B，2 HR 3,ps
        /// </summary>
        public string IntTypeID { get; set; }
        /// <summary>
        /// 对应平台的UserID
        /// </summary>
        public string IntUserID { get; set; }

        /// <summary>
        /// UUID
        /// </summary>
        public string VarTokenID { get; set; }

    }
}

﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// PPCTactic视图模型-Power by CodeGG
    /// </summary>
    public class VmPPCTactic
    {
        /// <summary>
        /// 外键，PPC表主键；时段属于哪条推广的
        /// </summary>
        public int IntPPCID { get; set; }

        /// <summary>
        /// 一天中开始生效时间
        /// </summary>
        public DateTime DteEndTime { get; set; }

        /// <summary>
        /// 一天中失效的时间
        /// </summary>
        public DateTime DteStartTime { get; set; }

        /// <summary>
        /// 标识位 0无效，1有效
        /// </summary>
        public int IntFlag { get; set; }

    }
}
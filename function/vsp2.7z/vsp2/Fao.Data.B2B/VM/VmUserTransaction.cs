﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// UserTransaction视图模型-Power by CodeGG
    /// </summary>
    public class VmUserTransaction
    {

        //用户交易表主键
        public int UserTransaction { get; set; }

        //外键，用户表主键
        public int UserID { get; set; }

        //账户总余额
        public decimal AccountBalance { get; set; }

        //支付密码，所有支付时都要使用
        public string PaymentPwd { get; set; }

        //短信剩余条数
        public int PhoneMsgSum { get; set; }

        //推广排名余额
        public decimal PPCBalance { get; set; }

        //短信子号
        public int IntSMSSrcID { get; set; }

    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticCargo视图模型-Power by CodeGG
    /// </summary>
    public class VmLogisticCargo
    {
        //货源表
        public string CargoID { get; set; }

        /// <summary>
        /// 加密ID
        /// </summary>
        public string EncriptID { get; set; }

        //消息标题
        [Required(ErrorMessage="请填写货物名称")]
        [StringLength(90, ErrorMessage = "请确保货物名称长度在2-30个字符之间")]
        [Display(Name = "消息标题")]
        public string CargoTitle { get; set; }

        //外键，企业ID
        public string EntID { get; set; }
        public string EntName { get; set; }

        //用户表ID，哪个用户发布的
        public int UserID { get; set; }
        public string UserName { get; set; }

        //外键，起始地，地区表ID
        [Required(ErrorMessage="请选择起始地")]
        [Display(Name = "起始地")]
        public int? AreaIDStart { get; set; }
        public string StartArea { get; set; }

        //外键，目的地，地区表ID
        [Required(ErrorMessage="请选择目的地")]
        [Display(Name = "目的地")]
        public int? AreaIDEnd { get; set; }
        public string EndArea { get; set; }

        //外键，字典表，货物类型
        [Required(ErrorMessage="请选择货物类型")]
        [Display(Name = "货物类型")]
        public int? CargoType { get; set; }
        public string Type { get; set; }

        //外键，字典表，货物类别
        [Required(ErrorMessage="请选择货物类别")]
        [Display(Name = "货物类别")]
        public int? CargoCate { get; set; }
        public string Cate { get; set; }

        //重量
        [Required(ErrorMessage="请填写重量")]
        [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "请填写正确的重量")]
        [StringLength(10,ErrorMessage="请确保重量小于10位数")]
        [Display(Name = "重量")]
        public string CargoWeight { get; set; }

        //外键，字典表，运输方式
        [Required(ErrorMessage="请填写运送方式 ")]
        [Display(Name = "运输方式")]
        public int? CargoTransType { get; set; }
        public string TransType { get; set; }

        //外键，字典表，运输要求
        [Display(Name = "运输要求")]
        public int? CargoTransAsk { get; set; }
        public string TransAsk { get; set; }

        //外键，字典表，包装方式]
        [Display(Name = "包装方式")]
        public int? CargoPackage { get; set; }
        public string Package { get; set; }

        //运费
        [StringLength(8, ErrorMessage = "请确保运费小于8位数")]
        [Display(Name="运费")]
        public decimal? DecCargoFreight { get; set; }

        //运外键，字典表，费单位
        [Display(Name="运费单位")]
        public int? FreightUnit { get; set; }
        public string Unit { get; set; }

        //联系人
        [Required(ErrorMessage="请填写联系人")]
        [StringLength(10,ErrorMessage="请确保联系人长度小于10个字符")]
        [Display(Name="联系人")]
        public string Contact { get; set; }

        //联系方式
        [Required(ErrorMessage = "请填写联系电话")]
        [RegularExpression(@"((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)", ErrorMessage = "请填写正确的电话号码")]
        [Display(Name="联系电话")]
        public string Phone { get; set; }

        //发布日期
        public string DteCreate { get; set; }

        //刷新时间
        public string DteRefresh { get; set; }

        //有效期至
        public string DteValid { get; set; }

        //浏览次数
        public int BrowserCount { get; set; }

        //详细说明
        [StringLength(2800, ErrorMessage = "请确保详细信息内容小于2800个字符")]
        [Display(Name="详细信息")]
        public string Details { get; set; }

        //标志位： 0 删除，1保存，2 待审批，3通过，4不通过
        public int? Flag { get; set; }

        //默认图片
        public string ImgUrl { get; set; }

        /// <summary>
        /// 所有图片的ID
        /// </summary>
        public List<string> ImageID { get; set; }


        /// <summary>
        /// 所有图片的地址
        /// </summary>
        public List<string> ImageUrl { get; set; }

        /// <summary>
        /// 有效期
        /// </summary>
        public DateTime? ValidDate { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public DateTime? RefreshDate { get; set; }

        /// <summary>
        /// 是否推广
        /// </summary>
        public string ISTG { get; set; }

        /// <summary>
        /// 信息推广id，null为没有参加推广
        /// </summary>
        public string PPCID { get; set; }

        /// <summary>
        /// 手机以及短信标识
        /// </summary>
        public string Sms { get; set; }
    }

    /// <summary>
    /// BaseLog 分页数据
    /// </summary>
    public class LogisticCargoPaging
    {
        public int total { get; set; }
        public List<VmLogisticCargo> rows { get; set; }
    }
}
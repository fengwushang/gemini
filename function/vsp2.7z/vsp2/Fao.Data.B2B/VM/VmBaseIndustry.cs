﻿using System;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// BaseIndustry视图模型-Power by CodeGG
    /// </summary>
    public class VmBaseIndustry
    {
        /// <summary>
        /// 父级ID
        /// </summary>
        public int ParentID { get; set; }

        /// <summary>
        /// 行业ID
        /// </summary>
        public int IndID { get; set; }

        /// <summary>
        /// 行业名称
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 行业简称
        /// </summary>
        public string AbbName { get; set; }
 

        /// <summary>
        /// 节点状态，easyui用
        /// </summary>
        public string state { get; set; }

        /// <summary>
        /// 父级id，easyui用
        /// </summary>
        public int _parentId { get; set; }
    }
}
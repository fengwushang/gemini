﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: yzq , 2013-02-22 
    /// VmInfoForHome视图模型-为前台页面列表使用
    /// </summary>
    public class VmInfoForHome
    {
        /// <summary>
        /// 信息id需加密
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// 用户手机信息，要加密
        /// </summary>
        public string Sms { get; set; }

        /// <summary>
        /// 信息标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 信息简述
        /// </summary>
        public string Detail { get; set; }

        /// <summary>
        /// 信息刷新日期
        /// </summary>
        public string RefreshDate { get; set; }

        /// <summary>
        /// 用户ID，需加密
        /// </summary>
        public string CreateUserID { get; set; }

        /// <summary>
        /// 企业名称
        /// </summary>
        public string EntName { get; set; }

        /// <summary>
        /// 信息发布地区，省-市
        /// </summary>
        public string Area { get; set; }

        /// <summary>
        /// 起订数量
        /// </summary>
        public string OrderCount { get; set; }

        /// <summary>
        /// 供货总量
        /// </summary>
        public string Total { get; set; }

        /// <summary>
        /// 单价单位
        /// </summary>
        public string Unit{get;set;}

        /// <summary>
        /// 单价
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// 信息图片url
        /// </summary>
        public string ImgUrl { get; set; }

        /// <summary>
        /// 信息推广id，null为没有参加推广
        /// </summary>
        public string PPCID { get; set; }


    }

    /// <summary>
    /// created by: yzq , 2013-02-22 
    /// VmInfoForHomePaging视图模型-为前台页面列表分页使用
    /// </summary>
    public class VmInfoForHomePaging
    {
        public int total { get; set; }

        public List<VmInfoForHome> rows { get; set; }
    }
}

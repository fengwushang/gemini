﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: chf,2013年7月11日11:06:45
    /// BaseUser视图模型 
    /// </summary>
    public class VmBasePlatform
    {
        /// <summary>
        /// 主键
        /// </summary>
        public string IntPID { get; set; }
         

        /// <summary>
        ///本平台用户ID
        /// </summary>
        public string IntCreateUserID { get; set; }

        /// <summary>
        ///平台标识：1 B2B，2 HR，3PS
        /// </summary>
        public string IntTypeID { get; set; }

        /// <summary>
        /// 对应平台的UserID
        /// </summary>
        public string IntUserID { get; set; }

        /// <summary>
        /// 状态标识位：1有效，0无效
        /// </summary>
        public string IntFlag { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime DteCreate { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        public DateTime DteUpdate { get; set; }

    }
}

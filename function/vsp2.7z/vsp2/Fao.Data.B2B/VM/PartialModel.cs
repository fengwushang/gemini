﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by：yzq 2013-02-26
    /// 分部视图模型，用于主视图给分部视图传参
    /// </summary>
    public class PartialModel
    {
        /// <summary>
        /// 控件视图ID
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// 设置控件的值
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// 设置控件的显示文本
        /// </summary>
        public string Text { get; set; }
        
    }
}

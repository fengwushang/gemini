﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Fao.Data.B2B.VM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticStore视图模型-Power by CodeGG
    /// </summary>
    public class VmLogisticStore
    {
        /// <summary>
        /// 库源表ID
        /// </summary>
        public int? StoreID { get; set; }

        /// <summary>
        /// 加密ID
        /// </summary>
        public string EncriptID { get; set; }

        /// <summary>
        /// 外键，企业ID
        /// </summary>
        public string EntID { get; set; }
        /// <summary>
        /// 企业名称
        /// </summary>
        public string EntName { get; set; }

        /// <summary>
        /// 外键，发布用户ID
        /// </summary>
        public int UserID { get; set; }
        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 仓库名称
        /// </summary>
        [Required(ErrorMessage="请填写仓库名称")]
        [StringLength(150, ErrorMessage = "请确保仓库名称长度在2-30个字符之间")]
        [Display(Name="仓库名称")]
        public string StoreTitle { get; set; }

        /// <summary>
        /// 外键，字典表，仓库类型
        /// </summary>
        [Required(ErrorMessage="请选择仓库类型")]
        [Display(Name="仓库类型")]
        public int? StoreType { get; set; }
        /// <summary>
        /// 类型名称
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// 外键，字典表，货架类型
        /// </summary>
        [Required(ErrorMessage="请选择货架类型")]
        [Display(Name="货架类型")]
        public int? StoreShelfType { get; set; }
        /// <summary>
        /// 货架类型
        /// </summary>
        public string ShelfType { get; set; }

        /// <summary>
        /// 总容量
        /// </summary>
        [Required(ErrorMessage="请填写总容量")]
        [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "请填写正确的总容量")]
        [StringLength(10,ErrorMessage="请确保总容量小于10位数")]
        [Display(Name="总容量")]
        public string StoreCapacity { get; set; }

        /// <summary>
        /// 可用容量
        /// </summary>
        [Required(ErrorMessage = "请填写可用容量")]
        [RegularExpression("^[1-9][0-9]*$", ErrorMessage = "请填写正确的可用容量")]
        [StringLength(10,ErrorMessage="请确保可用容量小于10位数")]
        [Display(Name="可用容量")]
        public string StoreUseCapacity { get; set; }

        /// <summary>
        /// 容量单位名称
        /// </summary>
        [Display(Name="容量单位")]
        [StringLength(10,ErrorMessage="请确保容量单位长度小于10个字符")]
        [Required(ErrorMessage="请选择容量单位")]
        public string VarUnit { get; set; }

        /// <summary>
        /// 外键，所在地、地址表ID
        /// </summary>
        [Required(ErrorMessage="请选择仓库所在地")]
        [Display(Name="所在地")]
        public int? AreaID { get; set; }
        /// <summary>
        /// 所在地
        /// </summary>
        public string AreaName { get; set; }

        /// <summary>
        /// 联系人
        /// </summary>
        [Required(ErrorMessage="请填写联系人")]
        [StringLength(98,ErrorMessage="请确保联系人字段小于10个字符")]
        [Display(Name="联系人")]
        public string Contact { get; set; }

        /// <summary>
        /// 联系电话
        /// </summary>
        [Required(ErrorMessage = "请填写联系电话")]
        [RegularExpression(@"((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)", ErrorMessage = "请填写正确的电话号码")]
        [Display(Name="联系电话")]
        public string Phone { get; set; }

        /// <summary>
        /// 发布日期字符串
        /// </summary>
        public string DteCreate { get; set; }

        /// <summary>
        /// 有效期字符串
        /// </summary>
        public string DteValid { get; set; }

        /// <summary>
        /// 刷新时间字符串
        /// </summary>
        public string DteRefresh { get; set; }

        /// <summary>
        /// 浏览次数
        /// </summary>
        public int BrowserCount { get; set; }

        /// <summary>
        /// 详细说明 
        /// </summary>
        [StringLength(2800, ErrorMessage = "请确保详细信息内容小于2800个字符")]
        [Display(Name="详细说明")]
        public string Details { get; set; }

        /// <summary>
        /// 图片URL
        /// </summary>
        public string ImgUrl { get; set; }

        /// <summary>
        /// 所有图片的ID
        /// </summary>
        public List<string> ImageID { get; set; }

        /// <summary>
        /// 标志位
        /// </summary>
        public int? Flag { get; set; }


        /// <summary>
        /// 所有图片的地址
        /// </summary>
        public List<string> ImageUrl { get; set; }

        /// <summary>
        /// 有效期
        /// </summary>
        public DateTime? ValidDate { get; set; }

        /// <summary>
        /// 刷新时间
        /// </summary>
        public DateTime? RefreshDate { get; set; }

        /// <summary>
        /// 是否推广
        /// </summary>
        public string ISTG { get; set; }

        /// <summary>
        /// 信息推广id，null为没有参加推广
        /// </summary>
        public string PPCID { get; set; }

        /// <summary>
        /// 手机以及短信标识
        /// </summary>
        public string Sms { get; set; }
    }

    /// <summary>
    /// 库源 分页数据
    /// </summary>
    public class LogisticStorePaging
    {
        public int total { get; set; }
        public List<VmLogisticStore> rows { get; set; }
    }
}
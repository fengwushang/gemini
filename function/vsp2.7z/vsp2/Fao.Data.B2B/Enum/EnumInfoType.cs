﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.Enum
{
    /// <summary>
    /// created by: chf , 2013-2-27 9:06:09
    /// 各类信息的标识,与数据库存储对应  
    /// </summary>
    public enum EnumInfoType
    { 
        供应 = 1, 求购=2, 招商=3, 代理=5, 合作=4, 货源=6, 库源=7, 车源=8, 物流专线=9
    }
    //Array ay = Enum.GetValues(typeof(EnumInfoType)); 
}

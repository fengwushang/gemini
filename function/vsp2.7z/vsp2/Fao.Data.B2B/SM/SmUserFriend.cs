﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// UserFriend查询模型-Power by CodeGG
    /// </summary>
    public class SmUserFriend
    {
        /// <summary>
        /// 类型 1好友，2关注 
        /// </summary>
        public int FriendType { get; set; }

    }
}
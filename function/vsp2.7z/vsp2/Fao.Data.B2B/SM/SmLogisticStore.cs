﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticStore查询模型-Power by CodeGG
    /// </summary>
    public class SmLogisticStore
    {
        //主键
        public int ID { get; set; }

        //关键字
        public string KeyWord { get; set; }

        //仓库类型
        public int StoreType { get; set; }

        //库源地
        public int AreaID { get; set; }

        //开始 刷新日期
        public string DteRefreshStart { get; set; }

        //结束 刷新日期
        public string DteRefreshEnd { get; set; }

        /// <summary>
        /// 仓库名称
        /// </summary>
        public string StoreTitle { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public int state { get; set; }
         
        /// <summary>
        /// 是否是检索
        /// </summary>
        public string SeFlag { get; set; }

        /// <summary>
        /// 0表示未推广
        /// </summary>
        public string ISTG { get; set; }
    }
}
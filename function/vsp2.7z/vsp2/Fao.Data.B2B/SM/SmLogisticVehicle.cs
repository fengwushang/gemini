﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LogisticVehicle查询模型-Power by CodeGG
    /// </summary>
    public class SmLogisticVehicle
    {
        public string LicenseNum { get; set; }
        public int state { get; set; }
    }
}
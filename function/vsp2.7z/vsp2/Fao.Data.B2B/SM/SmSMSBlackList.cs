﻿using System;


namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: sjp , 2013-07-18
    /// SMSBlackList查询模型-Power by sjp
    /// </summary>
    public class SmSMSBlackList
    {
        /// <summary>
        ///修改开始时间
        /// </summary>
        public string startDate { get; set; }

        /// <summary>
        ///修改结束时间
        /// </summary>
        public string endDate { get; set; }

        /// <summary>
        ///手机号码
        /// </summary>
        public string varPhone { get; set; }
    }
}

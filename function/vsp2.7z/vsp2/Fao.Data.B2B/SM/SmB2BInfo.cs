﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// B2BInfo查询模型-Power by CodeGG
    /// </summary>
    public class SmB2BInfo
    {
        /// <summary>
        /// 标志位 0删除 1 保存 2待审批 3通过 4不通过
        /// </summary>
        public int Flag { get; set; }


        /// <summary>
        /// 标题
        /// </summary>
        public string InfoTitle { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public int Type { get; set; }

        /// <summary>
        /// 地区id
        /// </summary>
        public int AreaID { get; set; }

        /// <summary>
        /// 分类ID
        /// </summary>
        public int Category { get; set; }

    }
}
﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-03-13 17:03:47
    /// Sms_MT_Detail查询模型-Power by CodeGG
    /// </summary>
    public class SmSms_MT_Detail
    {
        /// <summary>
        /// 批次ID
        /// </summary>
        public int BatchID { get; set; }

        /// <summary>
        /// 发送开始时间
        /// </summary>
        public string SendStartDate { get; set; }

        /// <summary>
        /// 发送结束时间
        /// </summary>
        public string SendEndDate { get; set; }

        /// <summary>
        ///接收人 
        /// </summary>
        public string ReciverUserName { get; set; }

        /// <summary>
        /// 短信状态
        /// </summary>
        public string SmsState { get; set; }
    }

    /// <summary>
    /// 收件箱
    /// </summary>
    public class smSmsInbox
    {
        /// <summary>
        /// 发送开始时间
        /// </summary>
        public string SendStartDate { get; set; }

        /// <summary>
        /// 发送结束时间
        /// </summary>
        public string SendEndDate { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string MobileNum { get; set; }
    }
}
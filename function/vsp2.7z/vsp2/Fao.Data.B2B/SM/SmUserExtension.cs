﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// UserExtension查询模型-Power by CodeGG
    /// </summary>
    public class SmUserExtension
    {
        
    }
}
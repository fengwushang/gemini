﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-20 10:18:31
    /// BaseLog查询模型-Power by CodeGG
    /// </summary>
    public class SmBaseLog
    {
        public int IntLogID { get; set; }
        public int IntUserID { get; set; }
        public int IntPlatform { get; set; }
        public string VarModel { get; set; }
        public string VarIP { get; set; }
        public string VarInfo { get; set; }
        public DateTime DateCreate { get; set; }
        public int IntLogType { get; set; }
    }
}
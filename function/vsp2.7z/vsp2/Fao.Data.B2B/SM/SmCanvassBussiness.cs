﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// 招商信息查询类
    /// </summary>
    public class SmCanvassBussiness
    {
        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public int state { get; set; }

        /// <summary>
        /// 为0表示未推广
        /// </summary>
        public string ISTG { get; set; }
    }
}

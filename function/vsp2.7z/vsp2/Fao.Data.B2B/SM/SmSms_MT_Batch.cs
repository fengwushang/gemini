﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-03-13 17:03:47
    /// Sms_MT_Batch查询模型-Power by CodeGG
    /// </summary>
    public class SmSms_MT_Batch
    {
        /// <summary>
        /// 发送开始时间
        /// </summary>
        public string SendStartDate { get; set; }

        /// <summary>
        /// 发送结束时间
        /// </summary>
        public string SendEndDate { get; set; }
    }
}
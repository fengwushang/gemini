﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// SMSBuyLog查询模型-Power by CodeGG
    /// </summary>
    public class SmSMSBuyLog
    {
        /// <summary>
        /// 发送开始时间
        /// </summary>
        public string SendStartDate { get; set; }

        /// <summary>
        /// 发送结束时间
        /// </summary>
        public string SendEndDate { get; set; }
    }
}
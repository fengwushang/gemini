﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// LeaveMsg查询模型-Power by CodeGG
    /// </summary>
    public class SmLeaveMsg
    {

        /// <summary>
        /// 分类 
        /// </summary>
        public int BelongTable { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public int Type { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

    }
}

﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// PPC查询模型-Power by CodeGG
    /// </summary>
    public class SmPPC
    {
        /// <summary>
        /// 1未过期，2过期
        /// </summary>
        public int state { get; set; }

        /// <summary>
        /// 热词类型
        /// </summary>
        public int Type { get; set; }

        /// <summary>
        /// 热词
        /// </summary>
        public string WordKey { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public string StartTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        public string EndTime { get; set; }
    }
}
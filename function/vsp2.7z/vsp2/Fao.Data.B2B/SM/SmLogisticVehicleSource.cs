﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// LogisticVehicleSource查询模型-Power by CodeGG
    /// </summary>
    public class SmLogisticVehicleSource
    {
        //主键
        public int ID { get; set; }

        //关键字
        public string KeyWord { get; set; }

        //外键，起始地，地区表ID
        public int AreaIDStart { get; set; }

        //外键，目的地，地区表ID
        public int AreaIDEnd { get; set; }

        //开始 刷新日期
        public string DteRefreshStart { get; set; }

        //结束 刷新日期
        public string DteRefreshEnd { get; set; }

        /// <summary>
        /// 车牌号码
        /// </summary>
        public string LicenseNum { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public int state { get; set; }

        /// <summary>
        /// 是否是检索
        /// </summary>
        public string SeFlag { get; set; }

        /// <summary>
        /// 0表示未推广
        /// </summary>
        public string ISTG { get; set; }
    }
}
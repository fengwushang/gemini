﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-27 09:20:35
    /// Attachment查询模型-Power by CodeGG
    /// </summary>
    public class SmAttachment
    {
         //附件表
        public int IntAttachmentID { get; set; }

        //标志位；归属表的区分。1 (LogisticCargo) 货源表，2(LogisticStore)库源表，3（LogisticVehicle）车辆表 ，
        //4(LogisticVehicleSource)车源表，5(LogisticRoute)物流专线表, 6 (B2BInfo)信息表，7(Authenticate)认证表
        public int IntBelongTable { get; set; }

        //外键，附件归属表的主键ID
        public int IntBelongTablePrikeyID { get; set; }

        //文件标题
        public int VarFileName { get; set; }

        //文件相对地址
        public int VarFilePath { get; set; }

        //描述信息
        public int VarDescrip { get; set; }

        //创建时间
        public int DteCreate { get; set; }

        //显示顺序 (如果是图片时，当只展示一张时，展示该消息第一张图)
        public int IntOrder { get; set; }

        //标志位；0 无效，1有效
        public int IntFlag { get; set; }
    }
}
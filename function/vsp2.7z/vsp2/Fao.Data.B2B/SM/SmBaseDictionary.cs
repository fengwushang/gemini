﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-20 10:18:31
    /// BaseDictionary查询模型-Power by CodeGG
    /// </summary>
    public class SmBaseDictionary
    {
        /// <summary>
        /// 父键
        /// </summary>
        public int ParentID { get; set; }

        /// <summary>
        /// 简称
        /// </summary>
        public string AbbName { get; set; }
    }
}
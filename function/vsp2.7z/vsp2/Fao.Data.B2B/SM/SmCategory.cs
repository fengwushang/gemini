﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Category查询模型-Power by CodeGG
    /// </summary>
    public class SmCategory
    {
        /// <summary>
        /// 父键
        /// </summary>
        public int ParentID { get; set; }

    }
}
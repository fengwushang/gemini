﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-21 10:32:34
    /// BaseAdmin查询模型-Power by CodeGG
    /// </summary>
    public class SmBaseAdmin
    {
        //管理员登陆名称
        public string VarAdminName { get; set; }

        //管理员真实姓名
        public string VarRealName { get; set; }

        //角色：1系统管理员，2审核员
        public string VarAuthority { get; set; }
    }
}
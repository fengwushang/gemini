﻿using System;

namespace Fao.Data.B2B.SM
{
    /// <summary>
    /// created by: codeGG , 2013-02-18 11:10:27
    /// Area查询模型-Power by CodeGG
    /// </summary>
    public class SmBaseArea
    {
        /// <summary>
        /// 父ID
        /// </summary>
        public int ParentID { get; set; }
    }
}